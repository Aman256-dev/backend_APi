import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import api from "../store/api";
import errorHandler from "../store/errorHandler";
// subscriber action

export const getdashBoard = createAsyncThunk(
  "dashboard/getdashBoard",
  async (_, { rejectWithValue }) => {
    try {
      const response = await api.get('/dashboard');
      if (response?.data?.status_code === 200) {
        return response.data;
      } else {
        if (response?.data?.errors) {
          return rejectWithValue(response.data.errors);
        } else {
          return rejectWithValue('Something went wrong.');
        }
      }
    } catch (err) {
      return rejectWithValue(err);
    }
  }
)
const initialState = {
  usersCount: [],
  loading: false,
  error: ''
}
const dashboardSlice = createSlice(
  {
    name: 'get_dash',
    initialState,
    reducers: {},
    extraReducers: (builder) => {
      builder.addCase(getdashBoard.pending, (state) => {
        state.loading = true;
      })
        .addCase(getdashBoard.fulfilled, (state, { payload }) => {
          state.loading = false;
          state.usersCount = payload
          state.error = ""
        })
        .addCase(getdashBoard.rejected, (state, { payload }) => {
          state.error = true;
          state.loading = false;
          state.message =
            payload !== undefined && payload.message
              ? payload.message
              : 'Something went wrong. Try again later.';
        })
    }
  }
)
// Export actions and reducer
export default dashboardSlice.reducer;
