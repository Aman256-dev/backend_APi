import { Label, Modal } from "flowbite-react";
import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { getAllSubPrompt, updatePrompt } from "../../reducers/PdfAndUrlSlice";
import { toast } from "react-toastify";

const UpdatePromptModal = ({ updatePromptModal, setUpdatePromptModal, pId, data }) => {
    const dispatch = useDispatch();
    const { loadingPromptUpdate } = useSelector((state) => state?.pdfAndUrl);
    const {
        register,
        handleSubmit,
        setValue,
        formState: { errors },
    } = useForm();

    useEffect(() => {
        setValue("prompt", data);
    }, []);

    const onSubmit = (data) => {
        console.log("Data", data)
        dispatch(updatePrompt({ ...data, prompt_id: pId })).then((res) => {
            if (res?.payload?.status_code === 200) {
                toast.success(res?.payload?.message, {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    progress: undefined,
                    theme: "light",
                });
                setUpdatePromptModal(false);
                dispatch(getAllSubPrompt());
            } else {
                toast.error(res?.payload?.response?.data?.message, {
                    position: "top-right",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    progress: undefined,
                    theme: "dark",
                });
            }
        });
    };

    return (
        <>
            <Modal
                size="7xl"
                show={updatePromptModal}
                onClose={() => setUpdatePromptModal(false)}
            >
                <Modal.Header className="border-0 absolute right-[20px] top-[20px]">
                    &nbsp;
                </Modal.Header>
                <Modal.Body className="pt-10">
                    <div className="px-3 pb-4">
                        <form onSubmit={handleSubmit(onSubmit)} className="w-full">
                            <div className="w-full">
                                <div className="mb-2 w-full">
                                    <div className="mb-2 block">
                                        <Label htmlFor="email1" value="Prompt" />
                                    </div>
                                    <textarea
                                        className="h-96 w-full bg-white border border-[#0f026f] text-[#888888] text-sm rounded-lg focus:ring-[#0f026f] focus:border-[#0f026f] block py-3 px-3"
                                        type="text"
                                        placeholder="Enter Prompt Name"
                                        {...register("prompt", { required: true })}
                                    />
                                </div>
                            </div>
                            <button
                                type="submit"
                                className="bg-[#0f026f] w-full rounded-lg text-center text-base py-2.5 font-medium text-white hover:bg-black mt-3"
                            >
                                {loadingPromptUpdate ? "Wait..." : " Update Prompt"}
                            </button>
                        </form>
                    </div>
                </Modal.Body>
            </Modal>
        </>
    )
}

export default UpdatePromptModal;