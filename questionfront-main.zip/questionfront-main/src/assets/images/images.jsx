import logo from "../imagesource/logo.png";
import logoIcon from "../imagesource/logoIcon.png";
import userIcon from "../imagesource/usericon.png";
import forgotPasswordIcon from "../imagesource/forgatepassImg.png";
import businessAnalystAI from "../imagesource/Business_Analyst_AI.png";
import technicalAnalystAI from "../imagesource/Technical_Analyst_AI.png";
import businessSystemAnalystAI from "../imagesource/Business_System_Analyst_AI.png";
import uATAnalystAI from "../imagesource/UAT_Analyst_AI.png";
import projectManagerAI from "../imagesource/Project_Manager_AI.png";
import developerAI from "../imagesource/Developer_AI.png";
import qualityAnalystAI from "../imagesource/Quality_Analyst_AI.png";
import LoginImg from "../imagesource/login_img.png";
import MenuIcon from "../imagesource/menu_icon.png";
import TopGainers01 from "../imagesource/TopGainers01.png";
import TopGainers02 from "../imagesource/TopGainers02.png";
import TopGainers03 from "../imagesource/TopGainers03.png";
import TopGainers04 from "../imagesource/TopGainers05.png";
import TopLosers01 from "../imagesource/TopLosers01.png";
import TopLosers02 from "../imagesource/TopLosers02.png";
import TopLosers03 from "../imagesource/TopLosers03.png";
import TopLosers04 from "../imagesource/TopLosers04.png";
import PortfolioAnalytics from "../imagesource/PortfolioAnalytics.png";

import AresAcquisitionCorporationIcon from "../imagesource/Ares_acquisition_corporationIcon.png";
import CocaColaCoIcon from "../imagesource/Coca-Cola_Co_icon.png";
import AmericanFinancialIcon from "../imagesource/American_Financial_icon.png";
import MicrosoftCorpIcon from "../imagesource/Microsoft_Corp_icon.png";
import UnitedParcelServiceIcon from "../imagesource/United_Parcel_ServiceIcon.png";
import AdobeIcon from "../imagesource/Adobe_Inc_icon.png";
import CounrtyCode from "../imagesource/counrty_code.png";

import nvdiaLogo from "../imagesource/nvdia_logo.png";
import greenCurve from "../imagesource/green_curve.png";

import metaIcon from "../imagesource/meta_icon.png";
import appleIcon from "../imagesource/apple_icon.png";
import teslaIcon from "../imagesource/tesla_icon.png";
import greenCurve2 from "../imagesource/green_curve2.png";
import blueCurve from "../imagesource/blue_curve.png";

import AppleLogo from "../imagesource/apple_logo.png";

import detailsAppleIcon from "../imagesource/details_apple_icon.png";

import GrapgFull from "../imagesource/grapg_full.png";
import AnalistRatings from "../imagesource/analist_ratings.png";
import EarningsGraph from "../imagesource/earnings_graph.png";

export {
  EarningsGraph,
  AnalistRatings,
  GrapgFull,
  detailsAppleIcon,
  AppleLogo,
  metaIcon,
  appleIcon,
  teslaIcon,
  greenCurve2,
  blueCurve,
  nvdiaLogo,
  greenCurve,
  CounrtyCode,
  AresAcquisitionCorporationIcon,
  CocaColaCoIcon,
  AmericanFinancialIcon,
  MicrosoftCorpIcon,
  UnitedParcelServiceIcon,
  AdobeIcon,
  PortfolioAnalytics,
  TopLosers01,
  TopLosers02,
  TopLosers03,
  TopLosers04,
  TopGainers01,
  TopGainers02,
  TopGainers03,
  TopGainers04,
  MenuIcon,
  LoginImg,
  logo,
  logoIcon,
  userIcon,
  forgotPasswordIcon,
  businessAnalystAI,
  technicalAnalystAI,
  businessSystemAnalystAI,
  uATAnalystAI,
  projectManagerAI,
  developerAI,
  qualityAnalystAI,
};
