import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../store/api";


export const uploadVendorCsv = createAsyncThunk(
    'uploadVendorCsv',
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post('/upload-vendor-csv', userInput);
            console.log("Csvresponse: ", response);
            if (response?.status === 201) {
                return response.data;
            } else {

                return rejectWithValue(response.data);
            }
        } catch (err) {

            return rejectWithValue(err);
        }
    }
)
export const getVendorCsv = createAsyncThunk(
    'getVendorCsvFile',
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.get('/get-vendor-list');
            console.log("Csvresponse: ", response);
            if (response?.status === 200) {
                return response.data;
            } else {

                return rejectWithValue(response.data);
            }
        } catch (err) {

            return rejectWithValue(err);
        }
    }

)
const initialState = {
    loading: false,
    error: null,
    message: "",
    vendorList: []
}
const UploadVendorCsvSlice = createSlice(
    {
        name: 'vendors_csv',
        initialState,
        reducers: {},
        extraReducers: (builder) => {
            builder.addCase(uploadVendorCsv.pending, (state) => {
                state.loading = true
            })
                .addCase(uploadVendorCsv.fulfilled, (state, { paylaod }) => {
                    state.loading = false
                    state.message = paylaod
                    state.error = null
                })
                .addCase(uploadVendorCsv.rejected, (state, { payload }) => {

                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
                .addCase(getVendorCsv.pending, (state) => {
                    state.loading = true
                })
                .addCase(getVendorCsv.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.vendorList = payload?.results
                    state.error = null
                })
                .addCase(getVendorCsv.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
        }
    }
)
export default UploadVendorCsvSlice.reducer;