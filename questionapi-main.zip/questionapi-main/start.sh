#!/bin/bash

# Activate the virtual environment
source /venv/bin/activate

# Install requirements
pip install -r requirements.txt
pip install pytesseract pdf2image opencv-python-headless numpy tqdm

# Run migrations and collect static files if needed
python manage.py makemigrations
python manage.py migrate
python manage.py collectstatic --noinput

# python manage.py loaddata user_type_data.json
# python manage.py loaddata user_data.json
# python manage.py loaddata subject.json
# python manage.py loaddata prompt_data.json

# Start Gunicorn server
# gunicorn question_generator.wsgi:application --bind 0.0.0.0:8000
gunicorn question_generator.wsgi:application --bind 0.0.0.0:8000 --workers 4 --timeout 1000
gunicorn question_generator.wsgi:application --bind 0.0.0.0:8000 --workers 4 --timeout 1000 --daemon
gunicorn question_generator.wsgi:application --bind 0.0.0.0:8000 --timeout 60000 --workers 3 --daemon
