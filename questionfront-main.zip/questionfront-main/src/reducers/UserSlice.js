import { tr } from "@faker-js/faker";
import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../store/api";

export const add_user = createAsyncThunk(
    'add_user',
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post('admin/add-teacher', userInput);
            console.log("response", response);
            if (response?.data?.status === true) {
                return response.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }

    }
)
export const getAllUser = createAsyncThunk(
    'getUsers',
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.get('admin/users-list');
            console.log("Response", response);
            if (response?.data?.status === true) {
                return response.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }
)
export const activeDeactiveUser = createAsyncThunk(
    'activeDeactiveUser',
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post('/admin/activate-deactivate-user', userInput);
            console.log("Response", response);
            if (response?.data?.status === true) {
                return response.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }
)
export const deleteUser = createAsyncThunk(
    'deleteUser',
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post('/admin/delete-user', userInput);
            console.log("Response", response);
            if (response?.data?.status === true) {
                return response.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }
)
const initialState = {
    loading: false,
    error: null,
    message: "",
    allUsers: []
}
const UserSlice = createSlice(
    {
        name: 'userData',
        initialState,
        reducers: {},
        extraReducers: (builder) => {
            builder.addCase(add_user.pending, (state) => {
                state.loading = true;
            })
                .addCase(add_user.fulfilled, (state, { payload }) => {
                    state.loading = false;
                    state.message = payload
                    state.error = null
                })
                .addCase(add_user.rejected, (state, { payload }) => {
                    state.loading = false;
                    state.error = payload;
                })
                .addCase(getAllUser.pending, (state) => {
                    state.loading = true;
                })
                .addCase(getAllUser.fulfilled, (state, { payload }) => {
                    state.loading = false;
                    state.allUsers = payload;
                    state.error = null
                })
                .addCase(getAllUser.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
                .addCase(activeDeactiveUser.pending, (state) => {
                    state.loading = true
                })
                .addCase(activeDeactiveUser.fulfilled, (state, { paylaod }) => {
                    state.loading = false
                    state.message = paylaod
                })
                .addCase(activeDeactiveUser.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
                .addCase(deleteUser.pending, (state) => {
                    state.loading = true
                })
                .addCase(deleteUser.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.message = payload
                })
                .addCase(deleteUser.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })

        }

    }
)
export default UserSlice.reducer