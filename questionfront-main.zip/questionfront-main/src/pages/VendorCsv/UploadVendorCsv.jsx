import { FileInput, Label, Table } from "flowbite-react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import {
  getVendorCsv,
  uploadVendorCsv,
} from "../../reducers/UploadVendorCsvSlice";
import { useEffect } from "react";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const UploadVendorCsv = () => {
  const { loading, vendorList } = useSelector((state) => state?.venDorCsv);
  const dispatch = useDispatch();
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors },
    reset,
  } = useForm();

  const onSubmit = (data) => {
    const formData = new FormData();
    console.log("Data: ", data?.csv_file[0]);

    formData.append("csv_file", data?.csv_file[0]);
    dispatch(uploadVendorCsv(formData)).then((res) => {
      console.log("Vendor res: ", res);
      if (res?.payload?.status === true) {
        toast.success(res?.payload?.msg, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          progress: undefined,
          theme: "light",
        });
        dispatch(getVendorCsv());
      } else {
        toast.error("Upload Pdf only", {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          progress: undefined,
          theme: "dark",
        });
      }
    });
  };

  useEffect(() => {
    dispatch(getVendorCsv());
  }, [dispatch]);

  console.log("Vendor List: ", vendorList?.results);
  return (
    <>
      <ToastContainer />
      <div className="container mx-auto p-4 text-black">
        <h1 className="text-2xl font-semibold mb-4">Display Data</h1>

        <div className="flex justify-between items-center mb-6">
          <div>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="flex items-center justify-center">
                <div className="upload_data_area">
                  <div className="mb-2 block">
                    <Label className="text-base" value="Upload file" />
                  </div>
                  <FileInput
                    id="file-upload"
                    {...register("csv_file", { required: "File is required" })}
                  />
                </div>

                <button
                  type="submit"
                  className="bg-[#029962] px-4 py-2 text-white rounded-md mt-7 ml-1"
                >
                  Parse
                </button>
                {/* {errors.csv_file && (
                  <span className="text-red-500">
                    {errors.csv_file.message}
                  </span>
                )} */}
              </div>
            </form>
          </div>
          <div>
            <form className="flex items-center max-w-sm mx-auto">
              <div className="relative w-full">
                <input
                  type="text"
                  id="simple-search"
                  className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-4 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  placeholder="Search..."
                  required
                />
              </div>
              <button
                type="submit"
                className="p-2.5 ms-2 text-sm font-medium text-white bg-blue-700 rounded-lg border border-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
              >
                <svg
                  className="w-4 h-4"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 20 20"
                >
                  <path
                    stroke="currentColor"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
                  />
                </svg>
                <span className="sr-only">Search</span>
              </button>
            </form>
          </div>
        </div>

        <div className="overflow-x-auto">
          <Table striped>
            <Table.Head>
              {/* <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Actions
              </Table.HeadCell> */}
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Vendor
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Product/Service
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Contact
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Best Contact
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Phone
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Email
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Member Benefit
              </Table.HeadCell>
            </Table.Head>
            <Table.Body className="divide-y">
              {Array.isArray(vendorList) &&
                vendorList?.map((vList) => {
                  return (
                    <>
                      <Table.Row className="bg-white dark:border-gray-700 dark:bg-gray-800">
                        {/* <Table.Cell className="flex items-center justify-start">
                        <div className="mr-10">
                          <button onClick={() => updateHandler(uInfo?.info_id)}>
                            <HiPencil />
                          </button>
                        </div>
                      </Table.Cell> */}
                        <Table.Cell className="font-bold">
                          {vList?.vendor}
                        </Table.Cell>
                        <Table.Cell className="font-bold">
                          {vList?.product_service}
                        </Table.Cell>
                        <Table.Cell className="font-bold">
                          {vList?.contact}
                        </Table.Cell>
                        <Table.Cell>{vList?.best_contact}</Table.Cell>
                        <Table.Cell>{vList?.phone}</Table.Cell>
                        <Table.Cell>{vList?.email}</Table.Cell>
                        <Table.Cell>{vList?.member_benifit}</Table.Cell>
                      </Table.Row>
                    </>
                  );
                })}
            </Table.Body>
          </Table>
        </div>
      </div>
    </>
  );
};
export default UploadVendorCsv;
