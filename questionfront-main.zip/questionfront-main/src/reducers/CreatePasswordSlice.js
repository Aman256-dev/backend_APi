import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../store/api";
import errorHandler from "../store/errorHandler";

export const createPassword = createAsyncThunk(
    "createPassword",
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post('/user/create-password', userInput);
            console.log("response: ", response);
            if (response?.data?.status_code === 200) {
                return response.data;
            } else {
                return rejectWithValue(response.data);
            }
        } catch (err) {
            let errors = errorHandler(err);
            return rejectWithValue(errors);
        }
    }
)
const initialState = {
    loading: false,
    error: null,
    message: ""
}
const CreatePasswordSlice = createSlice(
    {
        name: "create_Password",
        initialState,
        reducers: {},
        extraReducers: (builder) => {
            builder.addCase(createPassword.pending, (state) => {
                state.loading = true;
            })
                .addCase(createPassword.fulfilled, (state, { payload }) => {
                    state.loading = false;
                    state.message = payload
                    state.error = null
                })
                .addCase(createPassword.rejected, (state, payload) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
        }
    }
)
export default CreatePasswordSlice.reducer;