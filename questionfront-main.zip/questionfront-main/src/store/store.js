import { configureStore } from '@reduxjs/toolkit';

import AuthSlice from '../reducers/AuthSlice';
import DashboardSlice from '../reducers/DashboardSlice';

import UserSlice from '../reducers/UserSlice';
import UserTypeSlice from '../reducers/UserTypeSlice';
import UserLogsSlice from '../reducers/UserLogsSlice';
import CreatePasswordSlice from '../reducers/CreatePasswordSlice';
import UploadCsvSlice from '../reducers/UploadCsvSlice';
import UserInfoSlice from '../reducers/UserInfoSlice';
import UploadPdfSlice from '../reducers/UploadPdfSlice';
import UserUpdateSlice from '../reducers/UserUpdateSlice';
import UploadVendorCsvSlice from '../reducers/UploadVendorCsvSlice';
import SubscriptionSlice from '../reducers/SubscriptionSlice';
import downloadSlice from '../reducers/downloadSlice';
import PromptSlice from '../reducers/PromptSlice';
import SubjectListSlice from '../reducers/SubjectListSlice'
import PdfAndUrlSlice from '../reducers/PdfAndUrlSlice';

export const store = configureStore({
  reducer: {
    loginAuth: AuthSlice,
    dashboardData: DashboardSlice,
    users: UserSlice,
    useType: UserTypeSlice,
    logs: UserLogsSlice,
    crtPass: CreatePasswordSlice,
    upld_csv: UploadCsvSlice,
    info: UserInfoSlice,
    upld_pdf: UploadPdfSlice,
    updates: UserUpdateSlice,
    venDorCsv: UploadVendorCsvSlice,
    subs: SubscriptionSlice,
    downloads: downloadSlice,
    prompts: PromptSlice,
    teacher: SubjectListSlice,
    pdfAndUrl: PdfAndUrlSlice,
  },
  devTools: import.meta.env.DEV,
});
