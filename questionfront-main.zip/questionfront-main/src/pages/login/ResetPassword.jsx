import { Link, useNavigate, useParams } from "react-router-dom";
// import { forgotPasswordIcon, logo } from "../../../assets/images/images";
import { useDispatch, useSelector } from "react-redux";
import { useForm } from "react-hook-form";
import { Base64 } from "js-base64";
import { resetPassword } from "../../reducers/AuthSlice";

// import { resetPassword } from "../../../Reducer/AuthSlice";

const ResetPassword = () => {
  const dispatch = useDispatch();
  const nevigate = useNavigate();
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm();
  const token = useParams();
  console.log("token: ", token);
  const decodeToken = Base64.decode(token?.token);
  console.log("decode Token", decodeToken);
  const jsonObject = JSON.parse(decodeToken);
  console.log("jsonObject", jsonObject);
  const userid = jsonObject?.user_id;
  // const time = jsonObject?.time;
  console.log("User: ", userid);
  const onSubmit = (data) => {
    dispatch(resetPassword({ ...data, user_id: userid })).then((res) => {
      console.log(res);
      if (res?.payload?.status_code === 200) {
        nevigate("/");
      }
    });
  };
  const password = watch("password");
  return (
    <>
      <div className="my-0 md:my-16 lg:my-0 mx-4 lg:mx-0 flex justify-center items-center h-screen">
        <div className="w-full max-w-lg my-0 mx-auto">
          <div className="text-center mb-4">
            {/* <img className="inline-block w-44" src={forgotPasswordIcon} /> */}
          </div>
          <h1 className="text-[40px] text-center leading-[40px] text-[#009BF2] pb-5">
            Reset your password?
          </h1>
          <p className="text-base md:text-lg text-blue-900 font-medium text-center pb-8">
            No worries, we got you covered.
          </p>
          <div className="login_area">
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="mb-6">
                <input
                  type="password"
                  id="password1"
                  className="bg-white border border-[#009BF2] text-[#888888] text-base rounded-xl focus:ring-[#009BF2] focus:border-[#009BF2] block w-full py-4 px-3"
                  placeholder="Enter New Password"
                  {...register("password", { required: true })}
                />
              </div>
              {errors.password && (
                <span className="text-red-500">New Password is Required</span>
              )}
              <div className="mb-6">
                <input
                  type="password"
                  id="password2"
                  className="bg-white border border-[#009BF2] text-[#888888] text-base rounded-xl focus:ring-[#009BF2] focus:border-[#009BF2] block w-full py-4 px-3"
                  placeholder="Confirm Password"
                  {...register("confirm_password", {
                    required: true,
                    validate: (value) =>
                      value === password || "Password do not Match",
                  })}
                />
                {errors?.confirm_password && (
                  <h6 className="text-red-600">
                    {errors.confirm_password.message}
                  </h6>
                )}
              </div>
              <button
                type="submit"
                className="text-white bg-[#009BF2] font-Manrope font-extrabold text-[23px] mb-2 hover:bg-black focus:ring-4 focus:outline-none focus:ring-blue-300 rounded-xl text-xl w-full px-5 py-3.5 text-center"
              >
                Submit
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};
export default ResetPassword;
