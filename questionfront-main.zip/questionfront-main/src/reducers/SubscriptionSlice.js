import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../store/api";

export const getPlans = createAsyncThunk(
    'subscription/subscription',
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.get("/plans");
            console.log("response", response);
            if (response?.status === 200) {
                return response.data;
            } else {
                let errors = errorHandler(response);
                return rejectWithValue(response.data);
            }
        } catch (err) {
            console.log("error", err);
            // let errors = errorHandler(err);
            // console.log("errors", errors);
            return rejectWithValue(err);
        }
    }
)
export const paymentIntent = createAsyncThunk(
    'subscription/paymentIntent',
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post("/create-payment-intent", userInput);
            console.log("response", response);
            if (response?.status === 200) {
                return response.data;
            } else {
                let errors = errorHandler(response);
                return rejectWithValue(response.data);
            }
        } catch (err) {
            console.log("error", err);
            // let errors = errorHandler(err);
            // console.log("errors", errors);
            return rejectWithValue(err);
        }
    }

)
export const getStripeKey = createAsyncThunk(
    'subscription/getstripeKey',
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.get("/get-stripe-keys");
            console.log("response", response);
            if (response?.status === 200) {
                return response.data;
            } else {
                let errors = errorHandler(response);
                return rejectWithValue(response.data);
            }
        } catch (err) {
            console.log("error", err);
            // let errors = errorHandler(err);
            // console.log("errors", errors);
            return rejectWithValue(err);
        }
    }
)
export const completeSubscription = createAsyncThunk(
    'subscription/completeSubscription',

    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post("/complete-subscription", userInput);
            console.log("response", response);
            if (response?.status === 201) {
                return response.data;
            } else {
                let errors = errorHandler(response);
                return rejectWithValue(response.data);
            }
        } catch (err) {
            console.log("error", err);
            // let errors = errorHandler(err);
            // console.log("errors", errors);
            return rejectWithValue(err);
        }
    }

)
export const getUserDetails = createAsyncThunk(
    'getsUserDetails',
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.get("/get-user-details");
            console.log("response", response);
            if (response?.status === 200) {
                return response.data;
            } else {
                let errors = errorHandler(response);
                return rejectWithValue(response.data);
            }
        } catch (err) {
            console.log("error", err);
            // let errors = errorHandler(err);
            // console.log("errors", errors);
            return rejectWithValue(err);
        }
    }
)
export const cancelSubscription = createAsyncThunk(
    'cancelSubscriptions',
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post("/cancel-subscription", userInput);
            console.log("response", response);
            if (response?.status === 200) {
                return response.data;
            } else {
                let errors = errorHandler(response);
                return rejectWithValue(response.data);
            }
        } catch (err) {
            console.log("error", err);
            // let errors = errorHandler(err);
            // console.log("errors", errors);
            return rejectWithValue(err);
        }
    }

)
const initialState = {
    loading: false,
    error: null,
    plans: [],
    message: "",
    paymentIn: {},
    stripeKey: {},
    clientSecret: "",
    customer_id: "",
    subscription_id: "",
    usersDetails: "",
    completeSubs: "",
    cancelledSubs: ""
}
const subscriptionSlice = createSlice(
    {
        name: 'subscriptions',
        initialState,
        reducers: {},
        extraReducers: (builder) => {
            builder.addCase(getPlans.pending, (state) => {
                state.loading = true
            })
                .addCase(getPlans.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.plans = payload
                    state.error = null
                })
                .addCase(getPlans.rejected, (state, { payload }) => {

                    state.error = true;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : "Something went wrong. Try again later.";
                })
                .addCase(paymentIntent.pending, (state) => {
                    state.loading = true

                })
                .addCase(paymentIntent.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.clientSecret = payload?.clientSecret
                    state.customer_id = payload?.customer_id
                    state.subscription_id = payload?.subscription_id
                    state.error = null
                })
                .addCase(paymentIntent.rejected, (state, { payload }) => {

                    state.error = true;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : "Something went wrong. Try again later.";
                })
                .addCase(getStripeKey.pending, (state) => {
                    state.loading = true
                })
                .addCase(getStripeKey.fulfilled, (state, { payload }) => {

                    state.loading = false
                    state.stripeKey = payload?.stripe_publishable_key
                    state.error = null
                })
                .addCase(getStripeKey.rejected, (state, { payload }) => {
                    state.error = true;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : "Something went wrong. Try again later.";
                })
                .addCase(completeSubscription.pending, (state) => {
                    state.loading = true
                })
                .addCase(completeSubscription.fulfilled, (state, { payload }) => {
                    console.log("subs payload", payload);

                    state.loading = false
                    state.completeSubs = payload
                    state.error = null
                })
                .addCase(completeSubscription.rejected, (state, { payload }) => {
                    state.error = true;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : "Something went wrong. Try again later.";
                })
                .addCase(getUserDetails.pending, (state) => {
                    state.loading = true
                })
                .addCase(getUserDetails.fulfilled, (state, { payload }) => {
                    console.log("payload", payload?.res);

                    state.loading = false
                    state.usersDetails = payload?.res
                    console.log("usersDetails", state.usersDetails);

                    state.error = null
                })
                .addCase(getUserDetails.rejected, (state, { payload }) => {
                    state.error = true;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : "Something went wrong. Try again later.";
                })
                .addCase(cancelSubscription?.pending, (state) => {
                    state.loading = true
                })
                .addCase(cancelSubscription?.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.cancelledSubs = payload
                    state.error = null
                })
                .addCase(cancelSubscription?.rejected, (state, { payload }) => {
                    state.loading = false
                    state.error = true;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : "Something went wrong. Try again later.";
                })

        }
    }
)
export default subscriptionSlice.reducer;