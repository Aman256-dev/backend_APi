import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../store/api";
import errorHandler from "../store/errorHandler";

export const upload_csv = createAsyncThunk(
    'upload_csvs',
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post('/upload-csv', userInput);
            console.log("Csvresponse: ", response);
            if (response?.status === 201) {
                return response.data;
            } else {

                return rejectWithValue(response.data);
            }
        } catch (err) {

            return rejectWithValue(err);
        }
    }
)
const initialState = {
    loading: false,
    error: null,
    message: ""
}
const UploadCsvSlice = createSlice(
    {
        name: "upload_csvFile",
        initialState,
        reducers: {},
        extraReducers: (builder) => {
            builder.addCase(upload_csv.pending, (state) => {
                state.loading = true
            })
                .addCase(upload_csv.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.message = payload
                    state.error = null
                })
                .addCase(upload_csv.rejected, (state, { payload }) => {

                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
        }
    }
)
export default UploadCsvSlice.reducer;