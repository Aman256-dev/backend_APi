import React, { useEffect, useState } from "react";
import {
  Button,
  Checkbox,
  Radio,
  Label,
  TextInput,
  Select,
} from "flowbite-react";
import { useLocation, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { Controller, useForm } from "react-hook-form";

import { add_user, getSubList } from "../../reducers/SubjectListSlice";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const AddUser = () => {
  const [errorMessage, setErrorMessage] = useState("");
  const { loading, subList } = useSelector((state) => state?.teacher);
  const nevigate = useNavigate();
  const dispatch = useDispatch();
  const location = useLocation();
  const url = window.location.origin;
  console.log("Base Url", url);

  useEffect(() => {
    dispatch(getSubList());
  }, [dispatch]);
  console.log("teacher", subList);
  const {
    register,
    handleSubmit,
    control,
    formState: { errors },
  } = useForm();
  const onSubmit = (data) => {
    dispatch(add_user({ ...data, base_url: url })).then((res) => {
      console.log("Res: ", res);
      if (res?.payload?.status === true) {
        // nevigate("/user-list");
        toast.success(res?.payload?.message, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          progress: undefined,
          theme: "light",
        });
      } else {
        setErrorMessage(res?.payload?.response?.data?.msg);
      }
    });
  };
  return (
    <>
      <ToastContainer />
      <div className="container mx-auto p-4 text-black">
        <h1 className="text-2xl font-semibold mb-4">Add Teachers</h1>
        <div>
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="mb-0">
              <div className="mb-0 grid grid-cols-2 gap-4">
                <div className="mb-4">
                  <div className="mb-2 block">
                    <Label className="text-base font-bold" value="First Name" />
                  </div>
                  <TextInput
                    type="text"
                    placeholder="Enter First Name"
                    required
                    {...register("first_name", { required: true })}
                  />
                  {errors.first_name && (
                    <span className="text-red-500">First Name is required</span>
                  )}
                </div>

                <div className="mb-4">
                  <div className="mb-2 block">
                    <Label className="text-base font-bold" value="Last Name" />
                  </div>
                  <TextInput
                    type="text"
                    placeholder="Enter User Name short"
                    required
                    {...register("last_name", { required: true })}
                  />
                </div>
                {errors.last_name && (
                  <span className="text-red-500">Last Name is required</span>
                )}
              </div>
            </div>
            <div className="mb-0">
              <div className="mb-4 grid grid-cols-2 gap-4">
                <div className="mb-4">
                  <div className="mb-2 block">
                    <Label className="text-base font-bold" value=" Email ID" />
                  </div>
                  <TextInput
                    type="email"
                    placeholder="Enter Email ID"
                    required
                    {...register("email", { required: true })}
                  />
                </div>
                {errors.email && (
                  <span className="text-red-500">Email is required</span>
                )}
                <div className="mb-4">
                  <div className="mb-2 block">
                    <Label
                      className="text-base font-bold"
                      value="Subject Type"
                    />
                  </div>
                  <Controller
                    name="subject_id"
                    control={control}
                    defaultValue=""
                    render={({ field }) => (
                      <Select {...field} required>
                        <option>Choose...</option>
                        {subList?.results?.map((utypes) => {
                          return (
                            <>
                              <option value={`${utypes?.id}`}>
                                {utypes?.subject_name}
                              </option>
                            </>
                          );
                        })}
                      </Select>
                    )}
                  />
                </div>
                {errors.user_type_id && (
                  <span className="text-red-500">Please Select User Type</span>
                )}
              </div>
              <div className="mt-4 block">
                <Button
                  type="submit"
                  className="bg-[#4051a3] hover:bg-[#172554] px-2"
                >
                  {loading ? "Waiting.." : "Add User"}
                </Button>
                {errorMessage && (
                  <div className="text-red-500 text-center mb-4">
                    {errorMessage}
                  </div>
                )}
              </div>
            </div>
          </form>
        </div>
      </div>
    </>
  );
};

export default AddUser;
