import React, { useEffect } from "react";
import { Button, Table } from "flowbite-react";

import { MdDelete } from "react-icons/md";
import { useDispatch, useSelector } from "react-redux";
import { getUserLog } from "../../reducers/UserLogsSlice";

const UsersLog = () => {
  const { userLogsData } = useSelector((state) => state?.logs);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getUserLog());
  }, [dispatch]);
  console.log("Logs: ", userLogsData);
  return (
    <>
      <div className="container mx-auto p-4 text-black">
        <h1 className="text-2xl font-semibold mb-4">Users Log</h1>
        <div className="overflow-x-auto">
          <Table striped>
            <Table.Head>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                User Name
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Logged at
              </Table.HeadCell>
            </Table.Head>
            <Table.Body className="divide-y">
              {userLogsData?.map((logData) => {
                return (
                  <>
                    <Table.Row className="bg-white dark:border-gray-700 dark:bg-gray-800">
                      <Table.Cell className="font-bold">
                        {logData?.user_name}
                      </Table.Cell>
                      <Table.Cell className="font-bold">
                        {logData?.logged_time}
                      </Table.Cell>
                    </Table.Row>
                  </>
                );
              })}
            </Table.Body>
          </Table>
        </div>
        {/* <div className="mt-4 block">
          <Button
            type="submit"
            className="bg-[#4051a3] hover:bg-[#172554] px-2"
          >
            Load More
          </Button>
        </div> */}
      </div>
    </>
  );
};

export default UsersLog;
