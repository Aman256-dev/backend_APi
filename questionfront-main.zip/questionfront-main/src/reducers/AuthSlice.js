/* eslint-disable no-unused-vars */
import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import api from "../store/api";
import errorHandler from "../store/errorHandler";

export const login = createAsyncThunk(
  "login",
  async (userInput, { rejectWithValue }) => {
    try {
      const response = await api.post("/user/login", userInput);
      console.log("response", response);
      if (response?.status === 200) {
        return response.data;
      } else {
        let errors = errorHandler(response);
        return rejectWithValue(response.data);
      }
    } catch (err) {
      console.log("error", err);
      // let errors = errorHandler(err);
      // console.log("errors", errors);
      return rejectWithValue(err);
    }
  }
);
export const registeration = createAsyncThunk(
  "reg",
  async (userInput, { rejectWithValue }) => {
    try {
      const response = await api.post("/user/sign-up", userInput);
      console.log("response", response);
      if (response?.status === 201) {
        return response.data;
      } else {
        let errors = errorHandler(response);
        return rejectWithValue(response.data);
      }
    } catch (err) {
      console.log("error", err);
      // let errors = errorHandler(err);
      // console.log("errors", errors);
      return rejectWithValue(err);
    }
  }
);
export const forgetPassword = createAsyncThunk(
  "forget-passwords",
  async (userInput, { rejectWithValue }) => {
    try {
      const response = await api.post("user/forget-password", userInput);
      console.log("Response: ", response);
      if (response?.status === 200) {
        return response.data;
      } else {
        let errors = errorHandler(response);
        return rejectWithValue(response.data);
      }
    } catch (error) {
      console.log(error.response?.data?.message);
      if (error.response && error.response.status === 422) {
        return rejectWithValue({ network: 422, message: error.response?.data?.message || "Something Went Wrong" });
      }
      return rejectWithValue({ network: error.response?.status || 500, message: 'Something went wrong.' });
      let errors = errorHandler(err);
      return rejectWithValue(errors);
    }
  }
);
// initialize userToken from local storage
const userToken = localStorage.getItem('userToken')
  ? localStorage.getItem('userToken')
  : null

export const resetPassword = createAsyncThunk(
  "resetPassword",
  async (userInput, { rejectWithValue }) => {
    try {
      const response = await api.post("/user/reset-password", userInput);
      // console.log("response", response?.status);
      if (response?.status === 200) {
        return response.data;
      } else {
        let errors = errorHandler(response);
        return rejectWithValue(response.data);
      }
    } catch (err) {
      let errors = errorHandler(err);
      return rejectWithValue(errors);
    }
  }
);
// initialize the state
const initialState = {
  message: null,
  error: null,
  loading: false,
  isLoggedIn: false,
};


const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    resetAfterLoggedIn: (state) => {
      state = { ...initialState, isLoggedIn: true };
    },
    logout: (state) => {
      state.message = null,
        state.error = null,
        state.loading = false,
        state.isLoggedIn = false,
        localStorage.removeItem("userToken");
      localStorage.removeItem("name")
      localStorage.removeItem("userId")
      localStorage.removeItem("userType")
      localStorage.removeItem("subject")
      localStorage.removeItem("sub")
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(login.pending, (state) => {
        state.isLoggedIn = false;
        state.message = "Loading..";
        state.error = false;
        state.loading = true
      })

      .addCase(login.fulfilled, (state, { payload }) => {
        const { access_token, first_name, user_id, user_type, subject } = payload;
        state.loading = false
        state.isLoggedIn = true;
        state.message = "Successfully Logged in";
        localStorage.setItem("sub", JSON.stringify({ "subject": subject }))

        localStorage.setItem("userType", JSON.stringify({ "user_type_id": user_type }))
        localStorage.setItem(
          "userToken",
          JSON.stringify({ "token": access_token })
        );

        // sessionStorage.setItem(
        //   "userToken",
        //   JSON.stringify({ "token": access_token })
        // );
        localStorage.setItem(
          "name",
          JSON.stringify({ "name": first_name })
        )
        localStorage.setItem("userId", JSON.stringify({ "user_id": user_id }))
        state.error = false;
      })

      .addCase(login.rejected, (state, { payload }) => {
        state.isLoggedIn = false;
        state.loading = false
        state.error = true;
        state.message =
          payload !== undefined && payload.message
            ? payload.message
            : "Something went wrong. Try again later.";
      })

      .addCase(forgetPassword.pending, (state) => {
        state.isLoggedIn = false;
        state.message = "Loading..";
        state.error = false;
      })

      .addCase(forgetPassword.fulfilled, (state, { payload }) => {
        const { access_token, message } = payload;
        state.isLoggedIn = true;
        state.message = message;
        state.error = false;
      })
      .addCase(forgetPassword.rejected, (state, { payload }) => {
        state.isLoggedIn = false;
        state.error = true;
        state.message =
          payload !== undefined && payload.message
            ? payload.message
            : "Something went wrong. Try again later.";
      })
      .addCase(resetPassword.pending, (state) => {
        state.isLoggedIn = true;
      })
      .addCase(resetPassword.fulfilled, (state, { payload }) => {

        state.isLoggedIn = false
        state.message = payload
        state.error = null
      })
      .addCase(resetPassword.rejected, (state, { payload }) => {
        state.isLoggedIn = false;
        state.error = true;
        state.message =
          payload !== undefined && payload.message
            ? payload.message
            : "Something went wrong. Try again later.";
      }).addCase(registeration.pending, (state) => {
        state.loading = true
      })
      .addCase(registeration.fulfilled, (state, { payload }) => {

        const { access_token, user_id } = payload
        localStorage.setItem(
          "userToken",
          JSON.stringify({ "token": access_token })
        );
        localStorage.setItem("userId", JSON.stringify({ "user_id": user_id }))
        state.loading = false
        state.message = payload
        state.error = false
      })
      .addCase(registeration.rejected, (state, { payload }) => {
        state.isLoggedIn = false;
        state.error = true;
        state.loading = false
        state.message =
          payload !== undefined && payload.message
            ? payload.message
            : "Something went wrong. Try again later.";
      })
  },
});
export const { resetAfterLoggedIn, logout, clearMessages } =
  authSlice.actions;

export default authSlice.reducer;
