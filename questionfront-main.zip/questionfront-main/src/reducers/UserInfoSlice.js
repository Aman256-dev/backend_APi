import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../store/api";

export const getUserInfo = createAsyncThunk(
    'user/getUserInfo',
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.post('/get-information-list');
            console.log("Response: ", response);
            if (response?.data?.status === true) {
                return response?.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }
)
const initialState = {
    loading: false,
    error: null,
    infoList: []
}
const UserInfoSlice = createSlice(
    {
        name: 'info_user',
        initialState,
        reducers: {},
        extraReducers: (builder) => {
            builder.addCase(getUserInfo.pending, (state) => {
                state.loading = true
            })
                .addCase(getUserInfo.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.infoList = payload
                    state.error = null
                })
                .addCase(getUserInfo.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
        }
    }
)
export default UserInfoSlice.reducer;