import base64
import json
from rest_framework.decorators import api_view,permission_classes,authentication_classes
from rest_framework.response import Response
from app.models.users import User
from app.models.userType import UserType
from app.models.subject import Subject
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
import requests
from rest_framework import status
from app.validations.serializers import *
from django.conf import settings
from datetime import datetime
from django.template.loader import render_to_string
from django.core.mail import send_mail
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def add_user(request):
    data=request.data
    serializer = AddUserSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            'status':False,
            'message':'Validation error',
            'errors':serializer.errors,
            'status_code':status.HTTP_400_BAD_REQUEST
        },status.HTTP_400_BAD_REQUEST)
    fname=request.data.get('first_name',None)
    lname = request.data.get('last_name', None)
    email = request.data.get('email', None)
    subject_id = request.data.get('subject_id',None)
    base_url = request.data.get('base_url',None)
    time = datetime.now()
    str_time = time.strftime('%Y-%m-%d %H:%M:%S')
    chk=User.objects.filter(username=email).count()
    if(chk==0):
        user = User.objects.create(
            first_name=fname,
            last_name=lname,
            username=email,
            email=email,
            password='',
            status=1,
            user_type_id=2,
            subject_id=subject_id
        )
        if user.id>0:
            user_id=user.id
            time=datetime.now()
            str_time=time.strftime('%Y-%m-%d %H:%M:%S')
            secret_data={
                'user_id':user_id,
                'time':str_time
            }
            json_data=json.dumps(secret_data)
            token = base64.b64encode(json_data.encode('utf-8')).decode('utf-8')
            link_url=f'{base_url}/user/set-password/{token}'
            subject="Welcome to QA Generator team"
            from_email=settings.EMAIL_HOST_USER
            html_template=render_to_string('set_password.html', {'link_url': link_url,'fname':fname})
            send_mail(subject,'',from_email,[email],fail_silently=False,html_message=html_template)
            return Response({
                'status':True,
                'message':'User has been added successfully',
                'status_code':status.HTTP_201_CREATED
            },status.HTTP_201_CREATED)
        else:
            return Response({
                'status':False,
                'message':'Unable to create',
                'status_code':status.HTTP_400_BAD_REQUEST
            },status.HTTP_400_BAD_REQUEST)
    else:
        return Response({
                'status':False,
                'message':'This email is already exist, please try another one',
                'status_code':status.HTTP_400_BAD_REQUEST
            },status.HTTP_400_BAD_REQUEST)
@api_view(['POST'])
@permission_classes([IsAuthenticated])
def activate_deactivate_user(request):
    data=request.data
    serializer = UserIdSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            'status':False,
            'message':'Validation error',
            'errors':serializer.errors,
            'status_code':status.HTTP_400_BAD_REQUEST
        },status.HTTP_400_BAD_REQUEST)
    user_id=request.data.get('id',None)
    chk=User.objects.filter(id=user_id).count()
    if chk>0:
        get_user=User.objects.filter(id=user_id).get()
        u=User.objects.get(id=user_id)
        if(get_user.status==1):
            u.status=0
            u.save()
            msg='User has been deactivated successfully'
        else:
            u.status=1
            u.save()
            msg = 'User has been activated successfully'
        return Response({
            'status':True,
            'message':msg,
            'status_code':status.HTTP_200_OK
        },status.HTTP_200_OK)
    else:
        return Response({
            'status': False,
            'message': 'No users found',
            'status_code': status.HTTP_400_BAD_REQUEST
        }, status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def users_list(request):
    users=User.objects.filter(is_deleted=0).select_related('user_type').order_by('-id').exclude(user_type=1)
    user_data=[
        {
            'id':user.id,
            'fname':user.first_name,
            'lname':user.last_name,
            'email':user.email,
            'user_type_id':user.user_type_id,
            'user_type':user.user_type.user_type,
            'status':user.status
        }
        for user in users
    ]
    if(len(user_data)>0):
        return Response({
            'status':True,
            'message':'',
            'results':user_data,
            'status_code':status.HTTP_200_OK
        },status.HTTP_200_OK)
    else:
        return Response({
            'status': True,
            'message': 'No records found',
            'results': [],
            'status_code': status.HTTP_200_OK
        }, status.HTTP_200_OK)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def delete_user(request):
    data=request.data
    serializer=UserIdSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            'status': False,
            'message': 'Validation error',
            'errors': serializer.errors,
            'status_code': status.HTTP_400_BAD_REQUEST
        }, status.HTTP_400_BAD_REQUEST)
    else:
        user_id=request.data.get('id',None)
        chk=User.objects.filter(id=user_id).count()
        if chk>0:
            user=User.objects.filter(id=user_id)
            user.update(is_deleted=1)
            return Response({
                'status':True,
                'message':'Deleted successfully',
                'status_code':status.HTTP_200_OK
            })
        else:
            return Response({
                'status': True,
                'message': 'No users',
                'status_code': status.HTTP_400_BAD_REQUEST
            },status.HTTP_400_BAD_REQUEST)
@api_view(['POST'])
# @permission_classes([IsAuthenticated])
def create_password(request):
    data=request.data
    serializer=PasswordSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            'status': False,
            'message': 'Validation error',
            'errors': serializer.errors,
            'status_code': status.HTTP_400_BAD_REQUEST
        }, status.HTTP_400_BAD_REQUEST)
    user_id=request.data.get('user_id',None)
    password=request.data.get('password',None)
    confirm_password=request.data.get('confirm_password',None)
    chk=User.objects.filter(id=user_id).count()
    if chk>0:
        if password==confirm_password:
            user=User.objects.get(id=user_id)
            password=make_password(password)
            user.password=password
            user.save()
            msg='Password has been changed successfully'
            stats_code=status.HTTP_200_OK
            st=True
        else:
            msg='Password and confirm password does not match'
            stats_code=status.HTTP_400_BAD_REQUEST
            st = True
    else:
        msg='No users found'
        stats_code=status.HTTP_400_BAD_REQUEST
        st = True

    return Response({
        'status':st,
        'message':msg,
        'status_code':stats_code
    },stats_code)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_subject(request):
    get_subjects=Subject.objects.filter(is_deleted=0).exclude(id=1)
    subject_data=[
        {
            'id':get_subject.id,
            'subject_name':get_subject.subject_name,
        }
        for get_subject in get_subjects
    ]
    if(len(subject_data)>0):
        return Response({
            'status':True,
            'message':'',
            'results':subject_data,
            'status_code':status.HTTP_200_OK
        },status.HTTP_200_OK)
    else:
        return Response({
            'status':True,
            'message':'No record found',
            'results':[],
            'status_code':status.HTTP_200_OK
        },status.HTTP_200_OK)
