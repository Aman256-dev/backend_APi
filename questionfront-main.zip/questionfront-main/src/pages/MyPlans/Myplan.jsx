import { useEffect } from "react";
import { AiOutlineCheck } from "react-icons/ai";
import { useDispatch, useSelector } from "react-redux";
import {
  cancelSubscription,
  getUserDetails,
} from "../../reducers/SubscriptionSlice";
import { useNavigate } from "react-router-dom";

const Myplan = () => {
  const { usersDetails, loading } = useSelector((state) => state?.subs);
  const userIdObject = localStorage.getItem("userId");
  const parseUserId = JSON.parse(userIdObject);
  console.log("parse User Id", parseUserId);

  const userId = parseUserId?.user_id;
  console.log("UserId: ", userId);
  const dispatch = useDispatch();
  const nevigate = useNavigate();
  useEffect(() => {
    dispatch(getUserDetails());
  }, [dispatch]);
  console.log("User Details", usersDetails?.user_subscription);
  //   const handleDelete = (subsId) => {
  //     dispatch(
  //       cancelSubscription({
  //         user_id: userId,
  //         subscription_id: subsId,
  //       })
  //     ).then((res) => {
  //       console.log("cancel", res);
  //       if (res?.payload?.status === true) {
  //         nevigate("/subscriptionPage");
  //       }
  //     });
  //   };
  return (
    <>
      <div>
        <div className="mx-auto max-w-2xl mt-16 mb-20 px-2">
          <h2 className="text-4xl text-black font-bold mb-6">My Plan</h2>
          <div>
            <div className="text-left w-8/12 mb-4 lg:mb-0">
              <div className="bg-white py-3 mt-6 text-center items-center justify-center">
                {usersDetails?.user_subscription?.length > 0 ? (
                  <>
                    <h2 className="text-2xl lg:text-3xl font-bold text-[#5e17eb] pb-3 capitalize text-center">
                      {
                        usersDetails?.user_subscription[0]
                          ?.user_subscription_plan_name
                      }
                    </h2>
                    <p className="text-center font-medium text-black pb-4">
                      {usersDetails?.user_subscription[0]?.paid_amt}{" "}
                      {usersDetails?.user_subscription[0]?.currency}
                    </p>

                    <h3 className="text-3xl  text-violet-700 font-bold mr-2">
                      {usersDetails?.user_subscription[0]?.plan_interval}
                    </h3>

                    <div className="mt-4">
                      <p className="text-red-600">
                        {" "}
                        Your plan will ends on: &nbsp;
                        {usersDetails?.user_subscription[0]?.plan_period_end}
                      </p>
                    </div>
                  </>
                ) : (
                  <p>No subscription plan found.</p>
                )}
              </div>
            </div>
          </div>
          <div className="flex gap-3 max-w-sm">
            {/* <button
              onClick={() => {
                handleDelete(
                  usersDetails?.user_subscription[0]?.stripe_subscription_id
                );
              }}
              className="py-2.5 px-6 rounded-lg text-sm font-medium bg-red-200 text-teal-800 mb-2 mt-2"
            >
              Cancel Plan
            </button> */}
          </div>
        </div>
      </div>
    </>
  );
};
export default Myplan;
