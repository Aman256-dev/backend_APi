import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../store/api";
import errorHandler from "../store/errorHandler";

export const upload_pdf = createAsyncThunk(
    'upload_pdfs',
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post('/user/extract-questions', userInput);
            console.log("response: ", response);
            if (response?.data?.status_type === 200) {
                return response.data;
            } else {
                return rejectWithValue(response.data);
            }
        } catch (err) {
            let errors = errorHandler(err);
            return rejectWithValue(errors);
        }
    }
)
export const getUploadedPdf = createAsyncThunk(
    'get_uploaded_pdf',
    async (entity, { rejectWithValue }) => {
        try {
            const response = await api.post('/get-pdf', entity);
            console.log("Response: ", response);
            if (response?.data?.status === true) {
                return response?.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }
)
export const viewPdf = createAsyncThunk(
    'view_pdf',
    async (entity, { rejectWithValue }) => {
        try {
            const response = await api.post(`/view-pdf`, entity);
            console.log("Response: ", response);
            if (response?.data?.status === true) {
                return response?.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }
)


export const downloadedPdf = createAsyncThunk(
    'view_uploaded_pdf',
    async (id, { rejectWithValue }) => {
        try {
            const response = await api.get(`download-pdf/${id}`, {
                responseType: 'blob'  // This is important to get binary data
            });
            if (response?.status === 200) {
                return response?.data; // This is the Blob data
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }
);

//QA Generator
export const downloadWord = createAsyncThunk(
    'download_word',
    async (id, { rejectWithValue }) => {
        try {

            console.log("id: ", id);


            const response = await api.get(`/user/download-word?question_id=${id}`);
            console.log("response: ", response);
            if (response?.status === 200) {
                return response.data;
            } else {
                return rejectWithValue(response.data);
            }
        } catch (err) {
            let errors = errorHandler(err);
            return rejectWithValue(errors);
        }
    }
)



export const downloadCsv = createAsyncThunk(
    'download_csv',
    async (id, { rejectWithValue }) => {
        try {


            const response = await api.get(`/user/download-csv?question_id=${id}`);
            console.log("response: ", response);
            if (response?.status === 200) {
                return response.data;
            } else {
                return rejectWithValue(response.data);
            }
        } catch (err) {
            let errors = errorHandler(err);
            return rejectWithValue(errors);
        }
    }
)
const initialState = {
    loading: false,
    loadingupload: false,
    error: null,
    message: "",
    pdfData: [],
    questionResponse: [],
    downloadWordData: {},
    downloadPdfData: [],
    viewPdfData: [],
    downloadCsvData: []
}
const UploadPdfSlice = createSlice(
    {
        name: 'pdf_upload',
        initialState,
        reducers: {},
        extraReducers: (builder) => {
            builder
                .addCase(upload_pdf.pending, (state) => {
                    state.loadingupload = true
                })
                .addCase(upload_pdf.fulfilled, (state, { payload }) => {
                    state.loadingupload = false
                    state.questionResponse = payload
                    state.error = null
                })
                .addCase(upload_pdf.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loadingupload = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
                .addCase(getUploadedPdf.pending, (state) => {
                    state.loading = true
                })
                .addCase(getUploadedPdf.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.pdfData = payload
                    state.error = null
                })
                .addCase(getUploadedPdf.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
                .addCase(downloadedPdf.pending, (state) => {
                    state.loading = true
                })
                .addCase(downloadedPdf.fulfilled, (state, { payload }) => {
                    console.log("payload", payload);
                    state.loading = false
                    state.downloadPdfData = payload

                    state.error = null
                })
                .addCase(downloadedPdf.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
                .addCase(viewPdf.pending, (state) => {
                    state.loading = true
                })
                .addCase(viewPdf.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.viewPdfData = payload
                    state.error = null
                })
                .addCase(viewPdf.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
                .addCase(downloadWord.pending, (state) => {
                    state.loading = true
                })
                .addCase(downloadWord.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.downloadWordData = payload
                    state.error = null
                })
                .addCase(downloadWord.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
                .addCase(downloadCsv.pending, (state) => {
                    state.loading = true
                })
                .addCase(downloadCsv.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.downloadCsvData = payload
                    state.error
                })
                .addCase(downloadCsv.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
        }
    }
)
export default UploadPdfSlice.reducer