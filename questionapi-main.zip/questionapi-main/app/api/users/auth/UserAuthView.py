from rest_framework.decorators import api_view,permission_classes,authentication_classes
from rest_framework.response import Response
from app.models.users import User
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth import authenticate
from datetime import datetime
from rest_framework_simplejwt.tokens import RefreshToken
import requests
from rest_framework import status
from app.validations.serializers import *
import base64
import json
from django.core.mail import send_mail
from django.conf import settings
from django.template.loader import render_to_string
@api_view(['POST'])
def sign_up(request):
    data=request.data
    serilizer=UserSerializer(data=request.data)
    if not serilizer.is_valid():
        return Response({
            'status':False,
            'message':'Validation error',
            'errors':serilizer.errors,
            'status_code':status.HTTP_400_BAD_REQUEST
        })
    fname=request.data.get('first_name',None)
    lname = request.data.get('last_name', None)
    uname = request.data.get('username',None)
    email = request.data.get('email', None)
    password = request.data.get('password', None)
    confirm_password = request.data.get('confirm_password', None)
    chk=User.objects.filter(email=email).count()
    chk_uname=User.objects.filter(username=uname).count()
    if(chk==0):
        if(chk_uname==0):
            if password==confirm_password:
                hash_pwd=make_password(password)
                user=User.objects.create(
                    first_name=fname,
                    last_name=lname,
                    username=uname,
                    email=email,
                    password=hash_pwd,
                    user_type_id=2,
                    status=1,
                    is_deleted=0
                )
                return Response({
                    'status':True,
                    'message':'Thank you for registering with us',
                    'status_code':status.HTTP_201_CREATED
                },status.HTTP_201_CREATED)
            else:
                return Response({
                    'status': False,
                    'message': 'Passwords do not match. Please try again.',
                    'status_code': status.HTTP_400_BAD_REQUEST
                }, status.HTTP_400_BAD_REQUEST)
        else:
            return Response({
                'status': False,
                'message': 'This username already exists, please use another username',
                'status_code': status.HTTP_400_BAD_REQUEST
            }, status.HTTP_400_BAD_REQUEST)
    else:
        return Response({
            'status': False,
            'message': 'This email already exists, please use another email',
            'status_code': status.HTTP_400_BAD_REQUEST
        }, status.HTTP_400_BAD_REQUEST)



@api_view(['POST'])
def login(request):
    data=request.data
    serializer=UserLoginSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            'status': False,
            'message': 'Validation error',
            'errors': serializer.errors,
            'status_code': status.HTTP_400_BAD_REQUEST
        })
    username=request.data.get('username',None)
    password=request.data.get('password',None)
    # if username and '@' in username:
    #     ud=User.objects.filter(email=username).get()
    #     user_id=ud.id
    #     user=User.objects.filter(id=user_id).get()
    #     uname=user.username
    # else:
    #     uname=username
    uname=username
    chk=User.objects.filter(username=uname,status=1,is_deleted=0).count()
    if chk>0:
        user=authenticate(username=uname,password=password)
        # dd(user)
        if user is not None:
            refresh=RefreshToken.for_user(user)

            return Response({
                'status':True,
                'message':'',
                'access_token':str(refresh.access_token),
                'email': user.email,
                'user_id': user.id,
                'user_type':user.user_type_id,
                'subject_id':user.subject_id,
                'subject':user.subject.subject_name,
                'first_name': user.first_name,
                'status_code':status.HTTP_200_OK
            },status.HTTP_200_OK)
        else:
            return Response({
                'status': False,
                'message': 'Invalid Credentials',
                'status_code': status.HTTP_400_BAD_REQUEST
            }, status.HTTP_400_BAD_REQUEST)
    else:
        return Response({
            'status': False,
            'message': 'Invalid Credentials',
            'status_code': status.HTTP_400_BAD_REQUEST
        }, status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
def create_password(request):
    data=request.data
    serializer=PasswordSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            'status': False,
            'message': 'Validation error',
            'errors': serializer.errors,
            'status_code': status.HTTP_400_BAD_REQUEST
    })
    user_id=request.data.get('user_id',None)
    password=request.data.get('password',None)
    confirm_password=request.data.get('confirm_password',None)
    chk=User.objects.filter(id=user_id).count()
    if chk>0:
        if password==confirm_password:
            user=User.objects.get(id=user_id)
            password=make_password(password)
            user.password=password
            user.save()
            msg='Password has been created successfully'
            stats_code=status.HTTP_200_OK
            st=True
        else:
            msg='Password and confirm password does not match'
            stats_code=status.HTTP_400_BAD_REQUEST
            st = True
    else:
        msg='No users found'
        stats_code=status.HTTP_400_BAD_REQUEST
        st = True

    return Response({
        'status':st,
        'message':msg,
        'status_code':stats_code
    },stats_code)

@api_view(['POST'])
def forget_password(request):
    data = request.data
    serializer = ForgetPasswordSerializer(data=request.data)
    if not serializer.is_valid():
            return Response({
                'status': False,
                'message': 'Validation error',
                'errors': serializer.errors,
                'status_code': status.HTTP_400_BAD_REQUEST
    }, status.HTTP_400_BAD_REQUEST)
    email=request.data.get('email')
    base_url = request.data.get('base_url')
    chk = User.objects.filter(email=email).count()
    if(chk>0):
        get_ud=User.objects.filter(email=email).get()
        user_id=get_ud.id
        time = datetime.now()
        str_time = time.strftime('%Y-%m-%d %H:%M:%S')
        secret_data = {
            'user_id': user_id,
            'time': str_time
        }
        fname=get_ud.first_name
        json_data = json.dumps(secret_data)
        token = base64.b64encode(json_data.encode('utf-8')).decode('utf-8')
        link_url = f'{base_url}/user/reset-password/{token}'
        subject = "Reset Your Password"
        from_email = settings.EMAIL_HOST_USER
        html_template = render_to_string('reset_password.html', {'link_url': link_url, 'fname': fname})
        send_mail(subject, '', from_email, [email], fail_silently=False, html_message=html_template)
        return Response({
            'status': True,
            'message': 'Your reset password link has been sent to your registered email address. Please check your mail.',
            'status_code': status.HTTP_200_OK
        }, status.HTTP_200_OK)
    else:
        return Response({
            'status': False,
            'message': 'Invalid email id',
            'status_code': status.HTTP_400_BAD_REQUEST
        }, status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])  
def reset_password(request):
    data=request.data
    serializer=PasswordSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            'status': False,
            'message': 'Validation error',
            'errors': serializer.errors,
            'status_code': status.HTTP_400_BAD_REQUEST
    })
    user_id=request.data.get('user_id',None)
    password=request.data.get('password',None)
    confirm_password=request.data.get('confirm_password',None)
    chk=User.objects.filter(id=user_id).count()
    if chk>0:
        if password==confirm_password:
            user=User.objects.get(id=user_id)
            password=make_password(password)
            user.password=password
            user.save()
            msg='Password has been changed successfully'
            stats_code=status.HTTP_200_OK
            st=True
        else:
            msg='Password and confirm password does not match'
            stats_code=status.HTTP_400_BAD_REQUEST
            st = True
    else:
        msg='No users found'
        stats_code=status.HTTP_400_BAD_REQUEST
        st = True

    return Response({
        'status':st,
        'message':msg,
        'status_code':stats_code
    },stats_code)