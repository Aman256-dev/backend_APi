import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../store/api";
import errorHandler from "../store/errorHandler";

export const getSubjects = createAsyncThunk(
    'getSubjects',
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.get('/user/subjects');
            if (response?.data?.status_code === 200) {
                return response?.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }

    }
)

export const uploadPdf = createAsyncThunk(
    'uploadPdf',
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post('/user/pdf-question', userInput);
            if (response?.status === 200) {
                return response.data;
            } else {
                return rejectWithValue(response.data);
            }
        } catch (err) {
            let errors = errorHandler(err);
            return rejectWithValue(errors);
        }
    }
)

export const downloadDoc = createAsyncThunk(
    'downloadDoc',
    async (question_id, { rejectWithValue }) => {
        try {
            const response = await api.get(`/user/download-docx-pdf?question_id=${question_id}`);
            if (response?.status === 200) {
                return response.data;
            } else {
                return rejectWithValue(response.data);
            }
        } catch (err) {
            let errors = errorHandler(err);
            return rejectWithValue(errors);
        }
    }
)

export const downloadCsv = createAsyncThunk(
    'downloadCsv',
    async (question_id, { rejectWithValue }) => {
        try {
            const response = await api.get(`/user/download-csv-pdf?question_id=${question_id}`);
            if (response?.status === 200) {
                return response.data;
            } else {
                return rejectWithValue(response.data);
            }
        } catch (err) {
            let errors = errorHandler(err);
            return rejectWithValue(errors);
        }
    }
)

export const uploadUrl = createAsyncThunk(
    'uploadUrl',
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post('/user/url-question', userInput);
            if (response?.status === 200) {
                return response.data;
            } else {
                return rejectWithValue(response.data);
            }
        } catch (err) {
            let errors = errorHandler(err);
            return rejectWithValue(errors);
        }
    }
)


export const getAllSubPrompt = createAsyncThunk(
    "getAllSubPrompt",
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.get('/admin/all-subjects-prompt');
            if (response?.data?.status_code === 200) {

                return response?.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }

)

export const addPrompt = createAsyncThunk(
    "addPrompt",
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post('/admin/add-subject-with-prompt', userInput);
            if (response?.data?.status_code === 201) {

                return response?.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }
)

export const getSinglePromp = createAsyncThunk(
    "getSinglePrompt",
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post('/admin/edit-prompt-pdfandurl', userInput);
            console.log("Response", response?.data);
            if (response?.data?.status_code === 200) {

                return response?.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }
)

export const updatePrompt = createAsyncThunk(
    "updatePrompt",
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post('/admin/update-prompt-pdfandurl', userInput);
            if (response?.data?.status_code === 200) {
                return response?.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }
)


const initialState = {
    loading: false,
    message: "",
    subjects: [],
    loadingupload: false,
    pdfResponse: {},
    loadingDoc: false,
    downloadDocData: {},
    loadingCsv: false,
    downloadCsvData: {},
    loadinguploadUrl: false,
    urlResponse: {},
    allSubPrompt: [],
    loadingAddPrompt: false,
    singlePrompt: {},
    loadingPromptUpdate: false,
};

const PdfAndUrlSlice = createSlice(
    {
        name: 'pdfAndUrl',
        initialState,
        reducers: {
            resetPDFandURL: (state) => {
                state.pdfResponse = {};
                state.urlResponse = {};
            },
        },
        extraReducers: (builder) => {
            builder

                .addCase(getSubjects.pending, (state) => {
                    state.loading = true
                })
                .addCase(getSubjects.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.subjects = payload
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
                .addCase(getSubjects.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })

                .addCase(uploadPdf.pending, (state) => {
                    state.loadingupload = true
                })
                .addCase(uploadPdf.fulfilled, (state, { payload }) => {
                    state.loadingupload = false
                    state.pdfResponse = payload
                    state.error = null
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
                .addCase(uploadPdf.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loadingupload = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })

                .addCase(downloadDoc.pending, (state) => {
                    state.loadingDoc = true
                })
                .addCase(downloadDoc.fulfilled, (state, { payload }) => {
                    state.loadingDoc = false
                    state.downloadDocData = payload
                    state.error = null
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
                .addCase(downloadDoc.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loadingDoc = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })

                .addCase(downloadCsv.pending, (state) => {
                    state.loadingCsv = true
                })
                .addCase(downloadCsv.fulfilled, (state, { payload }) => {
                    state.loadingCsv = false
                    state.downloadCsvData = payload
                    state.error = null
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
                .addCase(downloadCsv.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loadingCsv = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })

                .addCase(uploadUrl.pending, (state) => {
                    state.loadinguploadUrl = true
                })
                .addCase(uploadUrl.fulfilled, (state, { payload }) => {
                    state.loadinguploadUrl = false
                    state.urlResponse = payload
                    state.error = null
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
                .addCase(uploadUrl.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loadinguploadUrl = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })

                .addCase(getAllSubPrompt.pending, (state) => {
                    state.loading = true;
                })
                .addCase(getAllSubPrompt.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.allSubPrompt = payload?.subjects
                    state.error = false
                })
                .addCase(getAllSubPrompt.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })

                .addCase(addPrompt.pending, (state) => {
                    state.loadingAddPrompt = true
                })
                .addCase(addPrompt.fulfilled, (state, { payload }) => {
                    state.loadingAddPrompt = false
                    state.message = payload
                    state.error = false
                })
                .addCase(addPrompt.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loadingAddPrompt = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })

                .addCase(getSinglePromp.pending, (state) => {
                    state.loading = true
                })
                .addCase(getSinglePromp.fulfilled, (state, { payload }) => {
                    console.log("Payload: ", payload);
                    state.loading = false
                    state.singlePrompt = payload
                    state.error = false
                })
                .addCase(getSinglePromp.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })

                .addCase(updatePrompt.pending, (state) => {
                    state.loadingPromptUpdate = true
                })
                .addCase(updatePrompt.fulfilled, (state, { payload }) => {
                    state.loadingPromptUpdate = false
                    state.message = payload
                    state.error = false
                })
                .addCase(updatePrompt.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loadingPromptUpdate = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
        }
    }
)

export const { resetPDFandURL } = PdfAndUrlSlice.actions;
export default PdfAndUrlSlice.reducer;