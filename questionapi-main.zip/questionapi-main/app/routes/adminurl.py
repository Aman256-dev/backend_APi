from django.urls import path
from app.api.admin import AdminView
from app.api.admin import PromptView
from app.api.users import urlPdfView
from app.api.admin import CsvView
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from django.conf import settings
from django.conf.urls.static import static

urlpatterns=[
    path('add-teacher',AdminView.add_user),
    path('activate-deactivate-user',AdminView.activate_deactivate_user),
    path('users-list',AdminView.users_list),
    path('delete-user',AdminView.delete_user),
    path('prompt-list',PromptView.prompt_list),
    path('edit-prompt',PromptView.edit_prompt),
    path('update-prompt',PromptView.update_prompt),
    path('get-subject-list',AdminView.get_subject),
    path('edit-prompt-pdfandurl',urlPdfView.edit_prompt),
    path('update-prompt-pdfandurl',urlPdfView.update_prompt),
    path('add-subject-with-prompt',urlPdfView.add_subject_with_prompt),
    path('all-subjects-prompt',urlPdfView.get_all_subjects_with_prompt),

    path('upload-csv',CsvView.upload_csv),
    path('add-csv-prompt',CsvView.add_csv_prompt),
    path('edit-csv-prompt',CsvView.edit_prompt),
    path('update-csv-prompt',CsvView.update_prompt),
    path('csv-prompt-list',CsvView.get_all_prompt_name),
    path('csv-promptName-prompt',CsvView.get_all_promptName_with_prompt),

]