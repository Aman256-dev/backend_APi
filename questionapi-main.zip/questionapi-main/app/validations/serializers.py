from rest_framework import serializers
from app.models import User
class AddUserSerializer(serializers.Serializer):
    first_name = serializers.CharField(
        error_messages={
            'blank':'Please provide your first name'
        }
    )
    last_name = serializers.CharField(
        error_messages={
            'blank': 'Please provide your last name'
        }
    )
    email = serializers.EmailField()
    subject_id=serializers.IntegerField()
    base_url = serializers.CharField(
        error_messages={
            'blank': 'Please provide the base url'
        }
    )
class UserSerializer(serializers.Serializer):
    first_name = serializers.CharField(
        error_messages={
            'blank':'Please provide your first name'
        }
    )
    last_name = serializers.CharField(
        error_messages={
            'blank': 'Please provide your last name'
        }
    )
    username = serializers.CharField(
        error_messages={
            'blank': 'Please provide your username'
        }
    )
    email = serializers.EmailField()
    password = serializers.CharField(
        error_messages={
            'blank': 'Password cannot be left blank!'
        }
    )
    confirm_password = serializers.CharField(
        error_messages={
            'blank': 'Confirm password cannot be left blank!'
        }
    )

class UserLoginSerializer(serializers.Serializer):
    username=serializers.CharField()
    password=serializers.CharField()

class UserIdSerializer(serializers.Serializer):
    id=serializers.IntegerField()

class PasswordSerializer(serializers.Serializer):
    user_id=serializers.IntegerField()
    password=serializers.CharField()
    confirm_password=serializers.CharField()

class ProjectSerializer(serializers.Serializer):
    project_name=serializers.CharField()
    requirement=serializers.CharField()
    deadline=serializers.DateField()
    priority_id=serializers.IntegerField()
    sdlc_methodology=serializers.IntegerField()

class UpdateUserSerializer(serializers.Serializer):
    first_name = serializers.CharField(
        error_messages={
            'blank':'Please provide your first name'
        }
    )
    last_name = serializers.CharField(
        error_messages={
            'blank': 'Please provide your last name'
        }
    )
    email = serializers.EmailField()
    user_type_id=serializers.IntegerField()
    user_id=serializers.IntegerField()

class EmailSerializer(serializers.Serializer):
    email=serializers.EmailField()

class ProjectMemberSerializer(serializers.Serializer):
    project_id=serializers.IntegerField()
    # employee_id=serializers.IntegerField()

class SimpleUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'first_name', 'last_name', 'email', 'avatar', 'status']



class ProjectOverviewSerializer(serializers.Serializer):
    project_id=serializers.IntegerField()


class UserProjectOverviewSerializer(serializers.Serializer):
    user_id=serializers.IntegerField()
    user_type_id=serializers.IntegerField()

class ProjectUserSerializer(serializers.Serializer):
    project_id=serializers.IntegerField()
    user_type_id=serializers.IntegerField()

class ProjectTaskSerializer(serializers.Serializer):
    project_id=serializers.IntegerField()
    task_name=serializers.CharField()
    deadline=serializers.DateField()

class TaskSerializer(serializers.Serializer):
    user_id=serializers.IntegerField()
    user_type_id=serializers.IntegerField()

class TaskStatusSerializer(serializers.Serializer):
    task_id=serializers.IntegerField()
    entity=serializers.CharField()

class AddProjectUpdateSerializer(serializers.Serializer):
    project_id=serializers.IntegerField()
    is_important=serializers.IntegerField()

class UpdateTaskSerializer(serializers.Serializer):
    is_important = serializers.IntegerField()
    task_id=serializers.IntegerField()


class UpdateUserSerializer(serializers.Serializer):
    first_name=serializers.CharField()
    last_name=serializers.CharField()
    email=serializers.EmailField()

class ProjectUpdateSerializer(serializers.Serializer):
    project_id=serializers.IntegerField()
    priority_id=serializers.IntegerField()
    project_name=serializers.CharField()

class RemoveMemberSerializer(serializers.Serializer):
    project_id=serializers.IntegerField()
    user_id=serializers.IntegerField()

class DeleteAccountSerializer(serializers.Serializer):
    user_id=serializers.IntegerField()
    user_type_id=serializers.IntegerField()

class UpdateTaskDescSerializer(serializers.Serializer):
    task_id=serializers.IntegerField()
    deadline=serializers.DateField()
    user_id=serializers.IntegerField()
    user_type_id=serializers.IntegerField()

class UpdateOrganisationRoleSerializer(serializers.Serializer):
    org_role_id=serializers.IntegerField()
    org_role_name=serializers.CharField()

class AddOrganisationMemberSerializer(serializers.Serializer):
    first_name=serializers.CharField()
    last_name=serializers.CharField()
    user_role_id=serializers.IntegerField()
    email=serializers.EmailField()
    org_id=serializers.IntegerField()


class UpdateOrganisationMemberSerializer(serializers.Serializer):
    user_id=serializers.IntegerField()
    first_name=serializers.CharField()
    last_name=serializers.CharField()
    email=serializers.EmailField()
    org_id=serializers.IntegerField()
    user_role_id=serializers.IntegerField()
    org_id=serializers.IntegerField()

class UserFileSerializer(serializers.Serializer):
    startString=serializers.CharField()

class PromptSerializer(serializers.Serializer):
    prompt_id=serializers.IntegerField()

class ForgetPasswordSerializer(serializers.Serializer):
    email=serializers.EmailField()
    base_url=serializers.CharField()

class pdfurlPromptSerializer(serializers.Serializer):
    prompt_id=serializers.IntegerField()

class csvPromptSerializer(serializers.Serializer):
    prompt_id=serializers.IntegerField()