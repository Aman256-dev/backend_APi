import { useForm } from "react-hook-form";
import Logo from "../../assets/images/logo.png";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { registeration } from "../../reducers/AuthSlice";
import { useState } from "react";

const Register = () => {
  const { message, loading } = useSelector((state) => state.loginAuth);
  const [errorMessage, setErrorMessage] = useState(null);
  const objToken = localStorage.getItem("accessToken");

  let token = null;
  if (objToken) {
    try {
      const parsedToken = JSON.parse(objToken);
      token = parsedToken.access_token;
    } catch (e) {
      console.error("Error parsing token:", e);
      // Handle the error as appropriate for your app
    }
  } else {
    console.warn("No access token found in localStorage");
  }
  console.log("parse Token: ", token);

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm();
  const dispatch = useDispatch();
  const nevigate = useNavigate();
  const onSubmit = (data) => {
    dispatch(registeration(data)).then((res) => {
      console.log("Res: ", res);
      if (res?.payload?.status === true) {
        nevigate("/");
      } else {
        setErrorMessage("The email has already been taken");
      }
    });
  };
  const password = watch("password");
  return (
    <>
      <section className="bg-white dark:bg-gray-900">
        <div className="flex flex-col items-center justify-center px-6 py-8 mx-auto md:h-screen lg:py-0">
          <a
            href="#"
            className="flex items-center mb-6 text-2xl font-semibold text-gray-900 dark:text-white"
          ></a>
          <div className="w-full bg-white rounded-lg shadow dark:border md:mt-0 sm:max-w-md xl:p-0 dark:bg-gray-800 dark:border-gray-700">
            <div className="p-6 space-y-4 md:space-y-6 sm:p-8">
              <h1 className="text-xl font-bold leading-tight tracking-tight text-gray-900 md:text-2xl dark:text-white">
                Register
              </h1>
              {errorMessage && (
                <div
                  className="p-4 mb-4 text-sm text-red-800 rounded-lg bg-red-50 dark:bg-gray-800 dark:text-red-400"
                  role="alert"
                >
                  <span className="font-medium">Failed! </span> {errorMessage}
                </div>
              )}
              <form
                onSubmit={handleSubmit(onSubmit)}
                className="space-y-4 md:space-y-6"
              >
                <div>
                  <label
                    htmlFor="email"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Your First Name
                  </label>
                  <input
                    type="text"
                    name="first_name"
                    id="name"
                    className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="First Name"
                    {...register("first_name", {
                      required: "First Name is required",
                    })}
                  />
                  {errors?.first_name?.message && (
                    <h6 className="text-danger">{errors.first_name.message}</h6>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="email"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Your Last Name
                  </label>
                  <input
                    type="text"
                    name="last_name"
                    id="name"
                    className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="Last Name"
                    {...register("last_name", {
                      required: "Last Name is required",
                    })}
                  />
                  {errors?.last_name?.message && (
                    <h6 className="text-danger">{errors.last_name.message}</h6>
                  )}
                </div>
                <div>
                  <label
                    htmlFor="email"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Your User Name
                  </label>
                  <input
                    type="text"
                    name="username"
                    id="name"
                    className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="User Name"
                    {...register("username", {
                      required: "User Name is required",
                    })}
                  />
                  {errors?.username?.message && (
                    <h6 className="text-danger">{errors.username.message}</h6>
                  )}
                </div>
                <div>
                  <label
                    htmlFor="email"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Your email
                  </label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="name@company.com"
                    {...register("email", { required: "Email is required" })}
                  />
                  {errors?.email?.message && (
                    <h6 className="text-danger">{errors.email.message}</h6>
                  )}
                </div>
                <div>
                  <label
                    htmlFor="password"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Password
                  </label>
                  <input
                    type="password"
                    name="password"
                    id="password"
                    placeholder="••••••••"
                    className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    {...register("password", {
                      required: "Password is required",
                    })}
                  />
                  {errors?.password?.message && (
                    <h6 className="text-danger">{errors.password.message}</h6>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="password"
                    className="block mb-2 text-sm font-medium text-gray-900 dark:text-white"
                  >
                    Confirm Password
                  </label>
                  <input
                    type="password"
                    name="confirm_password"
                    id="confirm_password"
                    placeholder="••••••••"
                    className="bg-gray-50 border border-gray-300 text-gray-900 sm:text-sm rounded-lg focus:ring-primary-600 focus:border-primary-600 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    {...register("confirm_password", {
                      required: true,
                      validate: (value) =>
                        value === password || "Password do not Match",
                    })}
                  />
                  {errors?.confirm_password?.message && (
                    <h6 className="text-red-600">
                      {errors.confirm_password.message}
                    </h6>
                  )}
                </div>

                <br />
                <Link
                  to="/"
                  className="text-[14px] text-[#4152a3] hover:text-[#ed1d24]"
                >
                  Existing User? Login
                </Link>
                {/* {<h6 className="text-red-600">{errorMessage}</h6>} */}
                <button
                  type="submit"
                  className="w-full text-white bg-[#1b3664] hover:bg-black focus:ring-4 focus:outline-none focus:ring-primary-300 font-medium rounded-lg text-base px-5 py-2.5 text-center dark:bg-primary-600 dark:hover:bg-primary-700 dark:focus:ring-primary-800"
                >
                  {loading ? "Waiting.." : "Sign Up"}
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
export default Register;
