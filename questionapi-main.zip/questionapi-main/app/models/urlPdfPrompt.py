from django.db import models

class UrlPdfPrompt(models.Model):
    subject=models.CharField(max_length=255)
    prompt=models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)