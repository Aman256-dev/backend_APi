from PIL import Image
import pytesseract

def extract_text_from_image(image_path):
    # Open the image file
    image = Image.open(image_path)

    # Use Tesseract to do OCR on the image
    text = pytesseract.image_to_string(image)

    return text

p = extract_text_from_image("ook.png")
print(p)