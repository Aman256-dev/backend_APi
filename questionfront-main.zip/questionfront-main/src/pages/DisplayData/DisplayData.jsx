import { FileInput, Label, Modal, Table } from "flowbite-react";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { upload_csv } from "../../reducers/UploadCsvSlice";
import { getUserInfo } from "../../reducers/UserInfoSlice";
import { HiPencil } from "react-icons/hi2";
import {
  active_deactive_info,
  getUserData,
  updateUser,
} from "../../reducers/UserUpdateSlice";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const DisplayData = () => {
  const [updateModal, setUpdateModal] = useState(false);
  const { loading } = useSelector((state) => state?.upld_csv);
  const dispatch = useDispatch();
  const { infoList } = useSelector((state) => state?.info);
  const { getUpdateUser } = useSelector((state) => state?.updates);
  const [info_id, setInfoId] = useState(null);
  const [userStatus, setUserStatus] = useState("");
  useEffect(() => {
    dispatch(getUserInfo());
  }, [dispatch]);
  console.log("UserInfolist: ", infoList?.results?.info_lists);
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors },
    reset,
  } = useForm();

  const {
    register: register1,
    setValue,
    handleSubmit: handleSubmit1,
    formState: { errors: errors1 },
  } = useForm();

  const onSubmit = (data) => {
    const formdata = new FormData();
    formdata.append("csv_file", data?.csv_file[0]);
    dispatch(upload_csv(formdata)).then((res) => {
      console.log("rescsv", res);
      if (res?.payload?.status === true) {
        toast.success(res?.payload?.msg, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          progress: undefined,
          theme: "light",
        });
        dispatch(getUserInfo());
      } else {
        toast.error(res?.payload?.response?.data?.msg, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          progress: undefined,
          theme: "dark",
        });
      }
    });
  };
  const updateHandler = (info_id) => {
    console.log("info_id", info_id);
    setUpdateModal(true);

    dispatch(getUserData(info_id)).then((res) => {
      console.log("res", res);
      const users = res?.payload?.results;
      console.log("users", users);
      setValue("info_id", users?.id);
      setValue("first_name", users?.first_name);
      setValue("last_name", users?.last_name);
      setValue("active_member", users?.active_member);
      setValue("company_name", users?.company_name);
      setValue("address_1", users?.address_1);
      setValue("address_2", users?.address_2);
      setValue("city", users?.city);
      setValue("state", users?.state);
      setValue("postal_code", users?.postal_code);
      setValue("phone_no", users?.phone_no);
      setValue("email", users?.email);
      setInfoId(users?.id);
      setUserStatus(users?.active_member);
      console.log("Active_member", users?.active_member);
    });
    // setUpdateModal(true);
  };
  console.log("currentStatusbefore", userStatus);
  const handleToggleStatus = (info_id, currentStatus) => {
    const newStatus = currentStatus === "No" ? "Yes" : "No";

    dispatch(active_deactive_info({ info_id, status: newStatus })).then(
      (res) => {
        console.log("Act_deact: ", res);
        if (res?.payload?.status === true) {
          setUserStatus(newStatus);
        }
      }
    );
    console.log("newStatus", newStatus);
    console.log("info id: ", info_id);
    console.log("currentStatus", currentStatus);
  };
  const handleUpdateUser = (data) => {
    data.active_member = data.active_member ? "Yes" : "No";
    dispatch(updateUser(data)).then((res) => {
      console.log("update: ", res);
      if (res?.payload?.status === true) {
        toast.success(res?.payload?.msg, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          progress: undefined,
          theme: "light",
        });
        setUpdateModal(false);
        dispatch(getUserInfo());
      } else {
        toast.error("Please upload only csv file", {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          progress: undefined,
          theme: "light",
        });
      }
    });
  };
  return (
    <>
      <ToastContainer />
      <div className="container mx-auto p-4 text-black">
        <h1 className="text-2xl font-semibold mb-4">Display Data</h1>

        <div className="flex justify-between items-center mb-6">
          <div>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="flex items-center justify-center">
                <div className="upload_data_area">
                  <div className="mb-2 block">
                    <Label className="text-base" value="Upload file" />
                  </div>
                  <FileInput
                    id="file-upload"
                    {...register("csv_file", { required: "File is required" })}
                  />
                </div>

                <button
                  type="submit"
                  className="bg-[#029962] px-4 py-2 text-white rounded-md mt-7 ml-1"
                >
                  {loading ? "Waiting.." : "Parse"}
                </button>
                {errors.csv_file && (
                  <span className="text-red-500">
                    {errors.csv_file.message}
                  </span>
                )}
              </div>
            </form>
          </div>
          <div>
            <form className="flex items-center max-w-sm mx-auto">
              <div className="relative w-full">
                <input
                  type="text"
                  id="simple-search"
                  className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full ps-4 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  placeholder="Search..."
                  required
                />
              </div>
              <button
                type="submit"
                className="p-2.5 ms-2 text-sm font-medium text-white bg-blue-700 rounded-lg border border-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
              >
                <svg
                  className="w-4 h-4"
                  aria-hidden="true"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 20 20"
                >
                  <path
                    stroke="currentColor"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"
                  />
                </svg>
                <span className="sr-only">Search</span>
              </button>
            </form>
          </div>
        </div>

        <div className="overflow-x-auto">
          <Table striped>
            <Table.Head>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Actions
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Company
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                First Name
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Last Name
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Active Member
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Address 1
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Address 2
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                City
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                State
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Postal Code
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Email
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Phone No
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Membership Ends
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Membership Number
              </Table.HeadCell>
            </Table.Head>
            <Table.Body className="divide-y">
              {infoList?.results?.info_lists?.map((uInfo) => {
                return (
                  <>
                    <Table.Row className="bg-white dark:border-gray-700 dark:bg-gray-800">
                      <Table.Cell className="flex items-center justify-start">
                        <div className="mr-10">
                          <button onClick={() => updateHandler(uInfo?.info_id)}>
                            <HiPencil />
                          </button>
                        </div>
                        {/* <button className="text-[#ea5c65] hover:text-black">
                          dsdsd
                        </button> */}
                      </Table.Cell>
                      <Table.Cell className="font-bold">
                        {uInfo?.company_name}
                      </Table.Cell>
                      <Table.Cell className="font-bold">
                        {uInfo?.first_name}
                      </Table.Cell>
                      <Table.Cell className="font-bold">
                        {uInfo?.last_name}
                      </Table.Cell>
                      <Table.Cell>{uInfo?.active_member}</Table.Cell>
                      <Table.Cell>{uInfo?.address_1}</Table.Cell>
                      <Table.Cell>{uInfo?.address_2}</Table.Cell>
                      <Table.Cell>{uInfo?.city}</Table.Cell>
                      <Table.Cell>{uInfo?.state}</Table.Cell>
                      <Table.Cell>{uInfo?.postal_code}</Table.Cell>
                      <Table.Cell>{uInfo?.email}</Table.Cell>
                      <Table.Cell>{uInfo?.phone_no}</Table.Cell>
                      <Table.Cell>{uInfo?.membership_end_date}</Table.Cell>
                      <Table.Cell>{uInfo?.membership_number}</Table.Cell>
                    </Table.Row>
                  </>
                );
              })}
            </Table.Body>
          </Table>
        </div>
        <Modal
          size="lg"
          show={updateModal}
          onClose={() => setUpdateModal(false)}
        >
          <Modal.Header className="border-0 absolute right-[20px] top-[20px]">
            &nbsp;
          </Modal.Header>
          <Modal.Body className="pt-10">
            <div className="px-3 pb-4">
              <form
                onSubmit={handleSubmit1(handleUpdateUser)}
                className="w-full gap-4"
              >
                <div className="flex  gap-4">
                  <div className="mb-2">
                    <div className="mb-2 block">
                      <Label htmlFor="email1" value="First Name" />
                    </div>
                    <input
                      className="bg-white border border-[#009BF2] text-[#888888] text-sm rounded-lg focus:ring-[#009BF2] focus:border-[#009BF2] block w-full py-3 px-3"
                      type="text"
                      placeholder="First Name"
                      {...register1("first_name")}
                    />
                  </div>
                  <div className="mb-2">
                    <div className="mb-2 block">
                      <Label htmlFor="email1" value="Last Name" />
                    </div>
                    <input
                      className="bg-white border border-[#009BF2] text-[#888888] text-sm rounded-lg focus:ring-[#009BF2] focus:border-[#009BF2] block w-full py-3 px-3"
                      type="text"
                      placeholder="Last Name"
                      {...register1("last_name")}
                    />
                  </div>
                </div>
                <div className="flex gap-10">
                  <div className="mr-8 mb-2">
                    <div className="mb-2 block">
                      <Label htmlFor="email1" value="Active User" />
                    </div>
                    <div className="mr-11">
                      <label className="inline-flex items-center cursor-pointer">
                        {console.log("userStatus", userStatus)}
                        <input
                          type="checkbox"
                          {...register1("active_member")}
                          // value={userStatus}
                          checked={userStatus !== "No"}
                          onChange={() => {
                            handleToggleStatus(info_id, userStatus);
                          }}
                          className="sr-only peer"
                        />
                        <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                      </label>
                    </div>
                  </div>

                  <div className=" ml-11 mb-2">
                    <div className="mb-2 block">
                      <Label htmlFor="email1" value="Company Name" />
                    </div>
                    <input
                      className="bg-white border border-[#009BF2] text-[#888888] text-sm rounded-lg focus:ring-[#009BF2] focus:border-[#009BF2] block w-full py-3 px-3"
                      type="text"
                      placeholder="Company Name"
                      {...register1("company_name")}
                    />
                  </div>
                </div>

                <div className="flex  gap-4">
                  <div className="mb-2">
                    <div className="mb-2 block">
                      <Label htmlFor="email1" value="Address 1" />
                    </div>
                    <input
                      className="bg-white border border-[#009BF2] text-[#888888] text-sm rounded-lg focus:ring-[#009BF2] focus:border-[#009BF2] block w-full py-3 px-3"
                      type="text"
                      placeholder="Address 1"
                      {...register1("address_1")}
                    />
                  </div>
                  <div className="mb-2">
                    <div className="mb-2 block">
                      <Label htmlFor="email1" value="Address 2" />
                    </div>
                    <input
                      className="bg-white border border-[#009BF2] text-[#888888] text-sm rounded-lg focus:ring-[#009BF2] focus:border-[#009BF2] block w-full py-3 px-3"
                      type="text"
                      placeholder="Address 2"
                      {...register1("address_2")}
                    />
                  </div>
                </div>

                <div className="flex  gap-4">
                  <div className="mb-2">
                    <div className="mb-2 block">
                      <Label htmlFor="email1" value="City" />
                    </div>
                    <input
                      className="bg-white border border-[#009BF2] text-[#888888] text-sm rounded-lg focus:ring-[#009BF2] focus:border-[#009BF2] block w-full py-3 px-3"
                      type="text"
                      placeholder="City"
                      {...register1("city", { required: true })}
                    />
                  </div>
                  <div className="mb-2">
                    <div className="mb-2 block">
                      <Label htmlFor="email1" value="State" />
                    </div>
                    <input
                      className="bg-white border border-[#009BF2] text-[#888888] text-sm rounded-lg focus:ring-[#009BF2] focus:border-[#009BF2] block w-full py-3 px-3"
                      type="text"
                      placeholder="State"
                      {...register1("state", { required: true })}
                    />
                  </div>
                </div>

                <div className="flex  gap-4">
                  <div className="mb-2">
                    <div className="mb-2 block">
                      <Label htmlFor="email1" value="Postal Code" />
                    </div>
                    <input
                      className="bg-white border border-[#009BF2] text-[#888888] text-sm rounded-lg focus:ring-[#009BF2] focus:border-[#009BF2] block w-full py-3 px-3"
                      type="text"
                      placeholder="Postal Code"
                      {...register1("postal_code")}
                    />
                  </div>
                  <div className="mb-2">
                    <div className="mb-2 block">
                      <Label htmlFor="email1" value="Phone" />
                    </div>
                    <input
                      className="bg-white border border-[#009BF2] text-[#888888] text-sm rounded-lg focus:ring-[#009BF2] focus:border-[#009BF2] block w-full py-3 px-3"
                      type="text"
                      placeholder="Phone"
                      {...register1("phone_no")}
                    />
                  </div>
                </div>
                <div className="mb-2">
                  <div className="mb-2 block">
                    <Label htmlFor="email1" value="Your email" />
                  </div>
                  <input
                    className="bg-white border border-[#009BF2] text-[#888888] text-sm rounded-lg focus:ring-[#009BF2] focus:border-[#009BF2] block w-full py-3 px-3"
                    type="email"
                    placeholder="Your email"
                    {...register1("email", { required: true })}
                  />
                </div>

                <button
                  type="submit"
                  className="bg-[#009BF2] w-full rounded-lg text-center text-base py-2.5 font-medium text-white hover:bg-black mt-3"
                >
                  Update User details
                </button>
              </form>
            </div>
          </Modal.Body>
        </Modal>
      </div>
    </>
  );
};

export default DisplayData;
