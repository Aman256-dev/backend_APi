import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../store/api";


export const getUsersType = createAsyncThunk(
    'users/getUsersType',
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.get('/get-user-type');

            if (response?.data?.status === true) {
                return response.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }
)
const initialState = {
    userTypes: [],
    loading: false,
    error: ""
}
const UserTypeSlice = createSlice(
    {
        name: 'usersType',
        initialState,
        reducers: {},
        extraReducers: (builder) => {
            builder.addCase(getUsersType.pending, (state) => {
                state.loading = true
            })
                .addCase(getUsersType.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.userTypes = payload
                    state.error = ""
                })
                .addCase(getUsersType.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
        }
    }
)
export default UserTypeSlice.reducer;