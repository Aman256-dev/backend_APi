import { Elements } from "@stripe/react-stripe-js";
import payment_icon from "../assets/images/payment_icon.jpg";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { useLocation } from "react-router-dom";
import CheckOutForm from "./CheckOutForm";
import { loadStripe } from "@stripe/stripe-js";
import HeaderContent from "../components/layout/HeaderContent";
const PaymentPage = () => {
  const [stripePromise, setStripePromise] = useState(null);
  const [options, setOptions] = useState(null);

  const { stripeKey, clientSecret, customer_id, subscription_id } = useSelector(
    (state) => state?.subs
  );
  console.log("stripeKey: ", stripeKey);
  console.log("clientSecret", clientSecret);
  console.log("customer_id", customer_id);
  console.log("subscription_id", subscription_id);
  const location = useLocation();
  let plan_id;
  let user_id;
  if (location?.state?.plan_id && location?.state?.user_id) {
    plan_id = location?.state?.plan_id;
    user_id = location?.state?.user_id;
  }
  console.log("User _id", user_id);
  console.log("Plan _id", plan_id);
  useEffect(() => {
    const promise = loadStripe(stripeKey);
    setStripePromise(promise);
    const stripe_options = {
      clientSecret: clientSecret,
    };
    setOptions(stripe_options);
  }, []);

  return (
    <>
      <HeaderContent />
      <div className="py-10 lg:py-24 px-8 lg:px-0">
        <div className="max-w-7xl mx-auto">
          <h2 className="font-Bebas text-4xl md:text-5xl tracking-normal text-center mb-4 text-[#232a34]">
            Payment
          </h2>
          <div className="plan_tab_area">
            <div className="px-4 lg:px-0">
              <div className="w-full max-w-4xl p-6 mx-auto my-0 shadow-xl bg-[#2aa9e1] rounded-2xl lg:p-10">
                <div className="container mx-auto my-0">
                  <div className="md:flex">
                    <div className="w-2/5 flex justify-center items-center">
                      <div className="hidden lg:block">
                        <div className="text-center">
                          <img
                            src={payment_icon}
                            alt="paymentIcon"
                            className="rounded-xl w-64"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="w-full lg:w-3/5">
                      <div className="register_cont">
                        <h2 className="font-Bebas py-5 text-4xl tracking-normal mb-5 text-center text-white">
                          Make Payment
                        </h2>
                        <div className="stripe-error text-red-600">
                          {/* {errorMessage} */}
                        </div>
                        {stripeKey &&
                          customer_id &&
                          subscription_id &&
                          plan_id &&
                          user_id && (
                            <>
                              <Elements
                                stripe={stripePromise}
                                options={options}
                              >
                                <CheckOutForm
                                  customer_id={customer_id}
                                  subscription_id={subscription_id}
                                  plan_id={plan_id}
                                  user_id={user_id}
                                />
                              </Elements>
                            </>
                          )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default PaymentPage;
