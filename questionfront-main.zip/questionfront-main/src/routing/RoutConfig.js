import CreatePassword from "../pages/AddUser/CreatePassword";
import OutsideLayout from "../UI/layout/OutsideLayout";

const allRoutes = [
    {
        path: '/activate-account/:id',
        element: <OutsideLayout />,
        children: [
            { index: true, element: <CreatePassword /> },
            { path: '/activate-account/:id', element: <CreatePassword /> },
        ],
    },


    {
        path: '*',
        element: 'Outside page not found',
    },
];
export default allRoutes;