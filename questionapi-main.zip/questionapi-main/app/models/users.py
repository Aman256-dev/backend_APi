from django.db import models
from django.contrib.auth.models import AbstractUser
from .userType import UserType
from .subject import Subject
class User(AbstractUser):
    user_type = models.ForeignKey(UserType, on_delete=models.CASCADE)
    username = models.CharField(max_length=255,unique=True)
    password = models.CharField(max_length=255)
    first_name = models.CharField(max_length=255,null=True)
    last_name = models.CharField(max_length=255, null=True)
    email = models.EmailField(max_length=100,unique=True)
    avatar = models.CharField(max_length=255,null=True)
    otp=models.IntegerField(null=True)
    is_verified=models.IntegerField(default=0)
    otp_expired_at=models.DateTimeField(null=True)
    oauth=models.CharField(max_length=255,null=True)
    oauth_client=models.CharField(max_length=255,null=True)
    mobile = models.CharField(max_length=255, unique=True, null=True)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE, db_constraint=False)
    status = models.IntegerField(default=1)
    is_deleted=models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    USERNAME_FIELD = 'username'
    REQUIRED_FIELDS = []


