import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../store/api";

export const getPromptList = createAsyncThunk(
    "prompt-list",
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.get('/admin/prompt-list');
            console.log("Response", response);
            if (response?.status === 200) {

                return response?.data?.results;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }

)
export const getSinglePromp = createAsyncThunk(
    "single-prompt",
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post('/admin/edit-prompt', userInput);
            console.log("Response", response?.data);
            if (response?.data?.status_code === 200) {

                return response?.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }
)
export const updatePrompt = createAsyncThunk(
    "update-prompt",
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post('/admin/update-prompt', userInput);
            console.log("Response", response?.data);
            if (response?.data?.status_code === 200) {

                return response?.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }
)
const initialState = {
    loading: false,
    error: false,
    promptList: [],
    singlePrompt: {},
    message: ""
}
const PromptSlice = createSlice(
    {
        name: 'promptLists',
        initialState,
        reducers: {},
        extraReducers: (builder) => {
            builder
                .addCase(getPromptList.pending, (state) => {
                    state.loading = true;
                })
                .addCase(getPromptList.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.promptList = payload
                    state.error = false
                })
                .addCase(getPromptList.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
                .addCase(getSinglePromp.pending, (state) => {
                    state.loading = true
                })
                .addCase(getSinglePromp.fulfilled, (state, { payload }) => {
                    console.log("Payload: ", payload);

                    state.loading = false
                    state.singlePrompt = payload
                    state.error = false
                })
                .addCase(getSinglePromp.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
                .addCase(updatePrompt.pending, (state) => {
                    state.loading = true
                })
                .addCase(updatePrompt.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.message = payload
                    state.error = false
                })
                .addCase(updatePrompt.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
        }
    })
export default PromptSlice.reducer;