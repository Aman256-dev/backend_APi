import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../store/api";

export const getSubList = createAsyncThunk(
    'sublist/getSubList',
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.get('/admin/get-subject-list');
            console.log("ResponseSub", response);
            if (response?.status === 200) {

                return response?.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }
)
export const add_user = createAsyncThunk(
    'add_teacher',
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post('admin/add-teacher', userInput);
            console.log("response", response);
            if (response?.data?.status === true) {
                return response.data;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }

    }
)
const initialState = {
    loading: false,
    error: false,
    subList: [],
    teacher: ""
}
const SubjectListSlice = createSlice(
    {
        name: 'sublists',
        initialState,
        reducers: {},
        extraReducers: (builder) => {
            builder.addCase(getSubList.pending, (state) => {
                state.loading = true;
            })
                .addCase(getSubList.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.subList = payload
                    state.error = false
                })
                .addCase(getSubList.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                }).addCase(add_user.pending, (state) => {
                    state.loading = true
                })
                .addCase(add_user.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.teacher = payload
                    state.error = false
                })
                .addCase(add_user.rejected, (state, { payload }) => {
                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
        }
    }
)
export default SubjectListSlice.reducer;