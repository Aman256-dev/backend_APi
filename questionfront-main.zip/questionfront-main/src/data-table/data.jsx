// // * fake data's
// import { faker } from "@faker-js/faker";

// export function createRandomUser() {
//   return {
//     profile: faker.image.avatar(),
//     firstName: faker.person.firstName(),
//     lastName: faker.person.lastName(),
//     age: faker.number.int(40),
//     visits: faker.number.int(1000),
//     progress: faker.number.int(100),
//     subscription: faker.number.int(),
//     amount: faker.number.int(1000),
//     status: faker.number.int(10),
//     email: faker.internet.email(),
//     phone: faker.phone.imei(),
//   };
// }

// export const USERS = faker.helpers.multiple(createRandomUser, {
//   count: 30,
// });
