import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../store/api";

export const getUserData = createAsyncThunk(
    'user/getUserData',
    async (id, { rejectWithValue }) => {
        try {
            const response = await api.get(`/edit-information/${id}`, id);
            // console.log("response", response?.status);
            if (response?.status === 200) {
                return response.data;
            } else {
                let errors = errorHandler(response);
                return rejectWithValue(response.data);
            }
        } catch (err) {
            let errors = errorHandler(err);
            return rejectWithValue(errors);
        }
    }
)
export const active_deactive_info = createAsyncThunk(
    'user/active_deactive_info',
    async (info_id, { rejectWithValue }) => {
        try {
            const response = await api.post(`/activate-deactivate-information`, info_id);
            // console.log("response", response?.status);
            if (response?.status === 200) {
                return response.data;
            } else {
                let errors = errorHandler(response);
                return rejectWithValue(response.data);
            }
        } catch (err) {
            let errors = errorHandler(err);
            return rejectWithValue(errors);
        }
    }
)
export const updateUser = createAsyncThunk(
    'user/updateUser',
    async (userInput, { rejectWithValue }) => {
        try {
            const response = await api.post(`/update-information`, userInput);
            // console.log("response", response?.status);
            if (response?.status === 200) {
                return response.data;
            } else {
                let errors = errorHandler(response);
                return rejectWithValue(response.data);
            }
        } catch (err) {
            let errors = errorHandler(err);
            return rejectWithValue(errors);
        }
    }
)
const initialState = {
    loading: false,
    getUpdateUser: [],
    error: null,
    message: ""
}
const UserUpdateSlice = createSlice(
    {
        name: 'usersUpdate',
        initialState,
        reducers: {},
        extraReducers: (builder) => {
            builder.addCase(getUserData.pending, (state) => {
                state.loading = true;
            })
                .addCase(getUserData.fulfilled, (state, { payload }) => {
                    state.loading = false;
                    state.getUpdateUser = payload
                    state.error = null
                })
                .addCase(getUserData.rejected, (state, { payload }) => {

                    state.error = true;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : "Something went wrong. Try again later.";
                })
                .addCase(active_deactive_info.pending, (state) => {
                    state.loading = true
                })
                .addCase(active_deactive_info.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.message = payload
                    state.error = null
                })
                .addCase(active_deactive_info.rejected, (state, { payload }) => {

                    state.error = true;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : "Something went wrong. Try again later.";
                })
                .addCase(updateUser.pending, (state) => {
                    state.loading = true
                })
                .addCase(updateUser.fulfilled, (state, { payload }) => {
                    state.loading = false
                    state.message = payload
                    state.error = null
                })
                .addCase(updateUser.rejected, (state, { payload }) => {

                    state.error = true;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : "Something went wrong. Try again later.";
                })
        }
    }
)
export default UserUpdateSlice.reducer;