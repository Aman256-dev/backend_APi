import { useEffect, useMemo, useState } from "react";
import AddPromptModal from "./AddPromptModal";
import { ToastContainer } from "react-toastify";
import { useDispatch, useSelector } from "react-redux";
import { getAllSubPrompt, getSinglePromp } from "../../reducers/PdfAndUrlSlice";
import TanStackTable from "../../data-table/TanstackReactTable";
import { createColumnHelper } from "@tanstack/react-table";
import { HiPencil } from "react-icons/hi2";
import { useForm } from "react-hook-form";
import UpdatePromptModal from "./UpdatePromptModal";

const AddPrompt = () => {
    const dispatch = useDispatch();
    const columnHelper = createColumnHelper();
    const [addPromptModal, setAddPromptModal] = useState(false);
    const [updatePromptModal, setUpdatePromptModal] = useState(false);

    const [pId, setPId] = useState(null);
    const [data, setData] = useState("");

    const { allSubPrompt } = useSelector((state) => state?.pdfAndUrl);
    console.log("allSubPrompt", allSubPrompt)

    const handleAddPrompt = () => {
        setAddPromptModal(true);
    }

    const {
        register,
        handleSubmit,
        setValue,
        formState: { errors },
    } = useForm();

    useEffect(() => {
        dispatch(getAllSubPrompt());
    }, [dispatch]);

    const updateUserHandler = (id) => {
        dispatch(getSinglePromp({ prompt_id: id })).then((res) => {
            console.log("Single Prompt: ", res?.payload?.result);
            if (res?.payload?.status_code === 200) {
                const prompt = res?.payload?.result;
                setValue("prompt", res?.payload?.result?.prompt);
                setPId(id);
                setData(res?.payload?.result?.prompt);
                setUpdatePromptModal(true);
            }
        });
    };

    const columns = useMemo(
        () => [
            columnHelper.accessor("subject", {
                cell: (info) => <span>{info.getValue()}</span>,
                header: "Subject",
            }),

            columnHelper.accessor("prompt", {
                cell: (info) => <span>{info.getValue()}</span>,
                header: "Prompt",
            }),

            columnHelper.accessor("Action", {
                cell: (info) => (
                    <button
                        onClick={() => {
                            updateUserHandler(info.cell.row.original.id);
                        }}
                        className="text-[#009BF2] text-xl hover:text-black"
                    >
                        <HiPencil />
                    </button>
                ),
            }),
        ],
        [columnHelper]
    );


    return (
        <>
            <ToastContainer />
            <div className="container mx-auto p-4 text-black">
                <div className="flex justify-between">
                    <h1 className="text-2xl font-semibold mb-4">Prompt List</h1>
                    <button onClick={() => {
                        handleAddPrompt();
                    }}
                        className="bg-[#0f026f] text-white font-bold py-2 px-4 rounded hover:bg-black focus:outline-none focus:ring-2 focus:ring-[#0f026f] focus:ring-opacity-75">
                        Add Prompt
                    </button>
                </div>
                <div className="mb-6">
                    <div>
                        <TanStackTable data={allSubPrompt} columns={columns} />
                    </div>
                </div>
            </div>

            {addPromptModal &&
                <AddPromptModal
                    addPromptModal={addPromptModal}
                    setAddPromptModal={setAddPromptModal}
                />
            }

            {updatePromptModal &&
                <UpdatePromptModal
                    updatePromptModal={updatePromptModal}
                    setUpdatePromptModal={setUpdatePromptModal}
                    pId={pId}
                    data={data}
                />
            }

        </>
    )
}

export default AddPrompt;