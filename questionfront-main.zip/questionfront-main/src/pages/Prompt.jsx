import { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { getPromptList, getSinglePromp } from "../reducers/PromptSlice";
import { createColumnHelper } from "@tanstack/react-table";
import TanStackTable from "../data-table/TanstackReactTable";
import { HiPencil } from "react-icons/hi2";
import { useForm } from "react-hook-form";
import PromptModal from "./PromptModal";

const Prompt = () => {
  const { promptList, singlePrompt } = useSelector((state) => state?.prompts);
  const columnHelper = createColumnHelper();
  const [updateUserModal, setUpdateUserModal] = useState(false);
  const [pId, setPId] = useState(null);
  const [data, setData] = useState("");
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getPromptList());
  }, [dispatch]);
  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm();
  console.log("Prompt List: ", promptList);
  const updateUserHandler = (id) => {
    dispatch(getSinglePromp({ prompt_id: id })).then((res) => {
      console.log("Single Prompt: ", res?.payload?.result);
      if (res?.payload?.status_code === 200) {
        const prompt = res?.payload?.result;
        setValue("prompt", res?.payload?.result?.prompt);
        setPId(id);
        setData(res?.payload?.result?.prompt);
        setUpdateUserModal(true);
      }
    });
  };
  const columns = useMemo(
    () => [
      columnHelper.accessor("subject", {
        cell: (info) => <span>{info.getValue()}</span>,
        header: "Subject",
      }),

      columnHelper.accessor("prompt", {
        cell: (info) => <span>{info.getValue()}</span>,
        header: "Prompt",
      }),

      columnHelper.accessor("Action", {
        cell: (info) => (
          <button
            onClick={() => {
              updateUserHandler(info.cell.row.original.id);
            }}
            className="text-[#009BF2] text-xl hover:text-black"
          >
            <HiPencil />
          </button>
        ),
      }),
    ],
    [columnHelper] // Depend on columnHelper so it's not recreated unnecessarily
  );
  return (
    <>
      <div className="container mx-auto p-4 text-black">
        <h1 className="text-2xl font-semibold mb-4">Prompt List</h1>
        <div className="mb-6">
          <div>
            <TanStackTable data={promptList} columns={columns} />
          </div>
        </div>
      </div>
      {updateUserModal && (
        <PromptModal
          updateUserModal={updateUserModal}
          setUpdateUserModal={setUpdateUserModal}
          pId={pId}
          data={data}
        />
      )}
    </>
  );
};
export default Prompt;
