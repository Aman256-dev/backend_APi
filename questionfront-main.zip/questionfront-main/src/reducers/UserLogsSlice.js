import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import api from "../store/api";


export const getUserLog = createAsyncThunk(
    "userLogs",
    async (_, { rejectWithValue }) => {
        try {
            const response = await api.post('/get-user-logs');
            console.log("Response", response);
            if (response?.status === 200) {
                console.log("Response2", response?.data?.results);
                return response?.data?.results;
            } else {
                if (response?.data?.errors) {
                    return rejectWithValue(response.data.errors);
                } else {
                    return rejectWithValue('Something went wrong.');
                }
            }
        } catch (err) {
            return rejectWithValue(err);
        }
    }

)
const initialState = {
    userLogsData: [],
    loading: false,
    error: null
}
const UserLogSlice = createSlice(
    {
        name: "userLogss",
        initialState,
        reducers: {},
        extraReducers: (builder) => {
            builder.addCase(getUserLog.pending, (state) => {
                state.loading = true;
            })
                .addCase(getUserLog.fulfilled, (state, { payload }) => {

                    state.loading = false;
                    state.userLogsData = payload
                    state.error = null
                })
                .addCase(getUserLog.rejected, (state, { payload }) => {

                    state.error = true;
                    state.loading = false;
                    state.message =
                        payload !== undefined && payload.message
                            ? payload.message
                            : 'Something went wrong. Try again later.';
                })
        }
    }
)
export default UserLogSlice.reducer;