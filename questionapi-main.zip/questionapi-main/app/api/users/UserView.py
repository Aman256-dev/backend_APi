import warnings
import re
from django.shortcuts import render
import PyPDF2
import json
from django.http import JsonResponse
from rest_framework.response import Response
from django.core.files.storage import FileSystemStorage
import csv
from django.views.decorators.csrf import csrf_exempt
from rest_framework.permissions import IsAuthenticated
import os
from rest_framework import status
import logging
import pandas as pd
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from io import StringIO
import xml.etree.ElementTree as ET
from io import StringIO
import io
from datetime import datetime
from django.conf import settings
from rest_framework.decorators import api_view,permission_classes,authentication_classes
from django.http import HttpResponse, JsonResponse
from app.models.prompts import Prompt
import json
import re
from typing import List, Dict, Any
from io import StringIO, BytesIO
import filetype
from PIL import Image
import pytesseract

from PyPDF2 import PdfReader
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
import re
from typing import List, Union

from pydantic import BaseModel
from openai import OpenAI
import uuid
from django.core.cache import cache
from app.models.cache import QuestionSet

from dotenv import load_dotenv
load_dotenv()
openai_api_key = os.getenv("OPENAI_API_KEY")


import cv2
import numpy as np
from pdf2image import convert_from_path
import pytesseract
from tqdm import tqdm
from pdf2image import pdfinfo_from_path


client = OpenAI()

warnings.filterwarnings("ignore", category=DeprecationWarning)
# logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)



def extract_text_from_pdf(pdf_path):
    extracted_text = []
    
    # Get the total number of pages
    info = pdfinfo_from_path(pdf_path)
    num_pages = info['Pages']
    
    # Process the PDF page by page
    for page_num in tqdm(range(num_pages), desc="Processing pages"):
        # Convert single page to image
        images = convert_from_path(pdf_path, first_page=page_num+1, last_page=page_num+1)
        
        for image in images:
            # Convert PIL Image to OpenCV format
            opencv_image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
            
            # Resize image if it's too large (adjust the max_dimension as needed)
            max_dimension = 2000
            h, w = opencv_image.shape[:2]
            if max(h, w) > max_dimension:
                scale = max_dimension / max(h, w)
                opencv_image = cv2.resize(opencv_image, None, fx=scale, fy=scale)
            
            # Convert the image to HSV color space
            hsv = cv2.cvtColor(opencv_image, cv2.COLOR_BGR2HSV)
            
            # Define the red color range (in HSV) for detecting red boxes
            # Red hue wraps around in HSV, so we need two ranges
            lower_red1 = np.array([0, 100, 100])
            upper_red1 = np.array([10, 255, 255])
            lower_red2 = np.array([160, 100, 100])
            upper_red2 = np.array([180, 255, 255])
            
            # Create masks to isolate red areas
            mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
            mask2 = cv2.inRange(hsv, lower_red2, upper_red2)
            mask = cv2.bitwise_or(mask1, mask2)
            
            # Find contours of red boxes
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # Extract text from each red box
            for contour in contours:
                x, y, w, h = cv2.boundingRect(contour)
                roi = opencv_image[y:y+h, x:x+w]
                text = pytesseract.image_to_string(roi, config='--psm 6')
                extracted_text.append(text.strip())
    
    return extracted_text



# def extract_text_from_pdf(pdf_path):
#     with open(pdf_path, 'rb') as file:
#         reader = PyPDF2.PdfReader(file)
#         text = ''
#         for page in reader.pages:
#             text += page.extract_text()        
#     return text

def extract_text_from_image(image_path):
    # Open the image file
    image = Image.open(image_path)

    # Use Tesseract to do OCR on the image
    text = pytesseract.image_to_string(image)

    return text



#image based pdf

def extract_text_from_image_pdf(image):
    try:
        text = pytesseract.image_to_string(image)
        return text
    except Exception as e:
        # logger.error(f"Error extracting text from image: {e}")
        return ""

def pdf_to_images(pdf_path):
    try:
        pdf = PdfReader(pdf_path)
        images = []
        for page in pdf.pages:
            # Create a blank image with a white background
            img = Image.new('RGB', (612, 792), color='white')
            
            # Create a canvas and draw the PDF page on it
            packet = io.BytesIO()
            can = canvas.Canvas(packet, pagesize=letter)
            can.drawString(100, 100, "This is a placeholder for PDF content")
            can.save()
            
            # Move to the beginning of the StringIO buffer
            packet.seek(0)
            new_pdf = PdfReader(packet)
            
            # Merge the original PDF page with our placeholder content
            page.merge_page(new_pdf.pages[0])
            
            # Convert the page to an image
            pil_image = Image.open(io.BytesIO(page.images[0].data))
            images.append(pil_image)
        return images
    except Exception as e:
        # logger.error(f"Error converting PDF to images: {e}")
        return []

def extract_text_from_pdf2(pdf_path, output_folder):
    try:
        os.makedirs(output_folder, exist_ok=True)
        
        # First, try to extract text directly using PyPDF2
        pdf = PdfReader(pdf_path)
        all_text = ""
        for i, page in enumerate(pdf.pages):
            text = page.extract_text()
            if text.strip():
                all_text += f"Page {i+1}:\n{text}\n\n"
        
        # If we got some text, return it
        if all_text.strip():
            return all_text
        
        # If no text was extracted, try image-based extraction
        # logger.info("No text extracted directly. Attempting image-based extraction.")
        images = pdf_to_images(pdf_path)
        
        all_text = ""
        for i, image in enumerate(images):
            page_text = extract_text_from_image_pdf(image)
            all_text += f"Page {i+1}:\n{page_text}\n\n"
        
        return all_text
    except Exception as e:
        # logger.error(f"Error processing PDF: {e}")
        return f"Error: {str(e)}"





#good image
class Question:
    def __init__(self, number: int, text: str, options: List[str]):
        self.number = number
        self.text = text
        self.options = options

    def __str__(self):
        options_str = "\n".join(f"   {option}" for option in self.options)
        return f"{self.number}. {self.text}\n{options_str}\n"

class FillInTheBlank(Question):
    pass

class SelectCorrectOption(Question):
    def __init__(self, number: int, text: str, options: List[str], context: str = ""):
        super().__init__(number, text, options)
        self.context = context

    def __str__(self):
        return f"{self.context}\n{super().__str__()}" if self.context else super().__str__()

class ExerciseSheet:
    def __init__(self, title: str):
        self.title = title
        self.questions: List[Union[FillInTheBlank, SelectCorrectOption]] = []

    def add_question(self, question: Union[FillInTheBlank, SelectCorrectOption]):
        self.questions.append(question)

    def __str__(self):
        questions_str = "\n".join(str(q) for q in self.questions)
        return f"{self.title}\n\n{questions_str}"

def parse_exercise_sheet(content: str) -> ExerciseSheet:
    sheet = ExerciseSheet("Practice Exercise")
    lines = content.split('\n')
    
    current_question = None
    context = ""
    
    for line in lines:
        line = line.strip()
        if not line or line.startswith("Page"):
            continue

        if line.startswith(('*', '•')):
            context = line
        elif re.match(r'^\d+\.', line):
            if current_question:
                sheet.add_question(current_question)
            
            number, text = line.split('.', 1)
            current_question = FillInTheBlank(int(number), text.strip(), [])
        elif re.match(r'^\([A-D]\)', line):
            if current_question:
                current_question.options.append(line)
        else:
            if current_question:
                if not current_question.text.endswith('?') and not line.startswith('('):
                    current_question.text += " " + line
                elif line.startswith('(') and len(current_question.options) == 0:
                    current_question.options = [opt.strip() for opt in line.split('(') if opt.strip()]
            elif context:
                number = len(sheet.questions) + 1
                current_question = SelectCorrectOption(number, line, [], context)
                context = ""

    if current_question:
        sheet.add_question(current_question)

    return sheet

def format_exercise_sheet(content: str) -> str:
    sheet = parse_exercise_sheet(content)
    return str(sheet)



# def extract_questions_from_text(text, start_string):
#     # Define the start line to begin extracting questions
#     start_line = f"{start_string}"

#     # Find the starting point of the questions section
#     start_index = text.find(start_line)

#     if start_index == -1:
#         return []  # Start line not found

#     # Extract text starting from the line after the start line
#     text_after_start = text[start_index + len(start_line):].strip()

#     # Split the text into lines
#     lines = text_after_start.split('\n')

#     questions = []
#     current_question = ""

#     # Pattern to detect the start of a new question (e.g., "1. ", "1) ", "Q 1. ")
#     question_start_pattern = re.compile(r'^\d+\.|\d+\)|Q\s*\d+\.')

#     for line in lines:
#         # Check if the line looks like the start of a new question
#         if question_start_pattern.match(line):
#             if current_question:
#                 questions.append(current_question.strip())
#             current_question = line
#         else:
#             current_question += " " + line

#     # Add the last question if there's any
#     if current_question:
#         questions.append(current_question.strip())

#     return questions


# New question 

# def extract_questions_from_text(text):
#     # Split the text into lines
#     lines = text.split('\n')

#     questions = []
#     current_question = ""

#     # Pattern to detect the start of a new question (e.g., "1. ", "1) ", "Q 1. ")
#     question_start_pattern = re.compile(r'^\s*(\d+\.|\d+\)|Q\s*\d+\.)')

#     for line in lines:
#         # Check if the line looks like the start of a new question
#         if question_start_pattern.match(line):
#             if current_question:
#                 questions.append(current_question.strip())
#             current_question = line
#         else:
#             current_question += " " + line

#     # Add the last question if there's any
#     if current_question:
#         questions.append(current_question.strip())

#     return questions




# New 18/09/24
def extract_questions_multi_subject(text):
    # Split the text into lines
    lines = text.split('\n')

    questions = []
    current_question = ""
    options = []
    question_number = 0

    # Patterns for different question formats
    question_patterns = [
        r'^\s*(\d+)[\.)]\s',  # Numbered questions: "1. " or "1) "
        r'^\s*[Qq]uestion\s*(\d+)[\.:]\s',  # "Question 1:" or "question 1."
        r'^\s*(\d+)\s*[\.:]\s',  # "1: " or "1. "
        r'^\s*\(?([a-zA-Z])\)?\s',  # Lettered questions: "(a) " or "a) " or "a. "
    ]

    # Combine patterns into a single regex
    question_start_pattern = re.compile('|'.join(question_patterns))

    # Pattern for options
    option_pattern = re.compile(r'^\s*([a-eA-E])[\.)]\s')

    for line in lines:
        line = line.strip()
        
        question_match = question_start_pattern.match(line)
        if question_match:
            if current_question:
                questions.append((question_number, current_question.strip(), options))
            question_number = question_match.group(1)
            current_question = line[len(question_match.group(0)):]
            options = []
        elif option_pattern.match(line):
            options.append(line)
        elif line and current_question:
            current_question += " " + line

    # Add the last question if there's any
    if current_question:
        questions.append((question_number, current_question.strip(), options))

    return questions

def classify_subject(question):
    # Simple classification based on keywords
    math_keywords = ['calculate', 'equation', 'solve', 'graph', 'number', 'geometry', 'algebra']
    science_keywords = ['experiment', 'hypothesis', 'scientific', 'chemistry', 'biology', 'physics']
    english_keywords = ['grammar', 'literature', 'write', 'essay', 'analyze', 'comprehension']

    question_lower = question.lower()
    
    if any(keyword in question_lower for keyword in math_keywords):
        return 'Math'
    elif any(keyword in question_lower for keyword in science_keywords):
        return 'Science'
    elif any(keyword in question_lower for keyword in english_keywords):
        return 'English'
    else:
        return 'Unknown'


def extract_questions_from_text(text):
    questions = extract_questions_multi_subject(text)
    question_list = []
    
    for number, question, options in questions:
        subject = classify_subject(question)
        
        # Format the question text
        formatted_question = f"Subject: {subject}\nQuestion: {question}\nOptions: {', '.join(options)}"
        
        # Create the question dictionary in the format OpenAI expects
        question_dict = {
            "text": formatted_question
        }
        
        # JSON encode the question dictionary
        encoded_question = json.dumps(question_dict)
        
        question_list.append(encoded_question)
    
    return question_list


# def identify_questions(input_string):
#     # Set up OpenAI API key

#     # Create an instance of the OpenAI language model
#     llm = OpenAI(temperature=0)

#     # Create a prompt template
#     template = """You will be given a string that may contain one or more questions. Your task is to identify how many questions are in the string and return them appropriately. Here's how to proceed:
#           1. First, you will be given the input string:
#           Text: {input_text}
#           2. Analyze the string to identify questions. Look for sentence-ending punctuation marks (?, !, or .) combined with question words (who, what, where, when, why, how) or inverted subject-verb order to identify questions.
#           3. Count the number of questions you've identified.
#           4. If there is only one question in the string:
#             - Return that single question inside <answer> tags.
#           5. If there are multiple questions in the string:
#             - Return all questions, each on a new line, inside <answer> tags.
#           6. If there are no questions in the string:
#             - Return the phrase "No questions found." inside <answer> tags.
#           Provide your response using the following format:
#           <answer>
#           [Your answer here]
#           </answer>
#           Remember to include only the identified question(s) or the "No questions found." message in your answer, without any additional explanation or commentary."""

#     prompt = PromptTemplate(template=template, input_variables=["input_text"])

#     # Create an LLMChain
#     chain = LLMChain(llm=llm, prompt=prompt)

#     # Run the chain
#     result = chain.invoke(input={"input_text": input_string})
#     answer_content = re.search(r'<answer>(.*?)</answer>', result['text'], re.DOTALL)
#     if answer_content:
#         return answer_content.group(1).strip()
#     else:
#         return "No questions found."




class Step(BaseModel):
    questions: str
    options: list[str]
    answer: str
    explanation: str

class MathReasoning(BaseModel):
    steps: list[Step]

def generate_questions_math(input_question):
    # prompt_template = """Your task is to create 5 new multiple-choice questions on each input question. New questions should be based on different formats like statement-based, passage-based, table-based, scenario-based, Match the column, Assertion and reason based etc. You can use other different formats as well. New questions should be application-based. New questions should not be direct or one-liners. These new questions should not be similar to the Input Question and it should be logically and analytically distinct. You should not reword the Input Question.
    # Follow these steps to generate the new multiple-choice questions:

    # 1. Analyze the input question to identify key concepts, themes, and potential areas for deeper exploration.
    # 2. For each new question you create:
    #     a. Formulate a question that goes beyond surface-level understanding, should be unique logically and analytically.
    #     b. Create one correct answer and three plausible but incorrect options.
    #     c. Ensure the correct answer is not obviously distinguishable from the distractors.

    # Guidelines for creating difficult questions:
    # - Focus on higher-order thinking skills (analysis, evaluation, synthesis)
    # - Include questions that require application of knowledge to new situations
    # - Incorporate common misconceptions or errors in the answer choices
    # - Use precise language to avoid ambiguity
    # - Do not repeat question or reword the question, each question should be different

    # Remember to generate exactly 5 questions, and ensure that each question is unique and non-duplicative of the others.Begin generating the multiple-choice questions now."""

    template = Prompt.objects.filter(id=1).first()
    prompt_template = template.prompt

    completion = client.beta.chat.completions.parse(
    model="gpt-4o-2024-08-06",
    messages=[
        {"role": "system", "content": prompt_template},
        {"role": "user", "content": input_question}
    ],
    response_format=MathReasoning,
    )

    math_reasoning = completion.choices[0].message

    # prompt_tokens = completion.usage.prompt_tokens
    # completion_tokens = completion.usage.completion_tokens
    total_tokens = completion.usage.total_tokens

    # If the model refuses to respond, you will get a refusal message
    if hasattr(math_reasoning, 'refusal') and math_reasoning.refusal:
        # print(math_reasoning.refusal)
        pass
    else:
        # Convert the parsed response to a Pydantic model
        math_solution = MathReasoning(steps=math_reasoning.parsed.steps)
    
    # Convert the Pydantic model to JSON
    json_output = math_solution.model_dump_json(indent=2)
    return json_output,total_tokens


def generate_questions_English(input_question):
    # prompt_template = """Your task is to create 5 new questions on each input question. New questions should be MCQs. New questions should be non-duplicate that test deep understanding of the subject matter. You can use other different formats as well. New questions should not be direct or one-liners. These new questions should not be similar to the Input Question and it should be logically and analytically distinct. You should not reword the Input Questions.

    # Follow these steps to generate the new multiple-choice questions:

    # 1. Analyze the input question to identify key concepts, themes, and potential areas for deeper exploration.
    # 2. For each new question you create:
    #     a. Formulate a question that goes beyond surface-level understanding, should be unique logically and analytically.
    #     b. Create one correct answer and three plausible but incorrect options.
    #     c. Ensure the correct answer is not obviously distinguishable from the distractors.

    # Guidelines for creating difficult questions:
    # - Focus on higher-order thinking skills (analysis, evaluation, synthesis)
    # - Include questions that require application of knowledge to new situations
    # - Incorporate common misconceptions or errors in the answer choices
    # - Use precise language to avoid ambiguity
    # - Do not repeat question or reword the question, each question should be different


    # Remember to generate exactly 5 questions, and ensure that each question is unique and non-duplicative of the others. Begin generating the multiple-choice questions now."""

    template = Prompt.objects.filter(id=3).first()
    prompt_template = template.prompt

    completion = client.beta.chat.completions.parse(
    model="gpt-4o-2024-08-06",
    messages=[
        {"role": "system", "content": prompt_template},
        {"role": "user", "content": input_question}
    ],
    response_format=MathReasoning,
    )

    math_reasoning = completion.choices[0].message

    # prompt_tokens = completion.usage.prompt_tokens
    # completion_tokens = completion.usage.completion_tokens
    total_tokens = completion.usage.total_tokens

    # If the model refuses to respond, you will get a refusal message
    if hasattr(math_reasoning, 'refusal') and math_reasoning.refusal:
        # print(math_reasoning.refusal)
        pass
    else:
        # Convert the parsed response to a Pydantic model
        math_solution = MathReasoning(steps=math_reasoning.parsed.steps)
    
    # Convert the Pydantic model to JSON
    json_output = math_solution.model_dump_json(indent=2)
    return json_output,total_tokens

def generate_questions_science(input_question):
    # prompt_template = """Your task is to create 5 new multiple-choice questions on each input question. New questions should be based on different formats like statement-based, passage-based, table-based, scenario-based, Match the column, Assertion and reason based etc. You can use other different formats as well. New questions should be application-based. New questions should not be direct or one-liners. These new questions should not be similar to the Input Question and it should be logically and analytically distinct. You should not reword the Input Question.

    #     Follow these steps to generate the new multiple-choice questions:
    #     1. Analyze the input question to identify key concepts, themes, and potential areas for deeper exploration.
    #     2. For each new question you create:
    #     a. Formulate a question that goes beyond surface-level understanding, should be unique logically and analytically.
    #     b. Create one correct answer and three plausible but incorrect options.
    #     c. Ensure the correct answer is not obviously distinguishable from the distractors.

    #     Guidelines for creating difficult questions:
    #     - Focus on higher-order thinking skills (analysis, evaluation, synthesis)
    #     - Include questions that require application of knowledge to new situations
    #     - Incorporate common misconceptions or errors in the answer choices
    #     - Use precise language to avoid ambiguity
    #     - Do not repeat question or reword the question, each question should be different

    #     Remember to generate exactly 5 questions, and ensure that each question is unique and non-duplicative of the others. Begin generating the multiple-choice science questions now, based on the given scientific topic or concept."""

    template = Prompt.objects.filter(id=2).first()
    prompt_template = template.prompt

    completion = client.beta.chat.completions.parse(
    model="gpt-4o-2024-08-06",
    messages=[
        {"role": "system", "content": prompt_template},
        {"role": "user", "content": input_question}
    ],
    response_format=MathReasoning,
    )

    math_reasoning = completion.choices[0].message

    # prompt_tokens = completion.usage.prompt_tokens
    # completion_tokens = completion.usage.completion_tokens
    total_tokens = completion.usage.total_tokens

    # If the model refuses to respond, you will get a refusal message
    if hasattr(math_reasoning, 'refusal') and math_reasoning.refusal:
        # print(math_reasoning.refusal)
        pass
    else:
        # Convert the parsed response to a Pydantic model
        math_solution = MathReasoning(steps=math_reasoning.parsed.steps)
    
    # Convert the Pydantic model to JSON
    json_output = math_solution.model_dump_json(indent=2)
    return json_output,total_tokens



def generate_questions_Gk(input_question):

    template = Prompt.objects.filter(id=4).first()
    prompt_template = template.prompt

    completion = client.beta.chat.completions.parse(
    model="gpt-4o-2024-08-06",
    messages=[
        {"role": "system", "content": prompt_template},
        {"role": "user", "content": input_question}
    ],
    response_format=MathReasoning,
    )

    math_reasoning = completion.choices[0].message

    # prompt_tokens = completion.usage.prompt_tokens
    # completion_tokens = completion.usage.completion_tokens
    total_tokens = completion.usage.total_tokens

    # If the model refuses to respond, you will get a refusal message
    if hasattr(math_reasoning, 'refusal') and math_reasoning.refusal:
        # print(math_reasoning.refusal)
        pass
    else:
        # Convert the parsed response to a Pydantic model
        math_solution = MathReasoning(steps=math_reasoning.parsed.steps)
    
    # Convert the Pydantic model to JSON
    json_output = math_solution.model_dump_json(indent=2)
    return json_output,total_tokens


def generate_questions_Reasoning(input_question):

    template = Prompt.objects.filter(id=5).first()
    prompt_template = template.prompt

    completion = client.beta.chat.completions.parse(
    model="gpt-4o-2024-08-06",
    messages=[
        {"role": "system", "content": prompt_template},
        {"role": "user", "content": input_question}
    ],
    response_format=MathReasoning,
    )

    math_reasoning = completion.choices[0].message

    # prompt_tokens = completion.usage.prompt_tokens
    # completion_tokens = completion.usage.completion_tokens
    total_tokens = completion.usage.total_tokens

    # If the model refuses to respond, you will get a refusal message
    if hasattr(math_reasoning, 'refusal') and math_reasoning.refusal:
        # print(math_reasoning.refusal)
        pass
    else:
        # Convert the parsed response to a Pydantic model
        math_solution = MathReasoning(steps=math_reasoning.parsed.steps)
    
    # Convert the Pydantic model to JSON
    json_output = math_solution.model_dump_json(indent=2)
    return json_output,total_tokens

# def single_json_to_dataframe(json_data):
#     # If json_data is a string, parse it
#     if isinstance(json_data, str):
#         data = json.loads(json_data)
#     else:
#         data = json_data

#     # Extract the steps
#     steps = data.get('steps', [])

#     # Create lists to hold the data
#     questions = []
#     option_a = []
#     option_b = []
#     option_c = []
#     option_d = []
#     answers = []
#     explanations = []

#     # Extract data from each step
#     for step in steps:
#         questions.append(step.get('questions', ''))
#         options = step.get('options', [])
        
#         # Ensure we have exactly 4 options, padding with empty strings if necessary
#         options += [''] * (4 - len(options))
        
#         option_a.append(options[0])
#         option_b.append(options[1])
#         option_c.append(options[2])
#         option_d.append(options[3])
        
#         answers.append(step.get('answer', ''))
#         explanations.append(step.get('explanation', ''))

#     # Create the DataFrame
#     df = pd.DataFrame({
#         'Question': questions,
#         'Option A': option_a,
#         'Option B': option_b,
#         'Option C': option_c,
#         'Option D': option_d,
#         'Answer': answers,
#         'Explanation': explanations
#     })

#     return df


# def single_json_to_dataframe(json_data, raw_question):
#     # If json_data is a string, parse it
#     if isinstance(json_data, str):
#         data = json.loads(json_data)
#     else:
#         data = json_data

#     # Extract the steps
#     steps = data.get('steps', [])

#     # Create lists to hold the data
#     questions = []
#     option_a = []
#     option_b = []
#     option_c = []
#     option_d = []
#     answers = []
#     explanations = []
#     raw_questions = []  # New list for raw questions

#     # Extract data from each step
#     for step in steps:
#         questions.append(step.get('questions', ''))
#         options = step.get('options', [])
        
#         # Ensure we have exactly 4 options, padding with empty strings if necessary
#         options += [''] * (4 - len(options))
        
#         option_a.append(options[0])
#         option_b.append(options[1])
#         option_c.append(options[2])
#         option_d.append(options[3])
        
#         answers.append(step.get('answer', ''))
#         explanations.append(step.get('explanation', ''))
#         raw_questions.append(raw_question)  # Add raw question for each step

#     # Create the DataFrame
#     df = pd.DataFrame({
#         'Raw Question': raw_questions,
#         'Question': questions,
#         'Option A': option_a,
#         'Option B': option_b,
#         'Option C': option_c,
#         'Option D': option_d,
#         'Answer': answers,
#         'Explanation': explanations
#     })

#     return df


def single_json_to_dataframe(json_data, raw_question):
    if isinstance(json_data, str):
        data = json.loads(json_data)
    else:
        data = json_data

    steps = data.get('steps', [])

    questions, option_a, option_b, option_c, option_d, answers, explanations, raw_questions = ([] for _ in range(8))

    def extract_content(option):
        # Match patterns like:
        # - "A) 2", "(A) 2", "A. 2", "a) 2", "(a) 2", "a. 2"
        # - "(1) apple", "1) apple", "1. apple"
        # - "A: apple", "B: apple", etc.
        # - or just plain content
        match = re.match(r'^(?:\(?(?:[A-Da-d]|[1-4])[\)\.:]|[A-Da-d]\s*:)?\s*(.+)$', option.strip())
        return match.group(1) if match else option

    def extract_answer(answer):
        # First, try to extract just the letter
        match = re.match(r'^(?:\(?([A-Da-d])[\)\.:])?\s*', answer.strip())
        if match and match.group(1):
            return match.group(1).upper()  # Convert lowercase to uppercase
        # If no letter, return the full content (for cases like "8 choice")
        return extract_content(answer)

    for step in steps:
        questions.append(step.get('questions', ''))
        options = step.get('options', [''] * 4)
        options += [''] * (4 - len(options))
        
        option_a.append(extract_content(options[0]))
        option_b.append(extract_content(options[1]))
        option_c.append(extract_content(options[2]))
        option_d.append(extract_content(options[3]))
        
        answers.append(extract_answer(step.get('answer', '')))
        explanations.append(step.get('explanation', ''))
        raw_questions.append(raw_question)

    df = pd.DataFrame({
        'Raw Question': raw_questions,
        'Question': questions,
        'Option A': option_a,
        'Option B': option_b,
        'Option C': option_c,
        'Option D': option_d,
        'Answer': answers,
        'Explanation': explanations
    })

    return df

def filter_list_items(input_list, min_words=10):
    def word_count(item):
        # Count words in the item
        return len(item.split())

    # Filter the list based on word count
    return [item for item in input_list if item.strip() and word_count(item) >= min_words]


@api_view(['POST'])
# @permission_classes([IsAuthenticated])
def extract_questions(request):
        file = request.FILES.get('file')
        techer_string = request.POST.get('startString')

        if not file or not techer_string:
            return Response({'status': False, 'message': 'Missing file or start string','status_code':status.HTTP_400_BAD_REQUEST},status.HTTP_400_BAD_REQUEST)
        
        kind = filetype.guess(file)

        try:
            if kind and kind.mime in ['application/pdf','image/png','image/jpeg']:
                if kind.mime == 'application/pdf':
                    with open('temp.pdf', 'wb+') as destination:
                        for chunk in file.chunks():
                            destination.write(chunk)
                    text = extract_text_from_pdf('temp.pdf')
                    extracted_questions = filter_list_items(text)

                    # if not text.strip():
                    #     output_folder = '/New'
                    #     extracted_text =  extract_text_from_pdf2('temp.pdf', output_folder)

                    #     extracted_questions = format_exercise_sheet(extracted_text)
                        # print("jjsjsjsjsjsjs")
                        
                elif kind.mime in ['image/png', 'image/jpeg']:
                     extracted_questions = extract_text_from_image(file)
            # extracted_questions = extract_questions_from_text(text)
            # print(extracted_questions)
            json_data = []
            dataframes = []
            total_tokens = 0

            if techer_string == "English": 
                  
                for i, raw_question in enumerate(extracted_questions, start=1):
                    new_question,question_tokens = generate_questions_English(raw_question)
                    json_data.append(new_question)
                    # Convert the single JSON object to a DataFrame
                    # df = single_json_to_dataframe(new_question)
                    df = single_json_to_dataframe(new_question, raw_question)
                    dataframes.append(df)
                    total_tokens += question_tokens
                    

            elif techer_string == "Math":

                for i, raw_question in enumerate(extracted_questions, start=1):
                    new_question,question_tokens = generate_questions_math(raw_question)
                    json_data.append(new_question)
                    # Convert the single JSON object to a DataFrame
                    # df = single_json_to_dataframe(new_question)
                    df = single_json_to_dataframe(new_question, raw_question)
                    dataframes.append(df)
                    total_tokens += question_tokens

            elif techer_string == "Science":

                for i, raw_question in enumerate(extracted_questions, start=1):
                    new_question,question_tokens = generate_questions_science(raw_question)
                    json_data.append(new_question)
                    # Convert the single JSON object to a DataFrame
                    # df = single_json_to_dataframe(new_question)
                    df = single_json_to_dataframe(new_question, raw_question)
                    dataframes.append(df)
                    total_tokens += question_tokens


            elif techer_string == "GK":
                
                for i, raw_question in enumerate(extracted_questions, start=1):
                    new_question,question_tokens = generate_questions_Gk(raw_question)
                    json_data.append(new_question)
                    # Convert the single JSON object to a DataFrame
                    df = single_json_to_dataframe(new_question,raw_question)
                    dataframes.append(df)
                    total_tokens += question_tokens
            
            elif techer_string == "Reasoning":

                for i, raw_question in enumerate(extracted_questions, start=1):
                    new_question,question_tokens = generate_questions_Reasoning(raw_question)
                    json_data.append(new_question)
                    # Convert the single JSON object to a DataFrame
                    df = single_json_to_dataframe(new_question,raw_question)
                    dataframes.append(df)
                    total_tokens += question_tokens
            
            # Combine all DataFrames into a single one
            combined_df = pd.concat(dataframes, ignore_index=True)

            # Convert DataFrame to a list of dictionaries
            df_list = combined_df.to_dict(orient='records')

            #question_id = str(uuid.uuid4())

            # Store the questions in the cache
            #cache.set(f"questions_{question_id}", json.dumps(df_list), timeout=3600)  # Store for 1 hour
            
            question_set = QuestionSet.objects.create(
            questions_data=df_list)

            return Response({
                'status': True,
                'message': json_data,
                'Total_token' : total_tokens,
                'question_id': str(question_set.question_id),
                'status_type':status.HTTP_200_OK
            },status.HTTP_200_OK)
        except Exception as e:
            logger.error(f"Error processing file: {str(e)}")
            return JsonResponse({'status': False, 'error': str(e)})    

@api_view(['GET'])
# @permission_classes([IsAuthenticated])
def download_csv(request):
    question_id = request.GET.get('question_id')
    if not question_id:
        logger.warning("Missing question ID in request")
        return HttpResponse("Missing question ID", status=400)

    #questions_json = cache.get(f"questions_{question_id}")
    #questions_json = QuestionSet.objects.get(question_id=question_id)
    
    questions_jsona = QuestionSet.objects.get(question_id=question_id)
    questions_json = questions_jsona.questions_data
    
    if not questions_json:
        logger.warning(f"No data found in cache for question_id: {question_id}")
        return HttpResponse("No data available for download", status=400)

    def clean_text(text):
        # Remove HTML-like color formatting
        if isinstance(text, str):
            # Remove color tags like <red>text</red>
            text = re.sub(r'<[^>]+>', '', text)
            # Remove color formatting if it exists in other formats
            text = re.sub(r'\[\[red\]\]|\[\[/red\]\]', '', text)
            # Remove any other potential color formatting
            text = re.sub(r'\{color:[^}]+\}|\{/color\}', '', text)
        return text

    try:
        #questions_data = json.loads(questions_json)
        
        # Create DataFrame and clean the data
        dataframe = pd.DataFrame(questions_json)

        column_order = [
            'Raw Question',
            'Question',
            'Option A',
            'Option B',
            'Option C',
            'Option D',
            'Answer',
            'Explanation'
        ]
        
        # Reorder columns
        dataframe = dataframe[column_order]
        
        # Clean specific columns that might contain color formatting
        columns_to_clean = ['Answer', 'Question', 'Option A', 'Option B', 'Option C', 'Option D']
        for column in columns_to_clean:
            if column in dataframe.columns:
                dataframe[column] = dataframe[column].apply(clean_text)
        
        current_time = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        user_id = request.user.id
        file_name = f"generated_questions_{current_time}.csv"
        csv_folder = os.path.join('media', 'csv', str(user_id))
        file_path = os.path.join(csv_folder, file_name)

        # Ensure the directory exists
        os.makedirs(csv_folder, exist_ok=True)
        
        # Create a CSV bytes object from the DataFrame
        csv_buffer = BytesIO()
        dataframe.to_csv(csv_buffer, index=False, encoding='utf-8')
        csv_bytes = csv_buffer.getvalue()

        # Save the file using FileSystemStorage
        fs = FileSystemStorage(location=csv_folder)
        with fs.open(file_name, 'wb') as csv_file:
            csv_file.write(csv_bytes)

        # Generate the URL
        csv_url = f'{settings.BASE_URL}/{csv_folder}/{file_name}'
        logger.info(f"CSV file generated successfully for user {user_id}, question_id: {question_id}")
        return JsonResponse({'csv_url': csv_url})
    
    except json.JSONDecodeError:
        logger.error(f"Invalid JSON data in cache for question_id: {question_id}")
        return HttpResponse("Error: Invalid JSON data in cache", status=500)
    except Exception as e:
        logger.error(f"Error processing data for question_id {question_id}: {str(e)}")
        return HttpResponse(f"Error processing data: {str(e)}", status=500)    



@api_view(['GET'])
# @permission_classes([IsAuthenticated])
def download_word(request):
    question_id = request.GET.get('question_id')
    if not question_id:
        logger.warning("Missing question ID in request")
        return HttpResponse("Missing question ID", status=400)

    #questions_json = cache.get(f"questions_{question_id}")
    #questions_json = QuestionSet.objects.get(question_id=question_id)
    
    questions_jsona = QuestionSet.objects.get(question_id=question_id)
    questions_json = questions_jsona.questions_data
    
    if not questions_json:
        logger.warning(f"No data found in cache for question_id: {question_id}")
        return HttpResponse("No data available for download", status=400)
    
    try:
        #questions_data = json.loads(questions_json)
        
        # Create DataFrame directly from the loaded data
        words_df = pd.DataFrame(questions_json)
        
        # Create a new Word document
        doc = Document()
        
        # Add a title
        title = doc.add_heading('Generated Questions', level=1)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Iterate through the DataFrame and add content to the Word document
        for index, row in words_df.iterrows():
            # Add a question number
            doc.add_paragraph(f"Question {index + 1}", style='List Number')
            
            # Add Raw Question
            if 'Raw Question' in row:
                doc.add_paragraph(f"Raw Question: {row['Raw Question']}")
            
            # Add Question
            if 'Question' in row:
                doc.add_paragraph(f"Question: {row['Question']}")
            
            # Add options
            for option in ['A', 'B', 'C', 'D']:
                option_field = f'Option {option}'
                if option_field in row:
                    doc.add_paragraph(f"{option}) {row[option_field]}")
            
            # Add answer
            if 'Answer' in row:
                answer_para = doc.add_paragraph("Answer: ")
                answer_run = answer_para.add_run(str(row['Answer']))
                answer_run.font.color.rgb = RGBColor(0, 128, 0)  # Green color
                answer_run.bold = True
            
            # Add explanation
            if 'Explanation' in row:
                explanation_para = doc.add_paragraph("Explanation: ")
                explanation_para.add_run(str(row['Explanation'])).italic = True
            
            # Add a separator
            doc.add_paragraph("_" * 50)
        
        # Save the document to a BytesIO object
        buffer = BytesIO()
        doc.save(buffer)
        buffer.seek(0)
        
        # Generate file name and path
        current_time = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        user_id = request.user.id
        file_name = f"generated_questions_{current_time}.docx"
        word_folder = os.path.join('media', 'word', str(user_id))
        file_path = os.path.join(word_folder, file_name)
        
        # Ensure the directory exists
        os.makedirs(word_folder, exist_ok=True)
        
        # Save the file
        fs = FileSystemStorage(location=word_folder)
        with fs.open(file_name, 'wb') as doc_file:
            doc_file.write(buffer.getvalue())
        
        # Generate the URL
        doc_url_words = f'{settings.BASE_URL}/{word_folder}/{file_name}'
        logger.info(f"Word document generated successfully for user {user_id}, question_id: {question_id}")
        return JsonResponse({'word_url': doc_url_words})
    
    except json.JSONDecodeError:
        logger.error(f"Invalid JSON data in cache for question_id: {question_id}")
        return HttpResponse("Error: Invalid JSON data in cache", status=500)
    except Exception as e:
        logger.error(f"Error processing data for question_id {question_id}: {str(e)}")
        return HttpResponse(f"Error processing data: {str(e)}", status=500)


@api_view(['GET'])
def health_check(request):
    try:
        # Test database connection
        QuestionSet.objects.first()
        
        return JsonResponse({
            'status': 'healthy',
            'database': 'connected',
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return JsonResponse({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }, status=500)


# @api_view(['GET'])
# # @permission_classes([IsAuthenticated])
# def download_word(request):
#     question_id = request.GET.get('question_id')
#     if not question_id:
#         logger.warning("Missing question ID in request")
#         return HttpResponse("Missing question ID", status=400)

#     questions_json = cache.get(f"questions_{question_id}")
#     if not questions_json:
#         logger.warning(f"No data found in cache for question_id: {question_id}")
#         return HttpResponse("No data available for download", status=400)
    
#     try:
#         questions_data = json.loads(questions_json)
        
#         # Create DataFrame directly from the loaded data
#         words_df = pd.DataFrame(questions_data)
        
#         # Create a new Word document
#         doc = Document()
        
#         # Add a title
#         title = doc.add_heading('Generated Questions', level=1)
#         title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
#         # Iterate through the DataFrame and add content to the Word document
#         for index, row in words_df.iterrows():
#             # Add a question number
#             doc.add_paragraph(f"Question {index + 1}", style='List Number')
            
#             # Try to find a question field
#             question_field = next((field for field in row.index if 'question' in field.lower()), None)
#             if question_field:
#                 doc.add_paragraph(f"{question_field.capitalize()}: {row[question_field]}")
#             else:
#                 doc.add_paragraph("Question: [No question found]")
            
#             # Add options
#             for option in ['A', 'B', 'C', 'D']:
#                 option_field = next((field for field in row.index if f'option {option}'.lower() in field.lower() or f'option_{option}'.lower() in field.lower()), None)
#                 if option_field:
#                     doc.add_paragraph(f"{option}) {row[option_field]}")
            
#             # Add answer
#             answer_field = next((field for field in row.index if 'answer' in field.lower()), None)
#             if answer_field:
#                 answer_para = doc.add_paragraph("Answer: ")
#                 answer_run = answer_para.add_run(str(row[answer_field]))
#                 answer_run.font.color.rgb = RGBColor(0, 128, 0)  # Green color
#                 answer_run.bold = True
            
#             # Add explanation
#             explanation_field = next((field for field in row.index if 'explanation' in field.lower()), None)
#             if explanation_field:
#                 explanation_para = doc.add_paragraph("Explanation: ")
#                 explanation_para.add_run(str(row[explanation_field])).italic = True
            
#             # Add a separator
#             doc.add_paragraph("_" * 50)
        
#         # Save the document to a BytesIO object
#         buffer = BytesIO()
#         doc.save(buffer)
#         buffer.seek(0)
        
#         # Generate file name and path
#         current_time = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
#         user_id = request.user.id
#         file_name = f"generated_questions_{current_time}.docx"
#         word_folder = os.path.join('media', 'word', str(user_id))
#         file_path = os.path.join(word_folder, file_name)
        
#         # Ensure the directory exists
#         os.makedirs(word_folder, exist_ok=True)
        
#         # Save the file
#         fs = FileSystemStorage(location=word_folder)
#         with fs.open(file_name, 'wb') as doc_file:
#             doc_file.write(buffer.getvalue())
        
#         # Generate the URL
#         doc_url_words = f'{settings.BASE_URL}/{word_folder}/{file_name}'
#         logger.info(f"Word document generated successfully for user {user_id}, question_id: {question_id}")
#         return JsonResponse({'word_url': doc_url_words})
    
#     except json.JSONDecodeError:
#         logger.error(f"Invalid JSON data in cache for question_id: {question_id}")
#         return HttpResponse("Error: Invalid JSON data in cache", status=500)
#     except Exception as e:
#         logger.error(f"Error processing data for question_id {question_id}: {str(e)}")
#         return HttpResponse(f"Error processing data: {str(e)}", status=500)