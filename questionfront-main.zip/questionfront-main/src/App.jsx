import { lazy, Suspense } from "react";
import "./App.css";
import "./assets/css/custom.css";
import { Route, BrowserRouter as Router, Routes } from "react-router-dom";

import Dashboard from "./pages/dashboard/Dashboard";
import { Login } from "./pages/login/Login";

import ProtectedRoute from "./routing/ProtectedRoute";

import UserList from "./pages/UserList/UserList";

import AddUser from "./pages/AddUser/AddUser";

import UsersLog from "./pages/UsersLog/UsersLog";

import DisplayData from "./pages/DisplayData/DisplayData";

import Uploadpdf from "./pages/Uploadpdf/Uploadpdf";
import CreatePassword from "./pages/AddUser/CreatePassword";
import ViewPdf from "./pages/Uploadpdf/ViewPdf";
import ForgotPassword from "./pages/login/ForgotPassword";
import ViewCsv from "./pages/Uploadpdf/ViewCsv";
import UploadVendorCsv from "./pages/VendorCsv/UploadVendorCsv";
import Register from "./pages/Registration/Register";
import SubscriptionPage from "./Subscription/SubscriptionPage";
import PaymentPage from "./Subscription/PaymentPage";
import PaymentRedirect from "./Subscription/PaymentRedirect";
import Myplan from "./pages/MyPlans/Myplan";
import Prompt from "./pages/Prompt";
import UploadPdf from "./pages/UrlAndPdf/UploadPdf";
import UploadUrl from "./pages/UrlAndPdf/UploadUrl";
import AddPrompt from "./pages/UrlAndPdf/AddPrompt";

const MasterLayout = lazy(() => import("./components/layout/MasterLayout"));

const ErrorComponent = lazy(() => import("./pages/errors/ErrorComponent"));

const ResetPassword = lazy(() => import("./pages/login/ResetPassword"));

function App() {
  return (
    <>
      <Router>
        <Suspense fallback={<div>Loading...</div>}>
          <Routes>
            {/* Route without MasterLayout */}
            <Route path="/" element={<Login />} />
            <Route path="/registration" element={<Register />} />
            <Route path="/subscriptionPage" element={<SubscriptionPage />} />
            <Route path="/paymentpage" element={<PaymentPage />} />
            <Route path="/payment-redirect" element={<PaymentRedirect />} />
            {/* Protected Routes with MasterLayout */}
            <Route element={<ProtectedRoute />}>
              <Route path="/" element={<MasterLayout />}>
                <Route path="dashboard" element={<Dashboard />} />
                <Route path="myplans" element={<Myplan />} />
                <Route path="add-user" element={<AddUser />} />
                <Route path="user-list" element={<UserList />} />
                <Route path="user-log" element={<UsersLog />} />
                <Route path="display-data" element={<DisplayData />} />
                <Route path="prompt" element={<Prompt />} />
                <Route path="upload-vendor-csv" element={<UploadVendorCsv />} />
                <Route path="upload-pdf" element={<Uploadpdf />} />

                <Route path="uploadPdf" element={<UploadPdf />} />
                <Route path="uploadUrl" element={<UploadUrl />} />
                <Route path="addPrompt" element={<AddPrompt />} />

                <Route path="reset-password" element={<ResetPassword />} />
                {/* <Route
                  path="user/set-password/:token"
                  element={<CreatePassword />}
                /> */}
                <Route path="/view_pdf" element={<ViewPdf />} />
                <Route path="/view_csv" element={<ViewCsv />} />
              </Route>
            </Route>
            <Route
              path="/user/set-password/:token"
              element={<CreatePassword />}
            />
            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route
              path="user/reset-password/:token"
              element={<ResetPassword />}
            />
            {/* Handle 404 or other fallback routes */}
            <Route path="*" element={<ErrorComponent />} />
          </Routes>
        </Suspense>
      </Router>
    </>
  );
}

export default App;
