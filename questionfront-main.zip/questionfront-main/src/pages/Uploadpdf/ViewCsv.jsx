import { FileInput, Label, Table } from "flowbite-react";
import React, { useEffect } from "react";

import { useDispatch, useSelector } from "react-redux";

import { Link, useLocation } from "react-router-dom";
import { downloadedPdf, viewPdf } from "../../reducers/UploadPdfSlice";

const ViewCsv = () => {
  const dispatch = useDispatch();

  const { pdfData, viewPdfData } = useSelector((state) => state?.upld_pdf);
  useEffect(() => {
    dispatch(viewPdf({ entity: "csv" }));
  }, [dispatch]);
  console.log("pdfData", pdfData?.res);

  const downloadPdfUser = (id, file_name) => {
    dispatch(downloadedPdf(id))
      .unwrap()
      .then((blob) => {
        const url = window.URL.createObjectURL(new Blob([blob]));
        const link = document.createElement("a");
        link.href = url;
        const extension = file_name.split(".").pop();
        link.setAttribute(
          "download",
          extension === "csv" ? `file_${id}.csv` : `file_${id}.pdf`
        );
        document.body.appendChild(link);
        link.click();
        link.parentNode.removeChild(link);
      })
      .catch((error) => {
        console.error("Error downloading the PDF: ", error);
      });
  };

  return (
    <>
      <div className="overflow-x-auto">
        <Table striped>
          <Table.Head>
            <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
              SL No.
            </Table.HeadCell>
            <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
              View List
            </Table.HeadCell>
            <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
              Created At
            </Table.HeadCell>
          </Table.Head>
          <Table.Body className="divide-y">
            {Array.isArray(viewPdfData.res) &&
              viewPdfData?.res?.map((pdfs, index) => (
                <Table.Row
                  key={index}
                  className="bg-white dark:border-gray-700 dark:bg-gray-800"
                >
                  <Table.Cell className="font-bold">{index + 1}</Table.Cell>
                  <Table.Cell className="font-bold">
                    <button
                      onClick={() => downloadPdfUser(pdfs?.id, pdfs?.file_name)}
                      className="bg-[#029962] px-4 py-2 text-white rounded-md mt-0 ml-1"
                    >
                      Download
                    </button>
                  </Table.Cell>
                  <Table.Cell className="font-bold">
                    {pdfs?.created_date}
                  </Table.Cell>
                </Table.Row>
              ))}
          </Table.Body>
        </Table>
      </div>
    </>
  );
};

export default ViewCsv;
