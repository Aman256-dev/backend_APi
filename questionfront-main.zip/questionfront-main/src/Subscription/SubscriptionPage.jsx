import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  getPlans,
  getStripeKey,
  paymentIntent,
} from "../reducers/SubscriptionSlice";
import { useNavigate } from "react-router-dom";
import HeaderContent from "../components/layout/HeaderContent";

const SubscriptionPage = () => {
  const { plans } = useSelector((state) => state?.subs);

  const userIdObject = localStorage.getItem("userId");
  const parseUserId = JSON.parse(userIdObject);
  console.log("parse User Id", parseUserId);

  const userId = parseUserId?.user_id;
  console.log("UserId: ", userId);

  const dispatch = useDispatch();
  const navigate = useNavigate();
  useEffect(() => {
    dispatch(getPlans());
  }, [dispatch]);
  console.log("plans: ", plans?.results);

  const payment_intent = (plan_id) => {
    dispatch(getStripeKey());
    dispatch(paymentIntent({ user_id: userId, plan_id: plan_id })).then(
      (res) => {
        console.log("res", res);
        if (res?.payload?.status === true) {
          navigate("/paymentpage", {
            state: { plan_id: plan_id, user_id: userId },
          });
        }
      }
    );
  };

  return (
    <>
      <HeaderContent />
      <div className="py-10 lg:py-10 px-8 lg:px-0">
        <div className="max-w-7xl mx-auto">
          <h2 className="font-Bebas text-4xl md:text-5xl tracking-normal text-center mb-0 text-[#232a34]">
            Choose Plan
          </h2>
          <div className="choose_your_plan_section pb-0">
            <div className="max-w-xl mx-auto py-0 lg:py-4 px-0 ">
              <div className="plan_tab_area">
                <div className="px-4 lg:px-0">
                  <div className="w-full max-w-4xl p-3 mx-auto my-0 lg:p-10">
                    <div className="container mx-auto my-0">
                      {plans?.results?.map((plandetails) => {
                        return (
                          <>
                            <div className="md:flex justify-between px-4 md:px-10 py-10  shadow-xl bg-[#2aa9e1] rounded-2xl mb-14">
                              <div className="w-full md:w-6/12">
                                <div className="">
                                  <h2 className="font-Bebas text-white pb-5 text-2xl lg:text-[40px] tracking-normal mb-2 text-center">
                                    {plandetails?.plan_name}
                                  </h2>

                                  <div className="text-center">
                                    <h3 className="text-xl lg:text-xl text-white font-semibold mb-4">
                                      <span className="text-black text-xl pr-5">
                                        $ {plandetails?.price}
                                      </span>
                                    </h3>
                                    <h3 className="text-3xl text-white font-bold mb-4">
                                      <span className="text-black pr-1"></span>
                                      {plandetails?.interval}
                                    </h3>
                                    {/* <h3 className="text-3xl text-white font-bold mb-4">
                                      <span className="text-black pr-1"></span>
                                      {plandetails?.description}
                                    </h3> */}

                                    <button
                                      onClick={() => {
                                        payment_intent(plandetails?.plan_id);
                                      }}
                                      className="text-base font-medium bg-[#18191b] hover:bg-[#2aa9e1] text-white text-center rounded-lg w-full block border-2 py-2 hover:border-white border-[#18191b]"
                                    >
                                      Subscribe Now
                                    </button>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
export default SubscriptionPage;
