import React, { useEffect } from "react";
import { Table } from "flowbite-react";

import { MdDelete } from "react-icons/md";
import { useDispatch, useSelector } from "react-redux";
import {
  activeDeactiveUser,
  deleteUser,
  getAllUser,
} from "../../reducers/UserSlice";

const UserList = () => {
  const { allUsers } = useSelector((state) => state?.users);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(getAllUser());
  }, [dispatch]);
  console.log("All Users: ", allUsers?.results?.user_lists);
  const handleToggleStatus = (user_id, currentStatus) => {
    const newStatus = currentStatus === 0 ? 1 : 0;
    dispatch(activeDeactiveUser({ user_id, status: newStatus })).then(() => {
      dispatch(getAllUser());
    });
  };
  const deleteHandler = (user_id) => {
    dispatch(deleteUser({ user_id: user_id })).then(() => {
      dispatch(getAllUser());
    });
  };
  return (
    <>
      <div className="container mx-auto p-4 text-black">
        <h1 className="text-2xl font-semibold mb-4">User List</h1>
        <div className="overflow-x-auto ">
          <Table striped>
            <Table.Head>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Actions
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Name
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Email
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Type
              </Table.HeadCell>
              <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                Status
              </Table.HeadCell>
            </Table.Head>
            <Table.Body className="divide-y">
              {allUsers?.results?.user_lists?.map((users) => {
                return (
                  <>
                    <Table.Row className="bg-white dark:border-gray-700 dark:bg-gray-800">
                      <Table.Cell className="flex items-center justify-start">
                        <div className="mr-10">
                          <label className="inline-flex items-center cursor-pointer">
                            <input
                              type="checkbox"
                              // value={users?.status}
                              checked={users.status === 1}
                              onChange={() =>
                                handleToggleStatus(users.user_id, users.status)
                              }
                              className="sr-only peer"
                            />
                            <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                          </label>
                        </div>
                        <button
                          onClick={() => {
                            deleteHandler(users?.user_id);
                          }}
                          className="text-[#ea5c65] hover:text-black"
                        >
                          <MdDelete className="text-2xl" />
                        </button>
                      </Table.Cell>
                      <Table.Cell className="font-bold">
                        {users?.name}
                      </Table.Cell>
                      <Table.Cell className="font-bold">
                        {users?.email}
                      </Table.Cell>
                      <Table.Cell className="font-bold">
                        {users?.user_type}
                      </Table.Cell>
                      <Table.Cell>
                        {users?.status === 0 ? (
                          <>
                            <button className="text-[#ea5c65] font-bold">
                              Inactive
                            </button>
                          </>
                        ) : (
                          <button className="text-[#277B0C] font-bold">
                            Active
                          </button>
                        )}
                      </Table.Cell>
                    </Table.Row>
                  </>
                );
              })}
            </Table.Body>
          </Table>
        </div>
      </div>
    </>
  );
};

export default UserList;
