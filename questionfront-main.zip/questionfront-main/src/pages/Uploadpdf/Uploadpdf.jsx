import {
  FileInput,
  Label,
  Select,
  Spinner,
  Table,
  TextInput,
} from "flowbite-react";
import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import {
  downloadCsv,
  downloadWord,
  upload_pdf,
} from "../../reducers/UploadPdfSlice";
import { Link } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import {
  downloadCsvFiles,
  downloadDocsFiles,
} from "../../reducers/downloadSlice";
import { getSubList } from "../../reducers/SubjectListSlice";

const Uploadpdf = () => {
  const dispatch = useDispatch();
  const { loading, subList } = useSelector((state) => state?.teacher);
  const user_typeJson = localStorage.getItem("userType");
  const user_typeObj = JSON.parse(user_typeJson);
  const { questionResponse, loadingupload, downloadWordData, downloadCsvData } =
    useSelector((state) => state?.upld_pdf);
  const [isData, setIsData] = useState(false);
  const [queId, setQueId] = useState("");
  const [token, setToken] = useState("");
  const [uploadProgress, setUploadProgress] = useState(0);
  const sub = localStorage.getItem("sub");
  const parseSubject = JSON.parse(sub);
  const subejct = parseSubject?.subject;
  useEffect(() => {
    dispatch(getSubList());
  }, [dispatch]);
  const {
    register,
    handleSubmit,
    setError,
    formState: { errors },
    reset,
  } = useForm();

  let question_data;

  const onSubmit = (data) => {
    setUploadProgress(0); // Reset progress
    let progressInterval;

    // Start simulating progress
    progressInterval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 99) {
          // Stop incrementing at 90%
          clearInterval(progressInterval);
          return prev;
        }
        return prev + 1; // Increment progress
      });
    }, 1500);
    const formdata = new FormData();
    formdata.append("startString", data?.startString);
    formdata.append("file", data?.file[0]);
    dispatch(upload_pdf(formdata)).then((res) => {
      console.log("res", res);
      clearInterval(progressInterval);
      if (res?.payload?.status === true) {
        // console.log("res?Payload: ", typeof res?.payload?.message);
        setIsData(true);
        console.log("isData: ", isData);
        setQueId(res?.payload?.question_id);
        setToken(res?.payload?.Total_token);
        toast.success("File Upload Successfully", {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          progress: undefined,
          theme: "light",
        });
      } else {
        console.log("Error: ", JSON.stringify(res?.payload?.error));

        toast.error(res?.payload?.error, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          progress: undefined,
          theme: "dark",
        });
      }
    });
  };

  const handleWordFileDownload = async (queId) => {
    try {
      const res = await dispatch(downloadWord(queId)).unwrap();
      const wordUrl = res.word_url; // Assuming response contains word_url
      console.log("Word URL: ", wordUrl);

      // Create a hidden link and trigger download
      const link = document.createElement("a");
      link.href = wordUrl;
      link.setAttribute("download", "file.docx"); // Optional: specify a default filename
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link); // Clean up after download
    } catch (error) {
      console.error("Failed to download Word file: ", error);
    }
  };
  const handleCsvFileDownload = async (queId) => {
    try {
      const res = await dispatch(downloadCsv(queId)).unwrap();
      const csvUrl = res.csv_url; // Assuming response contains csv_url
      console.log("CSV URL: ", csvUrl);

      // Create a hidden link and trigger download
      const link = document.createElement("a");
      link.href = csvUrl;
      link.setAttribute("download", "file.csv"); // Optional: specify a default filename
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link); // Clean up after download
    } catch (error) {
      console.error("Failed to download CSV file: ", error);
    }
  };
  let keyLabels = ["A", "B", "C", "D"];
  console.log("downloadWordData: ", downloadWordData);
  console.log("downloadCsvData: ", downloadCsvData);

  console.log("Ques id: ", queId);

  return (
    <>
      <ToastContainer />
      {loadingupload && (
        // <div className="fixed inset-0 flex items-center justify-center bg-gray-500 bg-opacity-75 z-50">
        //   <div className="text-center">
        //     <div role="status">
        //       <svg
        //         aria-hidden="true"
        //         className="inline w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
        //         viewBox="0 0 100 101"
        //         fill="none"
        //         xmlns="http://www.w3.org/2000/svg"
        //       >
        //         <path
        //           d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
        //           fill="currentColor"
        //         />
        //         <path
        //           d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
        //           fill="currentFill"
        //         />
        //       </svg>
        //       <span className="sr-only">Loading...</span>
        //     </div>
        //   </div>
        // </div>

        <div className="fixed inset-0 flex items-center justify-center bg-gray-500 bg-opacity-75 z-50">
          <div className="text-center">
            <div className="w-64 h-4 bg-gray-200 rounded overflow-hidden">
              <div
                className="h-full bg-blue-600 transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
            <p className="mt-2 text-white">{uploadProgress}%</p>
          </div>
        </div>
      )}
      <div className="container mx-auto p-4 text-black">
        <div className="flex justify-between">
          <h1 className="text-2xl font-semibold mb-4">Upload Files</h1>
          {isData && <p>Total Token:{token}</p>}
        </div>

        <div className="mb-6">
          <div>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="lg:flex items-center justify-start gap-5">
                {user_typeObj?.user_type_id === 1 ? (
                  <div className="upload_data_area w-full lg:w-5/12 mb-2 lg:mb-0">
                    <div className="mb-1 block">
                      <Label
                        className="text-base font-semibold"
                        value="Select Role"
                      />
                    </div>
                    <Select
                      id="base"
                      type="text"
                      sizing="md"
                      className="w-9/12"
                      {...register("startString", {
                        required: "Text is Required",
                      })}
                    >
                      <option value="">Select Role</option>
                      {subList?.results?.map((sub) => {
                        return (
                          <>
                            <option value={sub?.subject_name}>
                              {sub?.subject_name} Teacher
                            </option>
                          </>
                        );
                      })}
                    </Select>
                  </div>
                ) : (
                  <div className="upload_data_area w-full lg:w-5/12 mb-2 lg:mb-0">
                    <div className="mb-1 block">
                      <Label className="text-base font-semibold" value="Role" />
                    </div>
                    <TextInput
                      id="base"
                      type="text"
                      sizing="md"
                      className="w-9/12"
                      value={`${subejct} Teacher`}
                      readOnly
                    />
                    <input
                      type="hidden"
                      {...register("startString", {
                        required: "Text is Required",
                      })}
                      defaultValue={subejct}
                    />
                  </div>
                )}

                <div className="upload_data_area w-full lg:w-3/12">
                  <div className="mb-1 block">
                    <Label
                      className="text-base font-semibold"
                      value="Upload file"
                    />
                  </div>
                  <FileInput
                    id="file-upload"
                    {...register("file", { required: "File is Required" })}
                  />
                </div>
                <div>
                  <button
                    type="submit"
                    className="bg-[#4554a4] px-6 py-[11px] text-white rounded-md mt-4 lg:mt-8 ml-1 hover:bg-[#e86975] font-semibold"
                  >
                    {loadingupload ? "Waiting.." : "Upload"}
                  </button>
                </div>
                {errors.pdf_file && (
                  <span className="text-red-500">
                    {errors.pdf_file.message}
                  </span>
                )}
              </div>
            </form>
          </div>
        </div>
        {console.log("questionResponse: ", questionResponse?.message)}
        {isData && questionResponse?.message?.length > 0
          ? questionResponse?.message?.map((que, index) => {
              console.log("ques: ", JSON.parse(que));

              return (
                <>
                  <div key={index}>
                    <ul>
                      <li>
                        {/* {parsedQuestion?.question_number}.{que?.question_text}
                        Option:{que?.options} */}
                        {JSON.parse(que)?.steps?.map((jsonQue, index) => {
                          return (
                            <>
                              <ul>
                                <li className="bg-white p-6 rounded-md shadow-lg mb-4">
                                  <strong>
                                    {" "}
                                    {index + 1}.{jsonQue?.questions}
                                  </strong>
                                  <strong className="block">Option:</strong>
                                  <ul className="mb-2">
                                    {console.log("ops", jsonQue?.options)}

                                    {/* {Object.entries(jsonQue.options).map(
                                      ([key, value]) =>
                                        key !== "/" && ( // Filter out unwanted keys (like '/')
                                          <li key={key}>
                                            {key}: {value}
                                          </li>
                                        )
                                    )} */}
                                    {jsonQue?.options?.map((value, index) => (
                                      <li key={index}>
                                        {keyLabels[index]}:{value}
                                      </li>
                                    ))}
                                  </ul>
                                  <strong>Correct Answer:</strong>
                                  {jsonQue?.answer}
                                  <br />
                                  <strong>Explanation:</strong>
                                  {jsonQue?.explanation}
                                </li>
                              </ul>
                            </>
                          );
                        })}
                      </li>
                    </ul>
                  </div>
                </>
              );
            })
          : null}

        {isData && (
          <>
            <Link
              // to={`${downloadCsvData?.csv_url}`}
              onClick={() => handleCsvFileDownload(queId)}
              type="button"
              className="bg-[#4554a4] px-4 py-2 text-white rounded-md mt-7 ml-1 hover:bg-[#e86975] font-semibold"
            >
              Download Csv
            </Link>
            <Link
              // to={`${downloadWordData?.word_url}`}
              onClick={() => handleWordFileDownload(queId)}
              type="button"
              className="bg-[#4554a4] px-4 py-2 text-white rounded-md mt-7 ml-1 hover:bg-[#e86975] font-semibold float-right"
            >
              Download Doc
            </Link>
          </>
        )}
      </div>

      <div className="overflow-x-auto"></div>
    </>
  );
};

export default Uploadpdf;
