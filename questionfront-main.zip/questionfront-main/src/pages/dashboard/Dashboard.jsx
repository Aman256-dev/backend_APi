import { useDispatch, useSelector } from "react-redux";
import admin_icon from "../../assets/images/admin_icon.png";
import { useEffect, useMemo } from "react";
import { getdashBoard } from "../../reducers/DashboardSlice";
import { Table } from "flowbite-react";
import { getVendorCsv } from "../../reducers/UploadVendorCsvSlice";
import { createColumnHelper } from "@tanstack/react-table";
import TanstackReactTable from "../../data-table/TanstackReactTable";
import { Link } from "react-router-dom";
import {
  activeDeactiveUser,
  deleteUser,
  getAllUser,
} from "../../reducers/UserSlice";
import { MdDelete } from "react-icons/md";
const Dashboard = () => {
  const { usersCount, loading } = useSelector((state) => state?.dashboardData);
  const columnHelper = createColumnHelper();
  const { vendorList } = useSelector((state) => state?.venDorCsv);
  const user_nameJson = localStorage.getItem("name");
  const user_name_obj = JSON.parse(user_nameJson);
  const first_name = user_name_obj.name;
  console.log("UserName: ", first_name);

  const user_typeJson = localStorage.getItem("userType");
  const user_typeObj = JSON.parse(user_typeJson);
  console.log("UserObj", user_typeObj?.user_type_id);
  const dispatch = useDispatch();

  const { allUsers } = useSelector((state) => state?.users);

  useEffect(() => {
    dispatch(getAllUser());
  }, [dispatch]);
  console.log("dashboard allUsers: ", allUsers?.results);

  const handleToggleStatus = (user_id, currentStatus) => {
    const newStatus = currentStatus === 0 ? 1 : 0;
    dispatch(activeDeactiveUser({ id: user_id, status: newStatus })).then(
      () => {
        dispatch(getAllUser());
      }
    );
  };
  const deleteHandler = (user_id) => {
    dispatch(deleteUser({ id: user_id })).then(() => {
      dispatch(getAllUser());
    });
  };
  // const columns = useMemo(
  //   () => [
  //     columnHelper.accessor("vendor", {
  //       cell: (info) => <span>{info.getValue()}</span>,
  //       header: "Vendor",
  //     }),

  //     columnHelper.accessor("product_service", {
  //       cell: (info) => <span>{info.getValue()}</span>,
  //       header: "Product/Service",
  //     }),

  //     columnHelper.accessor("contact", {
  //       cell: (info) => <span>{info.getValue()}</span>,
  //       header: "Contact",
  //     }),

  //     columnHelper.accessor("best_contact", {
  //       cell: (info) => <span>{info.getValue()}</span>,
  //       header: "Best Contact",
  //     }),

  //     columnHelper.accessor("phone", {
  //       cell: (info) => {
  //         const phone = info.getValue();
  //         return (
  //           <Link to={`tel:${phone}`}>
  //             <span>{phone}</span>
  //           </Link>
  //         );
  //       },
  //       header: "Phone",
  //     }),

  //     columnHelper.accessor("email", {
  //       cell: (info) => {
  //         const email = info.getValue();
  //         return (
  //           <Link to={`mailto:${email}`}>
  //             <span>{email}</span>,
  //           </Link>
  //         );
  //       },
  //       header: "Email",
  //     }),

  //     columnHelper.accessor("member_benifit", {
  //       cell: (info) => <span>{info.getValue()}</span>,
  //       header: "Member Benefit",
  //     }),
  //   ],
  //   [columnHelper] // Depend on columnHelper so it's not recreated unnecessarily
  // );
  return (
    <>
      <div className="p-4">
        <div>
          <h2 className="text-black text-2xl font-semibold mb-4">Dashboard</h2>
          <div className="grid grid-cols-3 gap-4 bg-white p-4 rounded-lg border border-[#dedede] mb-4">
            <div className="flex">
              <div className="mr-4">
                <img
                  className="w-[50px] h-50px rounded-full"
                  src={admin_icon}
                  alt="admin_icon"
                />
              </div>
              <div>
                <p className="text-[#4051a3] font-normal text-base">Welcome</p>
                <h3 className="text-black font-normal text-lg">{first_name}</h3>
              </div>
            </div>
            {/* {user_typeObj?.user_type_id === 2 ? (
              <>
                <div className="text-center">
                  <h3 className="text-[#4051a3] font-bold text-lg">
                    Total Users
                  </h3>
                  <p className="text-[#ff98ac] font-bold text-lg">
                    {usersCount?.user_count}
                  </p>
                </div>
                <div className="text-center">
                  <h3 className="text-[#4051a3] font-bold text-lg">
                    Total Members
                  </h3>
                  <p className="text-[#ff98ac] font-bold text-lg">
                    {usersCount?.user_info_count}
                  </p>
                </div>
              </>
            ) : (
              <></>
            )} */}
          </div>
        </div>
      </div>
      {user_typeObj?.user_type_id === 1 ? (
        <div className="container mx-auto p-4 text-black">
          <h1 className="text-2xl font-semibold mb-4">User List</h1>
          <div className="overflow-x-auto ">
            <Table striped className="static">
              <Table.Head>
                <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                  Actions
                </Table.HeadCell>
                <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                  First Name
                </Table.HeadCell>
                <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                  Last Name
                </Table.HeadCell>
                <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                  Email
                </Table.HeadCell>
                <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                  Type
                </Table.HeadCell>
                <Table.HeadCell className="text-sm text-white font-bold bg-[#4051a3]">
                  Status
                </Table.HeadCell>
              </Table.Head>
              <Table.Body className="divide-y">
                {allUsers?.results?.map((users) => {
                  return (
                    <>
                      <Table.Row className="bg-white dark:border-gray-700 dark:bg-gray-800">
                        <Table.Cell className="flex items-center justify-start">
                          <div className="mr-10">
                            <label className="inline-flex items-center cursor-pointer">
                              <input
                                type="checkbox"
                                // value={users?.status}
                                checked={users.status === 1}
                                onChange={() =>
                                  handleToggleStatus(users.id, users.status)
                                }
                                className="sr-only peer"
                              />
                              <div className="relative w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                            </label>
                          </div>
                          <button
                            onClick={() => {
                              deleteHandler(users?.id);
                            }}
                            className="text-[#ea5c65] hover:text-black"
                          >
                            <MdDelete className="text-2xl" />
                          </button>
                        </Table.Cell>
                        <Table.Cell className="font-bold">
                          {users?.fname}
                        </Table.Cell>
                        <Table.Cell className="font-bold">
                          {users?.lname}
                        </Table.Cell>
                        <Table.Cell className="font-bold">
                          {users?.email}
                        </Table.Cell>
                        <Table.Cell className="font-bold">
                          {users?.user_type}
                        </Table.Cell>
                        <Table.Cell>
                          {users?.status === 0 ? (
                            <>
                              <button className="text-[#ea5c65] font-bold">
                                Inactive
                              </button>
                            </>
                          ) : (
                            <button className="text-[#277B0C] font-bold">
                              Active
                            </button>
                          )}
                        </Table.Cell>
                      </Table.Row>
                    </>
                  );
                })}
              </Table.Body>
            </Table>
          </div>
        </div>
      ) : (
        <></>
      )}
    </>
  );
};

export default Dashboard;
