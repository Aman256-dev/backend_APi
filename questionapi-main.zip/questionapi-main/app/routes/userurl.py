from django.urls import path
from app.api.users.auth import UserAuthView
from app.api.users import UserView
from app.api.users import urlPdfView
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from django.conf import settings
from django.conf.urls.static import static

urlpatterns=[
    path('sign-up',UserAuthView.sign_up),
    path("login",UserAuthView.login),
    path('extract-questions', UserView.extract_questions, name='extract_questions'),
    path('download-csv', UserView.download_csv, name='download_csv'),
    path('download-word', UserView.download_word, name='download_word'),
    path('create-password',UserAuthView.create_password),
    path('forget-password',UserAuthView.forget_password),
    path('reset-password',UserAuthView.reset_password),
    path('health', UserView.health_check, name='health'),
    path('url-question',urlPdfView.generate_questions_from_url_api),
    path('pdf-question',urlPdfView.generate_questions_api),
    path('download-csv-pdf',urlPdfView.download_csv),
    path('download-docx-pdf',urlPdfView.download_word),
    path('subjects',urlPdfView.get_all_subjects),
    
]


