import base64
import json
from rest_framework.decorators import api_view,permission_classes,authentication_classes
from rest_framework.response import Response
from app.models.users import User
from app.models.userType import UserType
from app.models.prompts import Prompt
from django.contrib.auth.hashers import make_password, check_password
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
import requests
from rest_framework import status
from app.validations.serializers import *
from django.conf import settings
from datetime import datetime
from django.template.loader import render_to_string
from django.core.mail import send_mail
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def prompt_list(request):
    prompts=Prompt.objects.order_by('-id')
    if(prompts.count()>0):
        get_prompts=prompts.all()
        prompt_list=[]
        for get_prompt in get_prompts:
            prompt={
                'id':get_prompt.id,
                'subject':get_prompt.subject,
                'prompt':get_prompt.prompt
            }
            prompt_list.append(prompt)
        status_type=True
        results=prompt_list
        status_code=status.HTTP_200_OK
    else:
        status_type = True
        results = []
        status_code = status.HTTP_200_OK
    return Response({
        'status':status_type,
        'results':results,
        'status_code':status_code
    },status_code)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def edit_prompt(request):
    prompt_id=request.data.get("prompt_id")
    if(prompt_id is not None):
        prompt=Prompt.objects.filter(id=prompt_id)
        if(prompt.count()>0):
            get_prompt=prompt.first()
            res={
                'id':get_prompt.id,
                'subject':get_prompt.subject,
                'prompt':get_prompt.prompt
            }
            status_type=True
            result=res
            status_code=status.HTTP_200_OK
        else:
            status_type = True
            result = 'No record found'
            status_code = status.HTTP_200_OK
    else:
        status_type = False
        result = 'prompt_id cannot be null'
        status_code = status.HTTP_400_BAD_REQUEST
    return Response({
        'status':status_type,
        'result':result,
        'status_code':status_code
    },status_code)

@api_view(['POST'])
@permission_classes([IsAuthenticated])
def update_prompt(request):
    data = request.data
    serializer = PromptSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            'status': False,
            'message': 'Validation error',
            'errors': serializer.errors,
            'status_code': status.HTTP_400_BAD_REQUEST
        }, status.HTTP_400_BAD_REQUEST)
    prompt_id=request.data.get("prompt_id")
    prompt=request.data.get("prompt")
    # print(len(prompt))
    get_prompt = Prompt.objects.filter(id=prompt_id)
    if(get_prompt.count()>0):
        if(prompt is not None and len(prompt)>0):
            get_prompt.update(prompt=prompt)
            if(get_prompt):
                status_type=True
                msg='Updated successfully'
                status_code=status.HTTP_200_OK
            else:
                status_type = False
                msg = 'Unable to update'
                status_code = status.HTTP_400_BAD_REQUEST
        else:
            status_type = False
            msg = 'prompt cannot be left blank'
            status_code = status.HTTP_400_BAD_REQUEST
    else:
        status_type = False
        msg = 'No record found'
        status_code = status.HTTP_400_BAD_REQUEST
    return Response({
        'status':status_type,
        'message':msg,
        'status_code':status_code
    },status_code)