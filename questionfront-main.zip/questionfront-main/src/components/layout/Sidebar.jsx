import {
  ImHome,
  AiOutlinePoweroff,
  AiOutlineUsergroupAdd,
  BsBorderWidth,
  MdSubscriptions,
} from "../../utils/icons";

import Logo from "../../assets/images/logo.png";
import { Link, useNavigate } from "react-router-dom";
import { logout } from "../../reducers/AuthSlice";
import { useDispatch } from "react-redux";

import SmallLogo from "../../assets/images/small_logo.png";
import { AiOutlineUser } from "react-icons/ai";

import { RiCoupon2Fill } from "react-icons/ri";
import { CiCircleList } from "react-icons/ci";
import { IoMdAddCircle } from "react-icons/io";
import { IoLogIn } from "react-icons/io5";
import {
  FaFileCsv,
  FaFilePdf,
  FaFileSignature,
  FaLightbulb,
  FaLink,
  FaUser,
} from "react-icons/fa";
import { FaDatabase } from "react-icons/fa6";
import { IoMdCloudUpload } from "react-icons/io";
import { TbPrompt } from "react-icons/tb";
import { useState } from "react";

function Sidebar() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [isHovered, setIsHovered] = useState(false);

  const handleLogout = async () => {
    dispatch(logout());
    navigate("/");
  };
  const user_typeJson = localStorage.getItem("userType");
  const user_typeObj = JSON.parse(user_typeJson);
  console.log("UserObj", user_typeObj?.user_type_id);

  return (
    <aside className="top-0 left-0 flex flex-col w-16 h-screen p-3 ease-linear shadow-md no-scrollbar sm:m-0 sm:w-64 md:w-72 bg-white hs-overlay hs-overlay-open:translate-x-0">
      <Link
        to="/dashboard"
        className="flex items-center justify-center w-full mt-0 mb-10"
      >
        {/* <img
          src={Logo}
          className="hidden transition-transform duration-1000 delay-500 transform md:block rounded-0 rotate-360"
          alt="Flowbite Logo"
        /> */}
        {/* <img src={SmallLogo} className="block md:hidden" alt="Flowbite Logo" /> */}
      </Link>

      <div className="transition-all duration-1000 grow">
        <ul className="space-y-5">
          {user_typeObj?.user_type_id === 1 ||
          user_typeObj?.user_type_id === 2 ? (
            <>
              <li>
                <Link
                  to="/dashboard"
                  className="flex items-start gap-2 p-1 m-1 transition-transform sm:p-2 hover:scale-110"
                >
                  <ImHome size={24} className="text-[#e86975]" />
                  <span className="hidden font-semibold sm:inline-block text-[#4353a4] hover:text-[#e86975]">
                    Dashboard
                  </span>
                </Link>
              </li>

              {user_typeObj?.user_type_id === 1 && (
                <li
                  className="relative"
                  onMouseEnter={() => setIsHovered(true)}
                  onMouseLeave={() => setIsHovered(false)}
                >
                  <div className="flex items-start gap-2 p-1 m-1 transition-transform sm:p-2 hover:scale-110 cursor-pointer">
                    <IoMdCloudUpload size={24} className="text-[#e86975]" />
                    <span className="hidden font-semibold sm:inline-block text-[#4353a4] hover:text-[#e86975]">
                      URL and PDF
                    </span>
                  </div>
                  {isHovered && (
                    <ul className="absolute top-0 left-[calc(100%-80px)] bg-white border border-gray-200 shadow-lg rounded-md z-10 w-[150px]">
                      <li className="flex items-center gap-2 px-4 py-2 hover:bg-gray-100">
                        <FaLink size={16} className="text-[#e86975]" />
                        <Link
                          to="/uploadUrl"
                          className="text-sm text-[#4353a4] hover:text-[#e86975]"
                        >
                          Upload URL
                        </Link>
                      </li>
                      <li className="flex items-center gap-2 px-4 py-2 hover:bg-gray-100">
                        <FaFilePdf size={16} className="text-[#e86975]" />
                        <Link
                          to="/uploadPdf"
                          className="text-sm text-[#4353a4] hover:text-[#e86975]"
                        >
                          Upload PDF
                        </Link>
                      </li>
                      <li className="flex items-center gap-2 px-4 py-2 hover:bg-gray-100">
                        <FaLightbulb size={16} className="text-[#e86975]" />
                        <Link
                          to="/addPrompt"
                          className="text-sm text-[#4353a4] hover:text-[#e86975]"
                        >
                          Add Prompt
                        </Link>
                      </li>
                    </ul>
                  )}
                </li>
              )}

              <li>
                <Link
                  to="/upload-pdf"
                  className="flex items-start gap-2 p-1 m-1 transition-transform sm:p-2 hover:scale-110"
                >
                  <IoMdCloudUpload size={24} className="text-[#e86975]" />
                  <span className="hidden font-semibold sm:inline-block text-[#4353a4] hover:text-[#e86975]">
                    Upload File
                  </span>
                </Link>
              </li>

              {user_typeObj?.user_type_id === 1 ? (
                <>
                  <li>
                    <Link
                      to="/prompt"
                      className="flex items-start gap-2 p-1 m-1 transition-transform sm:p-2 hover:scale-110"
                    >
                      <TbPrompt size={24} className="text-[#e86975]" />
                      <span className="hidden font-semibold sm:inline-block text-[#4353a4] hover:text-[#e86975]">
                        Prompt
                      </span>
                    </Link>
                  </li>

                  <li>
                    <Link
                      to="/add-user"
                      className="flex items-start gap-2 p-1 m-1 transition-transform sm:p-2 hover:scale-110"
                    >
                      <FaUser size={24} className="text-[#e86975]" />
                      <span className="hidden font-semibold sm:inline-block text-[#4353a4] hover:text-[#e86975]">
                        Add Teacher
                      </span>
                    </Link>
                  </li>
                </>
              ) : (
                <></>
              )}
            </>
          ) : (
            <>
              {/* <li>
                <Link
                  to="/dashboard"
                  className="flex items-start gap-2 p-1 m-1 transition-transform sm:p-2 hover:scale-110"
                >
                  <ImHome size={24} className="text-[#e86975]" />
                  <span className="hidden font-semibold sm:inline-block text-[#4353a4] hover:text-[#e86975]">
                    Dashboard
                  </span>
                </Link>
              </li>
              <li className="dropdown_section">
                <Link className="flex items-start gap-2 p-1 m-1 transition-transform sm:p-2 hover:scale-110">
                  <FaFileSignature size={24} className="text-[#e86975]" />
                  <span className="hidden font-semibold sm:inline-block text-[#4353a4] hover:text-[#e86975]">
                    View Files
                  </span>
                </Link>
                <ul>
                  <li>
                    <Link
                      to="/view_pdf"
                      className="flex items-start gap-2 p-1 m-1 transition-transform sm:p-2 hover:scale-110"
                    >
                      <FaFilePdf size={24} className="text-[#e86975]" />
                      <span className="hidden font-semibold sm:inline-block text-[#4353a4] hover:text-[#e86975]">
                        PDF
                      </span>
                    </Link>
                  </li>
                </ul>
              </li>
              <li>
                <Link
                  to="/myplans"
                  className="flex items-start gap-2 p-1 m-1 transition-transform sm:p-2 hover:scale-110"
                >
                  <span className="hidden font-semibold sm:inline-block text-[#4353a4] hover:text-[#e86975]">
                    My Plan
                  </span>
                </Link>
              </li> */}
            </>
          )}
        </ul>
      </div>
      <div className="mb-1 transition-all duration-1000">
        <ul className="space-5">
          <li>
            <button
              onClick={handleLogout}
              className="flex justify-center w-full gap-2 p-1 m-1 transition-transform bg-[#4554a4] rounded-md shadow-lg sm:p-2 hover:bg-black"
            >
              <AiOutlinePoweroff size={24} className="text-[#e86975]" />
              <span className="hidden font-semibold sm:inline-block text-slate-100">
                Logout
              </span>
            </button>
          </li>
        </ul>
      </div>
    </aside>
  );
}

export default Sidebar;
