from django.db import models
import uuid

class QuestionSet(models.Model):
    question_id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    questions_data = models.JSONField()

    class Meta:
        db_table = 'question_sets'
