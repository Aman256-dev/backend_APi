from django.http import HttpResponse, JsonResponse
from django.core.files.storage import default_storage
from django.conf import settings
import os
from werkzeug.utils import secure_filename
import json
import re
import pandas as pd
import os
import PyPDF2
import pytesseract
from pdf2image import convert_from_path
import re
from openai import OpenAI
import os
from pydantic import BaseModel
import requests
from bs4 import BeautifulSoup
from rest_framework.decorators import api_view,permission_classes,authentication_classes
from rest_framework.response import Response
from rest_framework import status
from app.models.urlPdfPrompt import UrlPdfPrompt
from app.models.cache import QuestionSet
from django.contrib.auth import authenticate
from rest_framework.permissions import IsAuthenticated
from app.validations.serializers import *
from django.core.files.storage import FileSystemStorage
import logging
import pandas as pd
from datetime import datetime
from io import StringIO, BytesIO
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

import pytesseract
from pdf2image import convert_from_path
import cv2
import numpy as np
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm
import re

# for new logic
import os
from typing import List
from PyPDF2 import PdfReader
from langchain.text_splitter import CharacterTextSplitter
from langchain_openai import OpenAIEmbeddings, ChatOpenAI
from langchain_community.vectorstores import FAISS
from langchain.chains import RetrievalQA
from langchain.agents import initialize_agent, Tool
from langchain.agents import AgentType
from langchain.schema import HumanMessage
import tiktoken
import re
from pydantic import BaseModel, Field, validator
from typing import List
from langchain.prompts import PromptTemplate
import json


from dotenv import load_dotenv
load_dotenv()
openai_api_key = os.getenv("OPENAI_API_KEY")

logger = logging.getLogger(__name__)




client = OpenAI()

ALLOWED_EXTENSIONS = {'pdf'}

def clean_text(text):
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text)
    # Remove leading/trailing whitespace from each line
    text = '\n'.join(line.strip() for line in text.split('\n'))
    # Remove empty lines
    text = re.sub(r'\n+', '\n', text)
    return text.strip()

def process_page(args):
    page_num, pdf_path = args
    
    # Convert single page to image
    images = convert_from_path(pdf_path, first_page=page_num, last_page=page_num, dpi=200)
    
    page_text = ""
    for image in images:
        # Convert PIL Image to OpenCV format
        opencv_image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
        
        # Resize image if it's too large
        max_dimension = 3000
        h, w = opencv_image.shape[:2]
        if max(h, w) > max_dimension:
            scale = max_dimension / max(h, w)
            opencv_image = cv2.resize(opencv_image, None, fx=scale, fy=scale)
        
        # Convert to grayscale
        gray = cv2.cvtColor(opencv_image, cv2.COLOR_BGR2GRAY)
        
        # Apply thresholding to preprocess the image
        gray = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
        
        # Perform text extraction
        text = pytesseract.image_to_string(gray, config='--psm 6')
        page_text += text + "\n"
    
    # Clean the extracted text
    cleaned_text = clean_text(page_text)
    return f"Page {page_num}:\n{cleaned_text}\n"


def extract_text_from_pdf(pdf_path, max_workers=None):
    # Existing code for text extraction
    images = convert_from_path(pdf_path, dpi=200)
    num_pages = len(images)
    
    extracted_text = []
    
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_page = {executor.submit(process_page, (page_num, pdf_path)): page_num 
                          for page_num in range(1, num_pages + 1)}
        
        for future in tqdm(as_completed(future_to_page), total=num_pages, desc="Processing pages"):
            page_num = future_to_page[future]
            try:
                page_text = future.result()
                extracted_text.append(page_text)
            except Exception as exc:
                print(f'Page {page_num} generated an exception: {exc}')
    
    full_text = ''.join(extracted_text)
    
    # Vector database creation
    print("Splitting text into chunks...")
    text_splitter = CharacterTextSplitter(chunk_size=200, chunk_overlap=20)
    texts = text_splitter.split_text(full_text)
    print(f"Created {len(texts)} text chunks")
    
    print("Creating embeddings and vector store...")
    embeddings = OpenAIEmbeddings()
    vectorstore = FAISS.from_texts(texts, embeddings)
    print("Vector store created successfully")
    
    return vectorstore


def extract_text_from_url(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        paragraphs = soup.find_all('p')
        text = ' '.join([p.get_text() for p in paragraphs])

        text_splitter = CharacterTextSplitter(chunk_size=200, chunk_overlap=20)
        texts = text_splitter.split_text(text)
        
        embeddings = OpenAIEmbeddings()
        vectorstore = FAISS.from_texts(texts, embeddings)

        return vectorstore
    except requests.RequestException as e:
        raise Exception(f"Error fetching URL: {str(e)}")
    


class Step(BaseModel):
    questions: str = Field(description="The question to be asked")
    options: List[str] = Field(description="List of possible answers")
    answer: str = Field(description="The correct answer")
    explanation: str = Field(description="Explanation for the correct answer")

    @validator('options')
    def check_options_length(cls, v):
        if len(v) != 4:
            raise ValueError('There must be exactly 4 options')
        return v

    @classmethod
    def parse_obj(cls, obj):
        if isinstance(obj, str):
            try:
                obj = json.loads(obj)
            except json.JSONDecodeError:
                pass
        if isinstance(obj, dict) and 'examples' in obj:
            return cls(**obj['examples'][0])
        return super().parse_obj(obj)

class MathReasoning(BaseModel):
    steps: List[Step] = Field(description="List of reasoning steps")

def count_tokens(text: str) -> int:
    encoding = tiktoken.encoding_for_model("gpt-4o-mini-2024-07-18")
    return len(encoding.encode(text))

def truncate_text(text: str, max_tokens: int) -> str:
    encoding = tiktoken.encoding_for_model("gpt-4o-mini-2024-07-18")
    encoded = encoding.encode(text)
    return encoding.decode(encoded[:max_tokens])
    

def generate_question(query: str, subject: str) -> Step:
    print(f"Generating question for query: {query}")
    context = retriever.invoke(query)[0].page_content
    truncated_context = truncate_text(context, 3000)

    template = UrlPdfPrompt.objects.filter(subject=subject).first()
    prompt_template = template.prompt
    
    prompt_template = PromptTemplate(
        input_variables=["context", "query"],
        template=prompt_template
    )
    
    prompt = prompt_template.format(context=truncated_context, query=query)
    result = llm.invoke([HumanMessage(content=prompt)])
    
    # Parse the result
    lines = result.content.split('\n')
    question = next((line.split(':', 1)[1].strip() for line in lines if line.startswith("Question:")), "")
    options = [line.split(')', 1)[1].strip() for line in lines if re.match(r'^[A-D]\)', line)]
    answer = next((line.split(':', 1)[1].strip() for line in lines if line.startswith("Answer:")), "")
    explanation = next((line.split(':', 1)[1].strip() for line in lines if line.startswith("Explanation:")), "")
    
    # Ensure we have exactly 4 options
    while len(options) < 4:
        options.append(f"Option {chr(65+len(options))}")
    
    if not question or not answer or not explanation or len(options) != 4:
        raise ValueError("Invalid question format: missing required fields or incorrect number of options")

    return Step(
        questions=question,
        options=options,
        answer=answer,
        explanation=explanation
    )

def generate_questions(vectorstore: FAISS, num_questions: int, subject: str) -> MathReasoning:
    print("Initializing question generation...")
    global llm, retriever
    llm = ChatOpenAI(model="gpt-4o-mini-2024-07-18", temperature=0.7)
    retriever = vectorstore.as_retriever(search_kwargs={"k": 3})  # Increased k to 3

    generated_questions = set()  # To store previously generated questions

    tools = [
        Tool(
            name="QuestionGenerator",
            func=lambda q: generate_question(q, subject),
            description="Useful for generating questions based on the content of the PDF"
        ),
        Tool(
            name="DiversityChecker",
            func=lambda x: "Different" if x not in generated_questions else "Similar",
            description="Checks if a question is different from previously generated ones"
        )
    ]

    print("Initializing agent...")
    agent = initialize_agent(tools, llm, agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION, verbose=True)

    steps = []
    for i in range(num_questions):
        attempts = 0
        max_attempts = 5  # Increased max attempts
        while attempts < max_attempts:
            try:
                print(f"Generating question {i+1}/{num_questions}")
                result = agent.invoke({
                    "input": f"""Generate question {i+1} of {num_questions}. 
                    Make it different from previous questions. 
                    Try to vary the type of question (e.g., calculation, conceptual understanding, problem-solving).
                    Use the DiversityChecker tool to ensure the question is unique."""
                })
                
                if isinstance(result['output'], Step):
                    step = result['output']
                else:
                    step = generate_question(
                        f"Generate a {['calculation', 'conceptual', 'problem-solving'][i % 3]} question about {subject} different from previous ones.",
                        subject
                    )
                
                # Validate the step
                if not step.questions or not step.answer or not step.explanation or len(step.options) != 4:
                    raise ValueError("Invalid question format: missing required fields or incorrect number of options")
                
                # Check for diversity
                if step.questions in generated_questions:
                    raise ValueError("Question is too similar to a previously generated one")
                
                generated_questions.add(step.questions)
                steps.append(step)
                print(f"{subject} question {i+1} generated successfully")
                break
            except ValueError as e:
                print(f"Error generating question {i+1}: {e}")
                attempts += 1
        
        if attempts == max_attempts:
            print(f"Failed to generate valid question after {max_attempts} attempts")
            fallback_question =generate_question(f"Generate a simple {['calculation', 'conceptual', 'problem-solving'][i % 3]} question.")
            steps.append(fallback_question)

    return MathReasoning(steps=steps)




def process_and_chunk_text(text, chunk_size):
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    
    # Split into chunks
    chunks = [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)]
    return chunks


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def json_to_dataframe(math_reasoning):
    # Handle both MathReasoning objects and raw JSON/dict data
    if isinstance(math_reasoning, MathReasoning):
        steps = math_reasoning.steps
    elif isinstance(math_reasoning, str):
        data = json.loads(math_reasoning)
        steps = data.get('steps', [])
    else:
        steps = math_reasoning.get('steps', [])

    questions, option_a, option_b, option_c, option_d, answers, explanations = ([] for _ in range(7))

    def extract_content(option):
        match = re.match(r'^(?:\(?(?:[A-Da-d]|[1-4])[\)\.:]|[A-Da-d]\s*:)?\s*(.+)$', option.strip())
        return match.group(1) if match else option

    def extract_answer(answer):
        match = re.match(r'^(?:\(?([A-Da-d])[\)\.:])?\s*', answer.strip())
        if match and match.group(1):
            return match.group(1).upper()
        return extract_content(answer)

    for step in steps:
        # Handle both Step objects and dictionaries
        if isinstance(step, Step):
            questions.append(step.questions)
            options = step.options
            answers.append(extract_answer(step.answer))
            explanations.append(step.explanation)
        else:
            questions.append(step.get('questions', ''))
            options = step.get('options', [''] * 4)
            answers.append(extract_answer(step.get('answer', '')))
            explanations.append(step.get('explanation', ''))
        
        # Ensure we have exactly 4 options
        options = list(options)  # Convert to list if it's not already
        options += [''] * (4 - len(options))
        
        option_a.append(extract_content(options[0]))
        option_b.append(extract_content(options[1]))
        option_c.append(extract_content(options[2]))
        option_d.append(extract_content(options[3]))

    df = pd.DataFrame({
        'Question': questions,
        'Option A': option_a,
        'Option B': option_b,
        'Option C': option_c,
        'Option D': option_d,
        'Answer': answers,
        'Explanation': explanations
    })

    return df




@api_view(['POST'])
def generate_questions_api(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Only POST method is allowed'}, status=405)

    if 'file' not in request.FILES:
        return JsonResponse({'error': 'No file part'}, status=400)
    
    file = request.FILES.get('file')
    subject = request.POST.get('subject')
    
    if not subject:
        return JsonResponse({'error': 'Subject is required'}, status=400)
    
    if file.name == '':
        return JsonResponse({'error': 'No selected file'}, status=400)
    
    max_questions = request.POST.get('max_questions', 5)
    
    try:
        max_questions = int(max_questions)
        if max_questions <= 0:
            return JsonResponse({'error': 'max_questions must be a positive integer'}, status=400)
    except ValueError:
        return JsonResponse({'error': 'max_questions must be a valid integer'}, status=400)

    if file and allowed_file(file.name):
        filename = secure_filename(file.name)
        temp_file_path = 'temp.pdf'
    
        with open(temp_file_path, 'wb+') as destination:
            for chunk in file.chunks():
                destination.write(chunk)
        
        try:
            vectorstore = extract_text_from_pdf(temp_file_path)
            math_reasoning = generate_questions(vectorstore, max_questions, subject)
            
            # Convert MathReasoning object to DataFrame
            df = json_to_dataframe(math_reasoning)
            df_list = df.to_dict(orient='records')
            
            question_set = QuestionSet.objects.create(
                questions_data=df_list)
            
            # Convert MathReasoning to dict for response
            questions_dict = {
                "steps": [
                    {
                        "questions": step.questions,
                        "options": step.options,
                        "answer": step.answer,
                        "explanation": step.explanation
                    } for step in math_reasoning.steps
                ]
            }
            
            # Clean up
            default_storage.delete(temp_file_path)
            
            return Response({
                'status': True,
                'questions': questions_dict,
                'question_id': str(question_set.question_id),
                'status_type': status.HTTP_200_OK
            }, status.HTTP_200_OK)
            
        except Exception as e:
            if default_storage.exists(temp_file_path):
                default_storage.delete(temp_file_path)
            return JsonResponse({'success': False, 'error': str(e)})
    
    return JsonResponse({'error': 'Invalid file type'}, status=400)





@api_view(['POST'])
def generate_questions_from_url_api(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'Only POST method is allowed'}, status=405)

    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON'}, status=400)

    if not data or 'url' not in data:
        return JsonResponse({'error': 'No URL provided'}, status=400)
    
    url = data['url']
    max_questions = data.get('max_questions', 5)
    subject = data.get('subject')
    
    try:
        max_questions = int(max_questions)
        if max_questions <= 0:
            return JsonResponse({'error': 'max_questions must be a positive integer'}, status=400)
    except ValueError:
        return JsonResponse({'error': 'max_questions must be a valid integer'}, status=400)
    
    try:

        vectorstore = extract_text_from_url(url)
        math_reasoning = generate_questions(vectorstore, max_questions, subject)
        
        # Convert MathReasoning object to DataFrame
        df = json_to_dataframe(math_reasoning)
        df_list = df.to_dict(orient='records')
        
        question_set = QuestionSet.objects.create(
            questions_data=df_list)
        
        # Convert MathReasoning to dict for response
        questions_dict = {
            "steps": [
                {
                    "questions": step.questions,
                    "options": step.options,
                    "answer": step.answer,
                    "explanation": step.explanation
                } for step in math_reasoning.steps
            ]
        }
        
        return Response({
                'status': True,
                'questions': questions_dict,
                'question_id': str(question_set.question_id),
                'status_type':status.HTTP_200_OK
            },status.HTTP_200_OK)
    except Exception as e:
        logger.error(f"Error processing file: {str(e)}")
        return JsonResponse({'success': False, 'error': str(e)})



@api_view(['GET'])
# @permission_classes([IsAuthenticated])
def download_csv(request):
    question_id = request.GET.get('question_id')
    if not question_id:
        logger.warning("Missing question ID in request")
        return HttpResponse("Missing question ID", status=400)

    #questions_json = cache.get(f"questions_{question_id}")
    #questions_json = QuestionSet.objects.get(question_id=question_id)
    
    questions_jsona = QuestionSet.objects.get(question_id=question_id)
    questions_json = questions_jsona.questions_data
    
    if not questions_json:
        logger.warning(f"No data found in cache for question_id: {question_id}")
        return HttpResponse("No data available for download", status=400)

    def clean_text(text):
        # Remove HTML-like color formatting
        if isinstance(text, str):
            # Remove color tags like <red>text</red>
            text = re.sub(r'<[^>]+>', '', text)
            # Remove color formatting if it exists in other formats
            text = re.sub(r'\[\[red\]\]|\[\[/red\]\]', '', text)
            # Remove any other potential color formatting
            text = re.sub(r'\{color:[^}]+\}|\{/color\}', '', text)
        return text

    try:
        #questions_data = json.loads(questions_json)
        
        # Create DataFrame and clean the data
        dataframe = pd.DataFrame(questions_json)

        column_order = [
            'Question',
            'Option A',
            'Option B',
            'Option C',
            'Option D',
            'Answer',
            'Explanation'
        ]
        
        # Reorder columns
        dataframe = dataframe[column_order]
        
        # Clean specific columns that might contain color formatting
        columns_to_clean = ['Answer', 'Question', 'Option A', 'Option B', 'Option C', 'Option D']
        for column in columns_to_clean:
            if column in dataframe.columns:
                dataframe[column] = dataframe[column].apply(clean_text)
        
        current_time = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        user_id = request.user.id
        file_name = f"generated_questions_{current_time}.csv"
        csv_folder = os.path.join('media', 'csv', str(user_id))
        file_path = os.path.join(csv_folder, file_name)

        # Ensure the directory exists
        os.makedirs(csv_folder, exist_ok=True)
        
        # Create a CSV bytes object from the DataFrame
        csv_buffer = BytesIO()
        dataframe.to_csv(csv_buffer, index=False, encoding='utf-8')
        csv_bytes = csv_buffer.getvalue()

        # Save the file using FileSystemStorage
        fs = FileSystemStorage(location=csv_folder)
        with fs.open(file_name, 'wb') as csv_file:
            csv_file.write(csv_bytes)

        # Generate the URL
        csv_url = f'{settings.BASE_URL}/{csv_folder}/{file_name}'
        logger.info(f"CSV file generated successfully for user {user_id}, question_id: {question_id}")
        return JsonResponse({'csv_url': csv_url})
    
    except json.JSONDecodeError:
        logger.error(f"Invalid JSON data in cache for question_id: {question_id}")
        return HttpResponse("Error: Invalid JSON data in cache", status=500)
    except Exception as e:
        logger.error(f"Error processing data for question_id {question_id}: {str(e)}")
        return HttpResponse(f"Error processing data: {str(e)}", status=500)  


@api_view(['GET'])
# @permission_classes([IsAuthenticated])
def download_word(request):
    question_id = request.GET.get('question_id')
    if not question_id:
        logger.warning("Missing question ID in request")
        return HttpResponse("Missing question ID", status=400)

    #questions_json = cache.get(f"questions_{question_id}")
    #questions_json = QuestionSet.objects.get(question_id=question_id)
    
    questions_jsona = QuestionSet.objects.get(question_id=question_id)
    questions_json = questions_jsona.questions_data
    
    if not questions_json:
        logger.warning(f"No data found in cache for question_id: {question_id}")
        return HttpResponse("No data available for download", status=400)
    
    try:
        #questions_data = json.loads(questions_json)
        
        # Create DataFrame directly from the loaded data
        words_df = pd.DataFrame(questions_json)
        
        # Create a new Word document
        doc = Document()
        
        # Add a title
        title = doc.add_heading('Generated Questions', level=1)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Iterate through the DataFrame and add content to the Word document
        for index, row in words_df.iterrows():
            # Add a question number
            doc.add_paragraph(f"Question {index + 1}", style='List Number')
            
            # Add Question
            if 'Question' in row:
                doc.add_paragraph(f"Question: {row['Question']}")
            
            # Add options
            for option in ['A', 'B', 'C', 'D']:
                option_field = f'Option {option}'
                if option_field in row:
                    doc.add_paragraph(f"{option}) {row[option_field]}")
            
            # Add answer
            if 'Answer' in row:
                answer_para = doc.add_paragraph("Answer: ")
                answer_run = answer_para.add_run(str(row['Answer']))
                answer_run.font.color.rgb = RGBColor(0, 128, 0)  # Green color
                answer_run.bold = True
            
            # Add explanation
            if 'Explanation' in row:
                explanation_para = doc.add_paragraph("Explanation: ")
                explanation_para.add_run(str(row['Explanation'])).italic = True
            
            # Add a separator
            doc.add_paragraph("_" * 50)
        
        # Save the document to a BytesIO object
        buffer = BytesIO()
        doc.save(buffer)
        buffer.seek(0)
        
        # Generate file name and path
        current_time = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        user_id = request.user.id
        file_name = f"generated_questions_{current_time}.docx"
        word_folder = os.path.join('media', 'word', str(user_id))
        file_path = os.path.join(word_folder, file_name)
        
        # Ensure the directory exists
        os.makedirs(word_folder, exist_ok=True)
        
        # Save the file
        fs = FileSystemStorage(location=word_folder)
        with fs.open(file_name, 'wb') as doc_file:
            doc_file.write(buffer.getvalue())
        
        # Generate the URL
        doc_url_words = f'{settings.BASE_URL}/{word_folder}/{file_name}'
        logger.info(f"Word document generated successfully for user {user_id}, question_id: {question_id}")
        return JsonResponse({'word_url': doc_url_words})
    
    except json.JSONDecodeError:
        logger.error(f"Invalid JSON data in cache for question_id: {question_id}")
        return HttpResponse("Error: Invalid JSON data in cache", status=500)
    except Exception as e:
        logger.error(f"Error processing data for question_id {question_id}: {str(e)}")
        return HttpResponse(f"Error processing data: {str(e)}", status=500)






@api_view(['POST'])
@permission_classes([IsAuthenticated])
def edit_prompt(request):
    prompt_id=request.data.get("prompt_id")
    if(prompt_id is not None):
        prompt=UrlPdfPrompt.objects.filter(id=prompt_id)
        if(prompt.count()>0):
            get_prompt=prompt.first()
            res={
                'id':get_prompt.id,
                'subject':get_prompt.subject,
                'prompt':get_prompt.prompt
            }
            status_type=True
            result=res
            status_code=status.HTTP_200_OK
        else:
            status_type = True
            result = 'No record found'
            status_code = status.HTTP_200_OK
    else:
        status_type = False
        result = 'prompt_id cannot be null'
        status_code = status.HTTP_400_BAD_REQUEST
    return Response({
        'status':status_type,
        'result':result,
        'status_code':status_code
    },status_code)




@api_view(['POST'])
@permission_classes([IsAuthenticated])
def update_prompt(request):
    data = request.data
    serializer = pdfurlPromptSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            'status': False,
            'message': 'Validation error',
            'errors': serializer.errors,
            'status_code': status.HTTP_400_BAD_REQUEST
        }, status.HTTP_400_BAD_REQUEST)
    prompt_id=request.data.get("prompt_id")
    prompt=request.data.get("prompt")
    # print(len(prompt))
    get_prompt = UrlPdfPrompt.objects.filter(id=prompt_id)
    if(get_prompt.count()>0):
        if(prompt is not None and len(prompt)>0):
            get_prompt.update(prompt=prompt)
            if(get_prompt):
                status_type=True
                msg='Updated successfully'
                status_code=status.HTTP_200_OK
            else:
                status_type = False
                msg = 'Unable to update'
                status_code = status.HTTP_400_BAD_REQUEST
        else:
            status_type = False
            msg = 'prompt cannot be left blank'
            status_code = status.HTTP_400_BAD_REQUEST
    else:
        status_type = False
        msg = 'No record found'
        status_code = status.HTTP_400_BAD_REQUEST
    return Response({
        'status':status_type,
        'message':msg,
        'status_code':status_code
    },status_code)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def add_subject_with_prompt(request):
    subject=request.data.get("subject")
    prompt=request.data.get("prompt")
    # print(len(prompt))
    get_prompt = UrlPdfPrompt.objects.filter(subject=subject)
    if(get_prompt.count()==0):
        if(prompt is not None and len(prompt)>0):
            if(subject is not None and len(subject)>0):
                    add_subject = UrlPdfPrompt.objects.create(prompt=prompt, subject = subject)
                    if(add_subject.id >0):
                        status_type=True
                        msg='created successfully'
                        status_code=status.HTTP_201_CREATED
                    else:
                        status_type = False
                        msg = 'Unable to create'
                        status_code = status.HTTP_400_BAD_REQUEST
            else:
                status_type = False
                msg = 'subject cannot be left blank'
                status_code = status.HTTP_400_BAD_REQUEST
        else:
                status_type = False
                msg = 'prompt  cannot be left blank'
                status_code = status.HTTP_400_BAD_REQUEST
    else:
        status_type = False
        msg = 'Already exist'
        status_code = status.HTTP_400_BAD_REQUEST
    return Response({
        'status':status_type,
        'message':msg,
        'status_code':status_code
    },status_code)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_all_subjects(request):
    subjects = UrlPdfPrompt.objects.values_list('subject', flat=True).distinct()
    
    if subjects:
        return Response({
            'status': True,
            'message': 'Subjects retrieved successfully',
            'subjects': list(subjects),
            'status_code': status.HTTP_200_OK
        }, status=status.HTTP_200_OK)
    else:
        return Response({
            'status': False,
            'message': 'No subjects found',
            'subjects': [],
            'status_code': status.HTTP_404_NOT_FOUND
        }, status=status.HTTP_404_NOT_FOUND)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_all_subjects_with_prompt(request):
    # Get all unique subjects with their prompts and IDs
    subjects_data = UrlPdfPrompt.objects.values('id', 'subject', 'prompt').distinct()
    
    if subjects_data:
        return Response({
            'status': True,
            'message': 'Subjects retrieved successfully',
            'subjects': list(subjects_data),
            'status_code': status.HTTP_200_OK
        }, status=status.HTTP_200_OK)
    else:
        return Response({
            'status': False,
            'message': 'No subjects found',
            'subjects': [],
            'status_code': status.HTTP_404_NOT_FOUND
        }, status=status.HTTP_404_NOT_FOUND)