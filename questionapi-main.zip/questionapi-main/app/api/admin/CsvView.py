import base64
import json
from rest_framework.decorators import api_view,permission_classes,authentication_classes
from rest_framework.response import Response
from app.models.users import User
from app.models.userType import UserType
from app.models.subject import Subject
from app.models.csv_prompt import CsvPrompt
from django.contrib.auth import authenticate
from rest_framework_simplejwt.tokens import RefreshToken
import requests
from rest_framework import status
from app.validations.serializers import *
from django.conf import settings
from datetime import datetime
from django.template.loader import render_to_string
from django.core.mail import send_mail
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAuthenticated

from rest_framework.decorators import api_view, permission_classes
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from werkzeug.utils import secure_filename
from io import StringIO, BytesIO
from django.core.files.storage import FileSystemStorage

import pandas as pd
from pydantic import BaseModel
from openai import OpenAI
import os
from dotenv import load_dotenv
load_dotenv()
openai_api_key = os.getenv("OPENAI_API_KEY")


client = OpenAI()

class Step(BaseModel):
    questions: str
    options: list[str]
    answer: str
    explanation: str

class MathReasoning(BaseModel):
    steps: list[Step]


def generate_questions_math(input_question:str,prompt_name: str) -> Step:
    # prompt_template = """The following words generate the sentennce"""
    template = CsvPrompt.objects.filter(prompt_name=prompt_name).first()
    prompt_template = template.prompt


    completion = client.beta.chat.completions.parse(
    model="gpt-4o-2024-08-06",
    messages=[
        {"role": "system", "content": prompt_template},
        {"role": "user", "content": input_question}
    ],
    response_format=MathReasoning,
    )

    math_reasoning = completion.choices[0].message

    # If the model refuses to respond, you will get a refusal message
    if hasattr(math_reasoning, 'refusal') and math_reasoning.refusal:
        # print(math_reasoning.refusal)
        pass
    else:
        # Convert the parsed response to a Pydantic model
        math_solution = MathReasoning(steps=math_reasoning.parsed.steps)
    
    # Convert the Pydantic model to JSON
    json_output = math_solution.model_dump_json(indent=2)
    return json_output


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def upload_csv(request):
    if 'file' not in request.FILES:
        return Response({'error': 'No file uploaded'}, status=400)

    file = request.FILES['file']
    file_extension = file.name.split('.')[-1].lower()
    prompt_name = request.data.get('prompt_name')

    if file_extension not in ['csv', 'xls', 'xlsx']:
        return Response({'error': 'Unsupported file format. Please upload CSV or Excel files.'}, status=400)

    try:
        # Save the uploaded file
        temp_file_path = default_storage.save(f'temp/{file.name}', ContentFile(file.read()))

        # Read the file
        if file_extension == 'csv':
            df = pd.read_csv(default_storage.path(temp_file_path))
        else:
            df = pd.read_excel(default_storage.path(temp_file_path))

        # Validate that required columns exist
        if 'id' not in df.columns or 'word' not in df.columns:
            return Response({'error': 'File must contain "id" and "word" columns'}, status=400)

        # Process each row through the OpenAI model
        df['processed_content'] = df.apply(lambda row: generate_questions_math(row['word'],prompt_name), axis=1)


        current_time = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        user_id = request.user.id
        file_name = f"generated_file_{current_time}.csv"
        csv_folder = os.path.join('media', 'csv', str(user_id))
        file_path = os.path.join(csv_folder, file_name)

        # Ensure the directory exists
        os.makedirs(csv_folder, exist_ok=True)
        
        # Create a CSV bytes object from the DataFrame
        csv_buffer = BytesIO()
        df.to_csv(csv_buffer, index=False, encoding='utf-8')
        csv_bytes = csv_buffer.getvalue()

        # Save the file using FileSystemStorage
        fs = FileSystemStorage(location=csv_folder)
        with fs.open(file_name, 'wb') as csv_file:
            csv_file.write(csv_bytes)

        # Generate the URL
        download_link = f'{settings.BASE_URL}/{csv_folder}/{file_name}'

        return Response({
            'message': 'File processed successfully',
            'download_link': download_link
        }, status=200)

    except Exception as e:
        return Response({'error': str(e)}, status=500)

    finally:
        # Clean up the temporary file
        if temp_file_path:
            default_storage.delete(temp_file_path)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def add_csv_prompt(request):
    prompt_name=request.data.get("prompt_name")
    prompt=request.data.get("prompt")
    # print(len(prompt))
    get_prompt = CsvPrompt.objects.filter(prompt_name=prompt_name)
    if(get_prompt.count()==0):
        if(prompt is not None and len(prompt)>0):
            if(prompt_name is not None and len(prompt_name)>0):
                    add_subject = CsvPrompt.objects.create(prompt=prompt, prompt_name = prompt_name)
                    if(add_subject.id >0):
                        status_type=True
                        msg='created successfully'
                        status_code=status.HTTP_201_CREATED
                    else:
                        status_type = False
                        msg = 'Unable to create'
                        status_code = status.HTTP_400_BAD_REQUEST
            else:
                status_type = False
                msg = 'prompt name cannot be left blank'
                status_code = status.HTTP_400_BAD_REQUEST
        else:
                status_type = False
                msg = 'prompt  cannot be left blank'
                status_code = status.HTTP_400_BAD_REQUEST
    else:
        status_type = False
        msg = 'Already exist'
        status_code = status.HTTP_400_BAD_REQUEST
    return Response({
        'status':status_type,
        'message':msg,
        'status_code':status_code
    },status_code)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def edit_prompt(request):
    prompt_id=request.data.get("prompt_id")
    if(prompt_id is not None):
        prompt=CsvPrompt.objects.filter(id=prompt_id)
        if(prompt.count()>0):
            get_prompt=prompt.first()
            res={
                'id':get_prompt.id,
                'subject':get_prompt.prompt_name,
                'prompt':get_prompt.prompt
            }
            status_type=True
            result=res
            status_code=status.HTTP_200_OK
        else:
            status_type = True
            result = 'No record found'
            status_code = status.HTTP_200_OK
    else:
        status_type = False
        result = 'prompt_id cannot be null'
        status_code = status.HTTP_400_BAD_REQUEST
    return Response({
        'status':status_type,
        'result':result,
        'status_code':status_code
    },status_code)



@api_view(['POST'])
@permission_classes([IsAuthenticated])
def update_prompt(request):
    data = request.data
    serializer = csvPromptSerializer(data=request.data)
    if not serializer.is_valid():
        return Response({
            'status': False,
            'message': 'Validation error',
            'errors': serializer.errors,
            'status_code': status.HTTP_400_BAD_REQUEST
        }, status.HTTP_400_BAD_REQUEST)
    prompt_id=request.data.get("prompt_id")
    prompt=request.data.get("prompt")
    # print(len(prompt))
    get_prompt = CsvPrompt.objects.filter(id=prompt_id)
    if(get_prompt.count()>0):
        if(prompt is not None and len(prompt)>0):
            get_prompt.update(prompt=prompt)
            if(get_prompt):
                status_type=True
                msg='Updated successfully'
                status_code=status.HTTP_200_OK
            else:
                status_type = False
                msg = 'Unable to update'
                status_code = status.HTTP_400_BAD_REQUEST
        else:
            status_type = False
            msg = 'prompt cannot be left blank'
            status_code = status.HTTP_400_BAD_REQUEST
    else:
        status_type = False
        msg = 'No record found'
        status_code = status.HTTP_400_BAD_REQUEST
    return Response({
        'status':status_type,
        'message':msg,
        'status_code':status_code
    },status_code)



@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_all_prompt_name(request):
    subjects = CsvPrompt.objects.values_list('prompt_name', flat=True).distinct()
    
    if subjects:
        return Response({
            'status': True,
            'message': 'Subjects retrieved successfully',
            'subjects': list(subjects),
            'status_code': status.HTTP_200_OK
        }, status=status.HTTP_200_OK)
    else:
        return Response({
            'status': False,
            'message': 'No subjects found',
            'subjects': [],
            'status_code': status.HTTP_404_NOT_FOUND
        }, status=status.HTTP_404_NOT_FOUND)



@api_view(['GET'])
@permission_classes([IsAuthenticated])
def get_all_promptName_with_prompt(request):
    # Get all unique subjects with their prompts and IDs
    subjects_data = CsvPrompt.objects.values('id', 'prompt_name', 'prompt').distinct()
    
    if subjects_data:
        return Response({
            'status': True,
            'message': 'Subjects retrieved successfully',
            'subjects': list(subjects_data),
            'status_code': status.HTTP_200_OK
        }, status=status.HTTP_200_OK)
    else:
        return Response({
            'status': False,
            'message': 'No subjects found',
            'subjects': [],
            'status_code': status.HTTP_404_NOT_FOUND
        }, status=status.HTTP_404_NOT_FOUND)