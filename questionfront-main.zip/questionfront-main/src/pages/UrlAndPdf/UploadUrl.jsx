import { Label, Select, TextInput } from "flowbite-react";
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import {
  downloadCsv,
  downloadDoc,
  getSubjects,
  resetPDFandURL,
  uploadUrl,
} from "../../reducers/PdfAndUrlSlice";
import { toast, ToastContainer } from "react-toastify";
import { Link } from "react-router-dom";

const UploadUrl = () => {
  const dispatch = useDispatch();
  const { subjects, loadinguploadUrl, urlResponse, loadingCsv, loadingDoc } =
    useSelector((state) => state?.pdfAndUrl);
  console.log("Subjects", subjects);
  console.log("urlResponse", urlResponse);
  const [isData, setIsData] = useState(false);
  const [queId, setQueId] = useState("");
  // const [token, setToken] = useState("");
  const [uploadProgress, setUploadProgress] = useState(0);

  const {
    register,
    handleSubmit,
    setError,
    formState: { errors },
    reset,
  } = useForm();

  useEffect(() => {
    dispatch(getSubjects());
  }, [dispatch]);

  const onSubmit = (data) => {
    console.log("Data", data);
    setUploadProgress(0); // Reset progress
    let progressInterval;

    // Start simulating progress
    progressInterval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 95) {
          // Stop incrementing at 90%
          clearInterval(progressInterval);
          return prev;
        }
        return prev + 5; // Increment progress
      });
    }, 1000);
    // const formdata = new FormData();
    // formdata.append("file", data?.file[0]);
    // formdata.append("subject", data?.subject);
    // formdata.append("max_questions", data?.max_questions);
    const payload = {
      url: data?.url,
      max_questions: parseInt(data?.max_questions),
      subject: data?.subject,
      // token: 3000,
      // per_token_queston: 3,
    };
    dispatch(uploadUrl(payload)).then((res) => {
      console.log("res", res);
      clearInterval(progressInterval);
      if (res?.payload?.status === true) {
        setIsData(true);
        setQueId(res?.payload?.question_id);
        // setToken(res?.payload?.Total_token);
        toast.success("Url Upload Successfully", {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          progress: undefined,
          theme: "light",
        });
      } else {
        toast.error(res?.payload?.error, {
          position: "top-right",
          autoClose: 5000,
          hideProgressBar: false,
          closeOnClick: true,
          progress: undefined,
          theme: "dark",
        });
      }
    });
  };

  const handleWordFileDownload = async (queId) => {
    try {
      const res = await dispatch(downloadDoc(queId)).unwrap();
      console.log("res", res);
      const wordUrl = res.word_url; // Assuming response contains word_url
      console.log("Word URL: ", wordUrl);

      // Create a hidden link and trigger download
      const link = document.createElement("a");
      link.href = wordUrl;
      link.setAttribute("download", "file.docx"); // Optional: specify a default filename
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link); // Clean up after download
    } catch (error) {
      console.error("Failed to download Word file: ", error);
    }
  };
  const handleCsvFileDownload = async (queId) => {
    try {
      const res = await dispatch(downloadCsv(queId)).unwrap();
      const csvUrl = res.csv_url; // Assuming response contains csv_url
      console.log("CSV URL: ", csvUrl);

      // Create a hidden link and trigger download
      const link = document.createElement("a");
      link.href = csvUrl;
      link.setAttribute("download", "file.csv"); // Optional: specify a default filename
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link); // Clean up after download
    } catch (error) {
      console.error("Failed to download CSV file: ", error);
    }
  };

  let keyLabels = ["A", "B", "C", "D"];

  useEffect(() => {
    dispatch(resetPDFandURL());
  }, []);

  return (
    <>
      <ToastContainer />
      {/* {loadinguploadUrl && (
                <div className="fixed inset-0 flex items-center justify-center bg-gray-500 bg-opacity-75 z-50">
                    <div className="text-center">
                        <div role="status">
                            <svg
                                aria-hidden="true"
                                className="inline w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
                                viewBox="0 0 100 101"
                                fill="none"
                                xmlns="http://www.w3.org/2000/svg"
                            >
                                <path
                                    d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                                    fill="currentColor"
                                />
                                <path
                                    d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                                    fill="currentFill"
                                />
                            </svg>
                            <span className="sr-only">Loading...</span>
                        </div>
                    </div>
                </div>
            )} */}
      {loadinguploadUrl && (
        <div className="fixed inset-0 flex items-center justify-center bg-gray-500 bg-opacity-75 z-50">
          <div className="text-center">
            <div className="w-64 h-4 bg-gray-200 rounded overflow-hidden">
              <div
                className="h-full bg-blue-600 transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
            <p className="mt-2 text-white">{uploadProgress}%</p>
          </div>
        </div>
      )}
      <div className="container mx-auto p-4 text-black">
        <div className="flex justify-between">
          <h1 className="text-2xl font-semibold mb-4">Upload Url</h1>
          {/* {isData && <p>Total Token:{token}</p>} */}
        </div>

        <div className="mb-6">
          <div>
            <form onSubmit={handleSubmit(onSubmit)}>
              <div className="lg:flex items-center justify-start gap-5">
                <div className="w-full lg:w-6/12 mb-2 lg:mb-0">
                  <div className="mb-1 block">
                    <Label className="text-base font-semibold" value="URL" />
                  </div>
                  <TextInput
                    id="base"
                    type="text"
                    sizing="md"
                    className="w-9/12"
                    {...register("url", {
                      required: "Url is Required",
                    })}
                    // defaultValue={subejct}
                  />
                  {errors.url && (
                    <span className="text-red-500">{errors.url.message}</span>
                  )}
                </div>

                <div className="upload_data_area w-full lg:w-6/12 mb-2 lg:mb-0">
                  <div className="mb-1 block">
                    <Label
                      className="text-base font-semibold"
                      value="Select Subject"
                    />
                  </div>
                  <Select
                    id="base"
                    type="text"
                    sizing="md"
                    className="w-9/12"
                    {...register("subject", {
                      required: "Subject is Required",
                    })}
                  >
                    <option value="">Select Subject</option>
                    {subjects?.subjects?.map((sub) => {
                      return (
                        <>
                          <option value={sub}>{sub}</option>
                        </>
                      );
                    })}
                  </Select>
                  {errors.subject && (
                    <span className="text-red-500">
                      {errors.subject.message}
                    </span>
                  )}
                </div>
                {/* <div className="w-full lg:w-6/12 mb-2 lg:mb-0">
                  <div className="mb-1 block">
                    <Label
                      className="text-base font-semibold"
                      value="Number of Tokens"
                    />
                  </div>
                  <TextInput
                    id="base"
                    type="number"
                    sizing="md"
                    className="w-9/12"
                    {...register("token", {
                      required: "Token is Required",
                    })}
                    // defaultValue={subejct}
                  />
                  {errors.token && (
                    <span className="text-red-500">{errors.token.message}</span>
                  )}
                </div>
                <div className="w-full lg:w-6/12 mb-2 lg:mb-0">
                  <div className="mb-1 block">
                    <Label
                      className="text-base font-semibold"
                      value="Question Per Tokens"
                    />
                  </div>
                  <TextInput
                    id="base"
                    type="number"
                    sizing="md"
                    className="w-9/12"
                    {...register("per_token_queston", {
                      required: "Question Per Token is Required",
                    })}
                    // defaultValue={subejct}
                  />
                  {errors.per_token_queston && (
                    <span className="text-red-500">
                      {errors.per_token_queston.message}
                    </span>
                  )}
                </div> */}
                <div className="w-full lg:w-6/12 mb-2 lg:mb-0">
                  <div className="mb-1 block">
                    <Label
                      className="text-base font-semibold"
                      value="Max Question"
                    />
                  </div>
                  <TextInput
                    id="base"
                    type="number"
                    sizing="md"
                    className="w-9/12"
                    {...register("max_questions", {
                      required: "Max question is Required",
                    })}
                    // defaultValue={subejct}
                  />
                  {errors.max_questions && (
                    <span className="text-red-500">
                      {errors.max_questions.message}
                    </span>
                  )}
                </div>

                <div>
                  <button
                    type="submit"
                    className="bg-[#4554a4] px-6 py-[11px] text-white rounded-md mt-4 lg:mt-8 ml-1 hover:bg-[#e86975] font-semibold"
                  >
                    {loadinguploadUrl ? "Wait..." : "Upload"}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>

        {urlResponse?.questions ? (
          <>
            <div>
              <ul>
                <li>
                  {urlResponse?.questions?.steps?.map((jsonQue, index) => {
                    return (
                      <>
                        <ul>
                          <li className="bg-white p-6 rounded-md shadow-lg mb-4">
                            <strong>
                              {" "}
                              {index + 1}.{jsonQue?.questions}
                            </strong>
                            <strong className="block">Option:</strong>
                            <ul className="mb-2">
                              {jsonQue?.options?.map((value, index) => (
                                <li key={index}>
                                  {keyLabels[index]}:{value}
                                </li>
                              ))}
                            </ul>
                            <strong>Correct Answer:</strong>
                            {jsonQue?.answer}
                            <br />
                            <strong>Explanation:</strong>
                            {jsonQue?.explanation}
                          </li>
                        </ul>
                      </>
                    );
                  })}
                </li>
              </ul>
            </div>
          </>
        ) : null}

        {
          // isData
          urlResponse?.questions && (
            <>
              <Link
                // to={`${downloadCsvData?.csv_url}`}
                onClick={() => handleCsvFileDownload(urlResponse?.question_id)}
                type="button"
                className="bg-[#4554a4] px-4 py-2 text-white rounded-md mt-7 ml-1 hover:bg-[#e86975] font-semibold"
              >
                {loadingCsv ? "Wait..." : "Download Csv"}
              </Link>
              <Link
                // to={`${downloadWordData?.word_url}`}
                onClick={() => handleWordFileDownload(urlResponse?.question_id)}
                type="button"
                className="bg-[#4554a4] px-4 py-2 text-white rounded-md mt-7 ml-1 hover:bg-[#e86975] font-semibold float-right"
              >
                {loadingDoc ? "Wait..." : "Download Doc"}
              </Link>
            </>
          )
        }
      </div>

      <div className="overflow-x-auto"></div>
    </>
  );
};

export default UploadUrl;
